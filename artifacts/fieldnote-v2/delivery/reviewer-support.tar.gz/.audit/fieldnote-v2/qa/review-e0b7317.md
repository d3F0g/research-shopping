# Independent corrected-candidate QA. PASS for the reviewed offline scope.

The goal is a useful minimal Exa-only conversational shopping assistant. This independent review is pinned to base `9d2a3c5e336a6652ec6b02e0c3deff6617fb7d11` and head `e0b7317f4bd00ce49141229943279e0da357cdbc`. The complete `src` tree is `e1d7c10c59e1251216e3ba99c0a55c5157109fd9`; the reviewed reducer blob is `ebbeb045de4cb0d1daedc44cfe8711993c015a4d`. I authored no application changes. Current tracked application, package, tests, eval and skill files have no QA modifications.

**PASS for the corrected functional and visual scope.** Both blockers from the 8fdc2b2 review now pass their original real-browser reproductions, and positive controls preserve intentional edits and new research. No unresolved blocking defect was reproduced in this final delta. This is not a claim of full live product acceptance. Genuine Exa discovery, representative semantic usefulness, current merchant information and merchant authorization remain unestablished by offline fixtures.

The full program's prior reports and red evidence remain preserved in `review-d858ca7.md`, `review-8d679f3.md`, and `review-8fdc2b2.md`. Only the reducer and new contextual unit/API assertions changed in application scope since 8fdc2b2. Source/price boundaries, UI composition, schemas, account code and packet exporter are unchanged.

## Original defects independently reverified

The unchanged independent `extended-meaning.mjs` harness now reports **10/10 groups passed**, cleanup true, at this exact head.

- `Find a compact photo printer under GBP 100.` followed by `That GBP 89 one looks good. I'm not a member and won't subscribe.` keeps maximum GBP 100. It returns an ordinary held reply, makes no new SDK request, and stores only the negative buyer facts as additional hard context. Earlier messages remain immutable.
- `Find a waterproof backpack under USD 100. It must protect contents in heavy rain.` followed by `One source says waterproof and another says only splash-resistant. Which is it?` keeps the entire intent unchanged and makes no new SDK request. It answers from retained assessments rather than turning a source question into a hard requirement.
- The actual frozen `FN-EH-001` trace also contains the waterproof and splash-resistant source passages. Its corrected reply explicitly surfaces the retained conflict first and preserves both passages and source URLs in the disclosure. User description does not become new source evidence.

Proof is `artifacts/fieldnote-v2/qa/final-e0b/meaning-recheck/proof.json`. Actual mobile screenshots include `quoted-price-budget-state.png` and `source-conflict-question.png`.

## Positive controls independently driven through Chromium

The separate shorter targeted real UI journey reports **4/4 groups passed**, cleanup true. It runs the original two reproduction cases plus these positive controls:

- Start with GBP 70–100 and no disposable batteries. Mention the GBP 89 product and reject membership/subscription. Both bounds and existing hard requirements survive, the buyer restrictions become hard context, eligibility remains conservative and the SDK count is unchanged.
- `Make it 120.` then changes only the maximum to 120, retains minimum 70 and buyer requirements, and dispatches exactly one SDK operation.
- A held source question remains free and preserves the complete current intent.
- `Research again.` dispatches exactly one SDK operation and keeps the intent unchanged.
- `That GBP 89 one looks good. I am not a member and remove the minimum.` remains pending as one complete unsupported combined edit. It does not remove the known minimum, add a partial qualification or dispatch research.

Proof is `final-e0b/targeted/proof.json`; screenshots include `free-held-source-question-positive.png` and `compound-selection-pending-whole.png`. The helper is `.audit/fieldnote-v2/qa/context-targeted.mjs`.

## Actual final commands and results

| Check | Result | Evidence under `artifacts/fieldnote-v2/qa/` |
| --- | --- | --- |
| `npm test` | 183 passed, 7 files | `final-e0b-test.log` |
| `npm run build` | Typecheck and build passed, existing large-chunk warning remains | `final-e0b-build.log` |
| Eval preservation, typecheck | Passed | `final-e0b-preservation.log`, `final-e0b-evaltype.log` |
| `npm run eval:test` | 20 passed | `final-e0b-evaltest.log` |
| Actual full 60-case SDK/Hono run | 11 passed, 0 failed, 48 blocked, 1 unsupported, 0 critical assertion failures, 0 infrastructure errors | `final-e0b/eval/report.json` |
| Preserved baseline bridge | 60/60 unchanged normative inputs, zero material differences | `final-e0b/scorecard/scorecard.md` |
| Strict actual browser eval | 29/29 checks, 15 screenshots, cleanup true | `final-e0b/strict-browser/proof.json` |
| Project verification skill | Three viewport journeys passed, cleanup true | `final-e0b/smoke/proof.json` |
| Unchanged independent extended browser | 10/10 groups passed, cleanup true | `final-e0b/meaning-recheck/proof.json` |
| Targeted browser plus positive controls | 4/4 groups passed, cleanup true | `final-e0b/targeted/proof.json` |
| Independent semantic regrade import | Ten packet-bound judgments accepted as reporting-only, human calibration pending | `final-e0b/semantic/semantic-report.json` |

The 60-case run's actual deterministic verdict remains **inconclusive**. The two local meaning fixes are additionally exercised in core unit/API coverage and the independent browser assertions above. The 48 blocked and one unsupported cases are not passes. The historical baseline stays 0 passed, 34 failed, 25 blocked, 1 unsupported, 37 critical failures. Comparing distinct evaluator contracts does not establish causal model-quality improvement.

Reproduction commands from the QA worktree:

```sh
QA_OUTPUT=artifacts/fieldnote-v2/qa/final-e0b/meaning-recheck node --unhandled-rejections=warn .audit/fieldnote-v2/qa/extended-meaning.mjs
QA_OUTPUT=artifacts/fieldnote-v2/qa/final-e0b/targeted node .audit/fieldnote-v2/qa/context-targeted.mjs
npm test
npm run build
npm run eval:preservation
npm run eval:typecheck
npm run eval:test
npm run eval -- --out artifacts/fieldnote-v2/qa/final-e0b/eval --gate critical
npm run eval:browser -- --out artifacts/fieldnote-v2/qa/final-e0b/strict-browser --mode strict
VERIFY_API_PORT=3273 VERIFY_WEB_PORT=5383 VERIFY_ARTIFACT_DIR=artifacts/fieldnote-v2/qa/final-e0b/smoke node .agents/skills/verify-research-shopping/scripts/smoke.mjs
```

The first unchanged broad-harness attempt timed out at the earlier necklace step before reaching the two target cases. Its pre-created response promise rejected outside the action catch and the driver exited. I preserved the diagnostic, verified the exact owned child PIDs, command lines, start times and worktree before stopping those process groups, then reran from free ports. The clean unchanged recheck passed every group. The shorter target run separately passed without the warning option. This diagnostic is not counted as product proof or silently erased.

## Semantic regrade from corrected actual data

The same purposeful six application scenarios and four evaluation-author calibration examples were re-exported against the actual final report. There are **zero omitted completed reply texts** and **four separate full-detail disclosures**. The packets retain actual visible text, collapsed disclosure identity, full detail, source passages, structured preferences and dispatch counts. Every imported judgment uses the newly bound packet hash.

The corrected source-conflict application case is qualitatively useful within its synthetic evidence. The other five application cases remain uncertain because incomplete or unsuitable fixture material cannot establish a justified completed choice. No selected current application case has a reported critical failure. The four separate authored calibration examples retain two useful, one not-useful and one uncertain verdicts. The intentionally bad Sony/over-budget calibration example remains a failure, not an application regression.

All judgments are **reporting-only** and **uncertain**, with human calibration pending. The same ten calibration-dimension disagreements remain recorded. There is no representative 60-case semantic score, no blind-study claim and no extra runtime inference API. Judge identity records this independent QA agent; exact host model identity is not exposed. The two changed cases were regraded after reading their actual corrected output. Unchanged cases and anchor judgments remain explicitly identified rather than presented as a new independent panel.

Artifacts are `final-e0b/semantic/selection.json`, `selected-report.json`, `packets.json`, `private-manifest.json`, `independent-judgments.json`, and `semantic-report.json`. This supersedes the two not-useful contextual judgments from the earlier 8fdc2b2 packet sample while preserving them as red evidence.

## Visual inspection and seven principles

I inspected the actual corrected source-question reply, quoted-price reply, positive held-source reply, pending compound message, and fresh mobile initial recommendation screenshots. Existing final desktop/mobile/short screenshots and component provenance remain applicable because no UI source changed. Fresh skill and strict-browser runs confirm the current behavior.

The layout remains minimal, centered, neutral and chat-first. The bottom composer and paid-call disclosure remain visible, with no dashboard, filter sidebar or document horizontal overflow. The useful recommendation and first title remain inside the initial viewport before manual scrolling. Keyboard disclosures, source controls, editor controls, scroll gutter and historical content remain reachable. A three-product held selection can occupy most of the mobile conversation viewport; its complete quoted evidence remains behind disclosure. The source-conflict lead is more verbose than a natural short answer, which is retained as a qualitative conciseness limitation rather than hidden by the passing functional checks.

| Principle | Final scoped assessment |
| --- | --- |
| Understand first | PASS for original price-reference and source-question reproductions, positive explicit edits and contextual references. |
| Define preferences in detail | PASS for separate buyer facts, both bounds, sticky hard requirements, pending whole compounds, scalar correction and actual editor. |
| Research and plan ahead | PASS for actual bounded local SDK lifecycle and intentional dispatch. Genuine external discovery remains unassessed. |
| Front-load | PASS for initial recommendation geometry and the earlier complete qualified short finding. Source-conflict conclusion precedes full source detail. |
| No scrolling blobs | PASS for the scoped progressive-disclosure behavior, with the noted multi-product/status verbosity limitation. |
| Per-user adaptation | PASS for quoted-price preservation, explicit edits, dissatisfaction, punctuated brand release, response length and retained history. |
| Restraint | PASS for free held source questions, selections and disclosures; explicit edits and fresh research still dispatch exactly once. |

## Reused evidence and boundaries

Account, workspace schema, source/price boundary and UI component blobs are unchanged from the preceding independently reviewed candidate. The prior final 8/8 maintained browser suite and registry verification are recorded in `review-8fdc2b2.md`. The actual 27 PostgreSQL tests, restart/crash/account browser checks and later detail persistence through real API restart remain explicitly reused unchanged-boundary evidence. They are not claimed to have run anew here. Root coordinates the separate final security review and GitHub gates.

No real Exa request, remote model API, private env/key, real ledger/grant, existing database, production operation, credential or permission change, purchase, push, merge or external comment occurred. All fixture data remains labeled. No current stock, live price, merchant authorization or genuine research usefulness follows from these runs. All final owned ports are free; final helper cleanup is true. The tracked source remained stable. A later docs/evidence-only head can inherit this verdict only after its source tree is verified equal to the pinned tree above.
