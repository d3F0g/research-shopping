import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { writeFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { chromium, expect } from "@playwright/test";
import { accountRuntime } from "../../../scripts/account-test-runtime.mjs";

const root = process.env.FIELDNOTE_SECURITY_ARTIFACT_DIR ?? "artifacts/fieldnote-v4/security";
const selected = process.env.FIELDNOTE_SECURITY_PROBE;
const proofPath = `${root}/${selected ? `probe-${selected.toLowerCase().replace(/[^a-z0-9]+/g, "-")}` : "adversarial-proof"}.json`;
const runtime = await accountRuntime({ web: true });
const browser = await chromium.launch();
const proof = { head: execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(), fixtureOnly: true, probes: [], cleanup: false };
const contexts = [];
const gate = () => { let release; const promise = new Promise((resolve) => { release = resolve; }); return { promise, release }; };
const message = (page) => page.getByRole("textbox", { name: "Message", exact: true });
const sendButton = (page) => page.getByRole("button", { name: "Send message", exact: true });
const newChat = (page) => page.getByRole("button", { name: "New chat", exact: true });
const stats = (page) => page.request.get(`${runtime.origin}/api/test-stats`).then((response) => response.json());
async function pageFor() {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  contexts.push(context);
  const page = await context.newPage();
  await context.route("**/*", (route) => new URL(route.request().url()).origin === runtime.origin ? route.continue() : route.abort());
  await page.goto(runtime.origin);
  await expect(newChat(page)).toBeEnabled();
  return page;
}
async function send(page, text) {
  await message(page).fill(text);
  await sendButton(page).click();
}
async function signUp(page) {
  await page.getByRole("button", { name: "Account", exact: true }).click();
  await page.getByRole("button", { name: "Create an account", exact: true }).click();
  await page.getByRole("textbox", { name: "Name", exact: true }).fill("Fixture security shopper");
  await page.getByRole("textbox", { name: "Email", exact: true }).fill(`fixture-security-${randomUUID()}@example.test`);
  await page.getByLabel("Password", { exact: true }).fill("fixture-security-password-only");
  await page.getByRole("button", { name: "Create account", exact: true }).click();
  await expect(page.getByRole("dialog")).toHaveCount(0);
}
async function probe(name, action) {
  if (selected && !name.includes(selected)) return;
  if (!selected && (name.startsWith("late initial") || name.includes("signed-in workspace with guest content"))) return;
  const result = { name, status: "running" };
  proof.probes.push(result);
  try { await action(result); result.status = "passed"; }
  catch (error) { result.status = "failed"; result.error = String(error); }
  await writeFile(proofPath, JSON.stringify(proof, null, 2));
}
try {
  await probe("reset blocks Enter, currency and preference submits without queuing, preserving a same-valued new draft", async (result) => {
    const page = await pageFor();
    await send(page, "A fixture powerbank around $30-40");
    await expect(page.getByRole("button", { name: "SGD", exact: true })).toBeEnabled();
    const before = await stats(page);
    const entered = gate(), release = gate();
    const submissions = [];
    page.on("request", (request) => { if (request.url().endsWith("/api/turn")) submissions.push(request.postDataJSON()); });
    await page.route("**/api/new-chat", async (route) => { entered.release(); await release.promise; await route.continue(); });
    await message(page).fill("SGD");
    await newChat(page).click();
    await entered.promise;
    try {
      await expect(message(page)).toHaveValue("");
      await message(page).fill("SGD");
      await message(page).press("Enter");
      await expect(sendButton(page)).toBeDisabled();
      await expect(newChat(page)).toBeDisabled();
      await expect(page.getByRole("button", { name: "SGD", exact: true })).toBeDisabled();
      await page.getByRole("button", { name: "Current request and preferences", exact: true }).click();
      await page.getByRole("button", { name: "Apply and research", exact: true }).click();
      await expect(message(page)).toHaveValue("SGD");
      assert.equal(submissions.length, 0);
      assert.equal((await stats(page)).calls, before.calls);
      release.release();
      await expect(page.getByRole("heading", { name: "What are you looking for?" })).toBeVisible();
      await expect(message(page)).toHaveValue("SGD");
      await expect(sendButton(page)).toBeEnabled();
      assert.equal(submissions.length, 0);
      await send(page, "hello");
      await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
      assert.equal((await stats(page)).calls, before.calls);
      result.providerCallDelta = 0;
      result.preferenceApplyClosesWithoutDispatch = true;
    } finally { release.release(); }
  });
  for (const outcome of ["success", "failure"]) await probe(`stale guest reset ${outcome} cannot clear signed-in reset readiness, draft or ownership`, async (result) => {
    const page = await pageFor();
    const guestEntered = gate(), guestRelease = gate(), accountEntered = gate(), accountRelease = gate();
    await send(page, "hello");
    await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
    await page.route("**/api/new-chat", async (route) => {
      const response = await route.fetch();
      guestEntered.release();
      await guestRelease.promise;
      await route.fulfill(outcome === "success" ? { response } : { status: 503, json: { error: "Fixture stale reset failure" } });
    });
    await newChat(page).click();
    await guestEntered.promise;
    try {
      await signUp(page);
      await send(page, "hello");
      await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
      await page.route("**/api/workspace", async (route) => {
        if (route.request().postDataJSON()?.phase !== "new-chat") return route.continue();
        const response = await route.fetch();
        accountEntered.release();
        await accountRelease.promise;
        await route.fulfill({ response });
      });
      await newChat(page).click();
      await accountEntered.promise;
      await message(page).fill("Fixture newer account draft");
      const oldResponse = page.waitForResponse((response) => response.url().endsWith("/api/new-chat"));
      guestRelease.release();
      await oldResponse;
      await expect(sendButton(page)).toBeDisabled();
      await expect(newChat(page)).toBeDisabled();
      await expect(message(page)).toHaveValue("Fixture newer account draft");
      await expect(page.getByText("The server could not start a new chat. Your history stays visible.", { exact: true })).toHaveCount(0);
      accountRelease.release();
      await expect(page.getByRole("heading", { name: "What are you looking for?" })).toBeVisible();
      await expect(sendButton(page)).toBeEnabled();
      await expect(message(page)).toHaveValue("Fixture newer account draft");
      await send(page, "hello");
      await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
      const account = await page.request.get(`${runtime.origin}/api/account`).then((response) => response.json());
      assert.equal(account.status, "signed-in");
      assert.equal(account.workspace.state.messages.some((entry) => entry.text === "hello"), true);
      result.accountOwnershipPreserved = true;
    } finally { guestRelease.release(); accountRelease.release(); }
  });
  await probe("failed current reset preserves new draft and history with no retry", async (result) => {
    const page = await pageFor();
    await send(page, "hello");
    await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
    const entered = gate(), release = gate();
    let attempts = 0;
    await page.route("**/api/new-chat", async (route) => { attempts++; entered.release(); await release.promise; await route.fulfill({ status: 503, json: { error: "Fixture reset failure" } }); });
    await newChat(page).click();
    await entered.promise;
    await message(page).fill("Fixture recovery draft");
    release.release();
    await expect(page.getByText("The server could not start a new chat. Your history stays visible.", { exact: true })).toBeVisible();
    await expect(message(page)).toHaveValue("Fixture recovery draft");
    await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
    await expect(sendButton(page)).toBeEnabled();
    assert.equal(attempts, 1);
    result.attempts = attempts;
  });
  await probe("late initial account reload cannot downgrade a newly signed-in workspace", async (result) => {
    const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
    contexts.push(context);
    const page = await context.newPage();
    await context.route("**/*", (route) => new URL(route.request().url()).origin === runtime.origin ? route.continue() : route.abort());
    const entered = gate(), release = gate();
    let accountReads = 0;
    await page.route("**/api/account", async (route) => {
      if (++accountReads !== 1) return route.continue();
      const response = await route.fetch();
      entered.release();
      await release.promise;
      await route.fulfill({ response });
    });
    await page.goto(runtime.origin);
    await entered.promise;
    try {
      await expect(newChat(page)).toBeEnabled();
      await send(page, "hello");
      await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
      await signUp(page);
      await expect(page.getByRole("heading", { name: "What are you looking for?" })).toBeVisible();
      await send(page, "thanks");
      const accountBefore = await page.request.get(`${runtime.origin}/api/account`).then((response) => response.json());
      assert.equal(accountBefore.status, "signed-in");
      await expect(page.getByText("thanks", { exact: true })).toBeVisible();
      await message(page).fill("Fixture signed-in draft during stale bootstrap");
      const oldResponse = page.waitForResponse((response) => response.url().endsWith("/api/account"));
      release.release();
      await oldResponse;
      await expect.poll(async () => page.request.get(`${runtime.origin}/api/account`).then((response) => response.json()).then((account) => account.status)).toBe("signed-in");
      await page.getByRole("button", { name: "Account", exact: true }).click();
      await page.screenshot({ path: `${root}/late-bootstrap-after-signin.png` });
      result.accountReads = accountReads;
      result.browserText = await page.locator("body").innerText();
      const account = await page.request.get(`${runtime.origin}/api/account`).then((response) => response.json());
      result.serverAccountStatus = account.status;
      result.serverMessages = account.workspace.state.messages.map((entry) => entry.text);
      result.calls = (await stats(page)).calls;
      await expect(page.getByText("Your saved conversation", { exact: true })).toBeVisible();
      await expect(page.getByText("thanks", { exact: true })).toBeVisible();
    } finally { release.release(); }
  });
  await probe("late Stop response cannot resurrect a guest conversation after New chat", async (result) => {
    const page = await pageFor();
    const before = await stats(page);
    const original = "I want a slow fixture powerbank under SGD40";
    await send(page, original);
    await expect.poll(async () => (await stats(page)).calls).toBe(before.calls + 1);
    const entered = gate(), release = gate();
    await page.route("**/api/cancel", async (route) => { const response = await route.fetch(); entered.release(); await release.promise; await route.fulfill({ response }); });
    await page.getByRole("button", { name: "Stop research", exact: true }).click();
    await entered.promise;
    try {
      await expect.poll(async () => (await stats(page)).closed).toBe(before.closed + 1);
      await newChat(page).click();
      await expect(page.getByRole("heading", { name: "What are you looking for?" })).toBeVisible();
      await send(page, "hello");
      await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
      await message(page).fill("Fixture draft after reset");
      const cancelResponse = page.waitForResponse((response) => response.url().endsWith("/api/cancel"));
      release.release();
      await cancelResponse;
      await expect(message(page)).toHaveValue("Fixture draft after reset");
      const server = await page.request.get(`${runtime.origin}/api/session`).then((response) => response.json());
      result.serverMessages = server.state.messages.map((entry) => entry.text);
      result.serverBudget = server.state.intent.budget;
      await page.screenshot({ path: `${root}/late-stop-after-reset.png` });
      result.browserText = await page.locator("main").innerText();
      result.stats = await stats(page);
      await expect(page.getByText(original, { exact: true })).toHaveCount(0);
      await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
    } finally { release.release(); }
  });
  await probe("late initial guest snapshot cannot replace a signed-in conversation", async (result) => {
    const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
    contexts.push(context);
    const page = await context.newPage();
    await context.route("**/*", (route) => new URL(route.request().url()).origin === runtime.origin ? route.continue() : route.abort());
    await page.request.get(`${runtime.origin}/api/session`);
    const entered = gate(), release = gate();
    let sessionReads = 0;
    await page.route("**/api/session", async (route) => {
      if (++sessionReads !== 1) return route.continue();
      const response = await route.fetch();
      entered.release();
      await release.promise;
      await route.fulfill({ response });
    });
    await page.goto(runtime.origin);
    await entered.promise;
    try {
      await expect(newChat(page)).toBeEnabled();
      await signUp(page);
      await expect(page.getByRole("heading", { name: "What are you looking for?" })).toBeVisible();
      await send(page, "thanks");
      await expect(page.getByText("thanks", { exact: true })).toBeVisible();
      const oldResponse = page.waitForResponse((response) => response.url().endsWith("/api/session"));
      release.release();
      await oldResponse;
      await page.getByRole("button", { name: "Account", exact: true }).click();
      await expect(page.getByText("Your saved conversation", { exact: true })).toBeVisible();
      await page.getByRole("button", { name: "Close", exact: true }).click();
      await page.screenshot({ path: `${root}/late-guest-bootstrap-after-signin.png` });
      result.browserText = await page.locator("main").innerText();
      const account = await page.request.get(`${runtime.origin}/api/account`).then((response) => response.json());
      result.serverAccountStatus = account.status;
      result.serverMessages = account.workspace.state.messages.map((entry) => entry.text);
      result.calls = (await stats(page)).calls;
      await expect(page.getByText("thanks", { exact: true })).toBeVisible();
    } finally { release.release(); }
  });
  await probe("late Stop response cannot replace a signed-in workspace with guest content", async (result) => {
    const page = await pageFor();
    const before = await stats(page);
    const original = "I want a slow fixture guest powerbank under SGD40";
    await send(page, original);
    await expect.poll(async () => (await stats(page)).calls).toBe(before.calls + 1);
    const entered = gate(), release = gate();
    let requests = 0;
    await page.route("**/api/cancel", async (route) => {
      if (++requests !== 1) return route.continue();
      const response = await route.fetch();
      entered.release();
      await release.promise;
      await route.fulfill({ response });
    });
    await page.getByRole("button", { name: "Stop research", exact: true }).click();
    await entered.promise;
    try {
      await expect.poll(async () => (await stats(page)).closed).toBe(before.closed + 1);
      await signUp(page);
      await expect(page.getByRole("heading", { name: "What are you looking for?" })).toBeVisible();
      await send(page, "hello");
      await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
      await message(page).fill("Fixture signed-in draft");
      const cancelResponse = page.waitForResponse((response) => response.url().endsWith("/api/cancel"));
      release.release();
      await cancelResponse;
      await expect(message(page)).toHaveValue("Fixture signed-in draft");
      const account = await page.request.get(`${runtime.origin}/api/account`).then((response) => response.json());
      result.accountStatus = account.status;
      result.serverMessages = account.workspace.state.messages.map((entry) => entry.text);
      result.serverBudget = account.workspace.state.intent.budget;
      await page.screenshot({ path: `${root}/late-stop-after-signin.png` });
      result.browserText = await page.locator("main").innerText();
      result.stats = await stats(page);
      await expect(page.getByText(original, { exact: true })).toHaveCount(0);
      await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
    } finally { release.release(); }
  });
} finally {
  for (const context of contexts) await context.close();
  await browser.close();
  await runtime.close();
  proof.cleanup = true;
  await writeFile(proofPath, JSON.stringify(proof, null, 2));
}
console.log(JSON.stringify(proof, null, 2));
if (proof.probes.some((entry) => entry.status !== "passed")) process.exitCode = 1;
