import { mkdir, writeFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { chromium } from "@playwright/test";
const root = "artifacts/fieldnote-v4/issue60/green/account-diagnostic";
await mkdir(root, { recursive: true });
const proof = { head: execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(), fixtureOnly: true, status: "running", pages: [], browserClosed: false };
const launch = chromium.launch.bind(chromium);
let ownedBrowser;
chromium.launch = async (...args) => {
  const browser = await launch(...args);
  ownedBrowser = browser;
  const newContext = browser.newContext.bind(browser);
  browser.newContext = async (...contextArgs) => {
    const context = await newContext(...contextArgs);
    const pages = new Map();
    context.on("page", (page) => {
      const entry = { index: proof.pages.length, events: [] };
      proof.pages.push(entry);
      pages.set(page, entry);
      const record = (value) => { if (entry.events.length < 40) entry.events.push(String(value).slice(0, 2000)); };
      page.on("pageerror", (error) => record(`pageerror ${error}`));
      page.on("console", (event) => { if (event.type() === "error") record(`console ${event.text()}`); });
      page.on("requestfailed", (request) => record(`requestfailed ${request.url()} ${request.failure()?.errorText}`));
      page.on("response", (response) => { if (response.status() >= 400) record(`http ${response.status()} ${response.url()}`); });
    });
    const close = context.close.bind(context);
    context.close = async (...closeArgs) => {
      for (const [page, entry] of pages) if (!page.isClosed()) {
        entry.url = page.url();
        entry.body = (await page.locator("body").innerText().catch(String)).slice(0, 6000);
        await page.screenshot({ path: `${root}/context-${entry.index}.png` }).catch((error) => { entry.captureError = String(error); });
      }
      return close(...closeArgs);
    };
    return context;
  };
  return browser;
};
try {
  await import("../../../scripts/verify-personalization-browser.mjs");
  proof.status = "passed";
} catch (error) {
  proof.status = "failed";
  proof.error = String(error);
  process.exitCode = 1;
} finally {
  proof.browserClosed = !ownedBrowser?.isConnected();
  await writeFile(`${root}/proof.json`, JSON.stringify(proof, null, 2));
}
