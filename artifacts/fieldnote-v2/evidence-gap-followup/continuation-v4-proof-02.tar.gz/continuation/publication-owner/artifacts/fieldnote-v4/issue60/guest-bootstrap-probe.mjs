import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { writeFile } from "node:fs/promises";
import { chromium, expect } from "@playwright/test";
import { accountRuntime } from "../../../scripts/account-test-runtime.mjs";
const root = process.env.FIELDNOTE_SECURITY_ARTIFACT_DIR ?? "artifacts/fieldnote-v4/issue60/green";
const runtime = await accountRuntime({ web: true });
const browser = await chromium.launch();
const context = await browser.newContext();
const page = await context.newPage();
const proof = { head: execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(), fixtureOnly: true, status: "running", cleanup: false };
let release;
const gate = new Promise((resolve) => { release = resolve; });
let entered;
const held = new Promise((resolve) => { entered = resolve; });
let count = 0;
try {
  await page.route("**/api/session", async (route) => {
    if (++count !== 1) return route.continue();
    const response = await route.fetch();
    entered();
    await gate;
    await route.fulfill({ response });
  });
  await page.goto(runtime.origin);
  await held;
  await expect(page.getByRole("button", { name: "New chat", exact: true })).toBeEnabled();
  const composer = page.getByRole("textbox", { name: "Message", exact: true });
  await composer.fill("hello");
  await page.getByRole("button", { name: "Send message", exact: true }).click();
  await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  const response = page.waitForResponse((response) => response.url().endsWith("/api/session"));
  release();
  await (await response).finished();
  proof.server = await page.request.get(`${runtime.origin}/api/session`).then((response) => response.json());
  proof.stats = await page.request.get(`${runtime.origin}/api/test-stats`).then((response) => response.json());
  await page.screenshot({ path: `${root}/late-guest-bootstrap-after-hello.png` });
  proof.browserText = await page.locator("main").innerText();
  assert.equal(proof.stats.calls, 0);
  await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  proof.status = "passed";
} catch (error) { proof.status = "failed"; proof.error = String(error); }
finally {
  release();
  await context.close();
  await browser.close();
  await runtime.close();
  proof.cleanup = true;
  await writeFile(`${root}/late-guest-bootstrap-after-hello.json`, JSON.stringify(proof, null, 2));
}
if (proof.status !== "passed") process.exitCode = 1;
