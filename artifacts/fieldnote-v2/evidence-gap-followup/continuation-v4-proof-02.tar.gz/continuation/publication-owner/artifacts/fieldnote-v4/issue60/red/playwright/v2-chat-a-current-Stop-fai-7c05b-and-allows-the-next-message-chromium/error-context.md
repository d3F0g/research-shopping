# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v2-chat.spec.ts >> a current Stop failure preserves accepted context and allows the next message
- Location: tests/e2e/v2-chat.spec.ts:420:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('SGD 40', { exact: true })
Expected: visible
Timeout: 6000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('SGD 40', { exact: true }) with timeout 6000ms
  - waiting for getByText('SGD 40', { exact: true })

```

```yaml
- banner:
  - text: Fieldnote
  - button "Account"
  - button "Switch to light mode"
  - button "New chat"
- main:
  - region "Messages":
    - log:
      - paragraph: I want a slow fixture powerbank under SGD40
      - button "Current request and preferences"
      - alert: The server could not confirm cancellation. No automatic retry was sent.
  - button "Scroll to end"
  - group:
    - textbox "Message":
      - /placeholder: Describe what you want to buy…
      - text: Fixture draft during Stop
    - group:
      - text: SGD 0–40
      - button "Send message"
  - paragraph: Shopping submissions can trigger a paid Exa call. Viewing existing evidence is free.
```

# Test source

```ts
  339 |   await send.click();
  340 |   await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  341 |   let release!: () => void;
  342 |   let entered!: () => void;
  343 |   let attempts = 0;
  344 |   const held = new Promise<void>((resolve) => { entered = resolve; });
  345 |   const gate = new Promise<void>((resolve) => { release = resolve; });
  346 |   await page.route("**/api/new-chat", async (route) => {
  347 |     attempts++;
  348 |     entered();
  349 |     await gate;
  350 |     await route.fulfill({ status: 503, json: { error: "Fixture reset unavailable" } });
  351 |   });
  352 |   await page.getByRole("button", { name: "New chat", exact: true }).click();
  353 |   await held;
  354 |   try {
  355 |     await composer.fill("Fixture draft after failed reset");
  356 |     await expect(send).toBeDisabled();
  357 |     release();
  358 |     await expect(page.getByText("The server could not start a new chat. Your history stays visible.", { exact: true })).toBeVisible();
  359 |     await expect(composer).toHaveValue("Fixture draft after failed reset");
  360 |     await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  361 |     await expect(send).toBeEnabled();
  362 |     expect(attempts).toBe(1);
  363 |   } finally {
  364 |     release();
  365 |   }
  366 | });
  367 | 
  368 | for (const outcome of ["success", "failure"]) {
  369 |   test(`a late Stop ${outcome} preserves the new chat and draft`, async ({ page }) => {
  370 |     await page.goto("/");
  371 |     const composer = page.getByRole("textbox", { name: "Message", exact: true });
  372 |     const send = page.getByRole("button", { name: "Send message", exact: true });
  373 |     const calls = async () => (await page.request.get("/api/test-stats").then((response) => response.json())).calls as number;
  374 |     const baseline = await calls();
  375 |     const original = "I want a slow fixture powerbank under SGD40";
  376 |     await composer.fill(original);
  377 |     await send.click();
  378 |     await expect.poll(calls).toBe(baseline + 1);
  379 |     let release!: () => void;
  380 |     let entered!: () => void;
  381 |     const held = new Promise<void>((resolve) => { entered = resolve; });
  382 |     const gate = new Promise<void>((resolve) => { release = resolve; });
  383 |     await page.route("**/api/cancel", async (route) => {
  384 |       const response = await route.fetch();
  385 |       entered();
  386 |       await gate;
  387 |       await route.fulfill(outcome === "success" ? { response } : { status: 503, json: { error: "Fixture cancellation unavailable" } });
  388 |     });
  389 |     await page.getByRole("button", { name: "Stop research", exact: true }).click();
  390 |     await held;
  391 |     try {
  392 |       await page.getByRole("button", { name: "New chat", exact: true }).click();
  393 |       await expect(page.getByRole("heading", { name: "What are you looking for?" })).toBeVisible();
  394 |       await composer.fill("hello");
  395 |       await send.click();
  396 |       await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  397 |       await composer.fill("Fixture draft after Stop and New chat");
  398 |       const pendingResponse = page.waitForResponse((response) => response.url().endsWith("/api/cancel"));
  399 |       release();
  400 |       await (await pendingResponse).finished();
  401 |       const current = await page.request.get("/api/session").then((response) => response.json());
  402 |       expect(current.state.intent.budget).toBeNull();
  403 |       expect(current.state.messages.some((message: { text: string }) => message.text === "hello")).toBe(true);
  404 |       await expect(page.getByText(original, { exact: true })).toHaveCount(0);
  405 |       await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  406 |       await expect(page.getByText("The server could not confirm cancellation. No automatic retry was sent.", { exact: true })).toHaveCount(0);
  407 |       await expect(composer).toHaveValue("Fixture draft after Stop and New chat");
  408 |       await expect(send).toBeEnabled();
  409 |       expect(await calls()).toBe(baseline + 1);
  410 |       await composer.fill("thanks");
  411 |       await send.click();
  412 |       await expect(page.getByText("thanks", { exact: true })).toBeVisible();
  413 |       expect(await calls()).toBe(baseline + 1);
  414 |     } finally {
  415 |       release();
  416 |     }
  417 |   });
  418 | }
  419 | 
  420 | test("a current Stop failure preserves accepted context and allows the next message", async ({ page }) => {
  421 |   await page.goto("/");
  422 |   const composer = page.getByRole("textbox", { name: "Message", exact: true });
  423 |   const send = page.getByRole("button", { name: "Send message", exact: true });
  424 |   const calls = async () => (await page.request.get("/api/test-stats").then((response) => response.json())).calls as number;
  425 |   const baseline = await calls();
  426 |   await composer.fill("I want a slow fixture powerbank under SGD40");
  427 |   await send.click();
  428 |   await expect.poll(calls).toBe(baseline + 1);
  429 |   let attempts = 0;
  430 |   await page.route("**/api/cancel", async (route) => {
  431 |     attempts++;
  432 |     await route.fetch();
  433 |     await route.fulfill({ status: 503, json: { error: "Fixture cancellation unavailable" } });
  434 |   });
  435 |   await composer.fill("Fixture draft during Stop");
  436 |   await page.getByRole("button", { name: "Stop research", exact: true }).click();
  437 |   await expect(page.getByText("The server could not confirm cancellation. No automatic retry was sent.", { exact: true })).toBeVisible();
  438 |   await expect(composer).toHaveValue("Fixture draft during Stop");
> 439 |   await expect(page.getByText("SGD 40", { exact: true })).toBeVisible();
      |                                                           ^ Error: expect(locator).toBeVisible() failed
  440 |   expect(attempts).toBe(1);
  441 |   await composer.fill("hello");
  442 |   await send.click();
  443 |   await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  444 |   await expect(page.getByText("The server could not confirm cancellation. No automatic retry was sent.", { exact: true })).toHaveCount(0);
  445 |   expect(await calls()).toBe(baseline + 1);
  446 |   const current = await page.request.get("/api/session").then((response) => response.json());
  447 |   expect(current.state.intent.budget).toMatchObject({ maximum: 40, currency: "SGD" });
  448 | });
  449 | 
```