import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { writeFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { chromium, expect } from "@playwright/test";
import { accountRuntime } from "../../scripts/account-test-runtime.mjs";

const order = process.argv[2] ?? "abort-first";
const runtime = await accountRuntime({ web: true });
const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
const page = await context.newPage();
page.setDefaultTimeout(15000);
const proof = { source: execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(), order, events: [], cleanup: false };
let release = () => {};
try {
  process.stdout.write("Fixture browser created.\n");
  await page.goto(runtime.origin);
  process.stdout.write("Fixture page loaded.\n");
  await page.getByRole("button", { name: "Account", exact: true }).click();
  await page.getByRole("button", { name: "Create an account", exact: true }).click();
  await page.getByRole("textbox", { name: "Name", exact: true }).fill("Fixture shopper");
  await page.getByRole("textbox", { name: "Email", exact: true }).fill(`fixture-issue63-${randomUUID()}@example.test`);
  await page.getByLabel("Password", { exact: true }).fill("fixture-browser-password-only");
  await page.getByRole("button", { name: "Create account", exact: true }).click();
  await expect(page.getByRole("dialog")).toHaveCount(0);
  process.stdout.write("Fixture account dialog closed.\n");
  const account = async () => {
    const response = await page.request.get(`${runtime.origin}/api/account`);
    assert.equal(response.status(), 200);
    return response.json();
  };
  const stats = () => page.request.get(`${runtime.origin}/api/test-stats`).then((response) => response.json());
  const before = await stats();
  let entered;
  const held = new Promise((resolve) => { entered = resolve; });
  const gate = new Promise((resolve) => { release = resolve; });
  let cancelled;
  await page.route("**/api/workspace", async (route) => {
    const command = route.request().postDataJSON();
    proof.events.push({ event: "command", phase: command.phase, revision: command.revision });
    process.stdout.write(`Fixture command ${command.phase} at revision ${command.revision}.\n`);
    if (command.phase === "research" && order === "cancel-first") {
      const response = await route.fetch();
      proof.events.push({ event: "research-response", status: response.status(), body: await response.json() });
      await route.fulfill({ response });
      return;
    }
    if (command.phase !== "cancel") return route.continue();
    if (order === "abort-first") {
      await expect.poll(async () => (await stats()).closed).toBe(before.closed + 1);
      await expect.poll(async () => (await account()).workspace.pendingOperationId).toBe(null);
      proof.events.push({ event: "settled-before-cancel", account: await account() });
    }
    const response = await route.fetch();
    cancelled = await response.json();
    proof.cancel = { status: response.status(), keys: Object.keys(cancelled), body: cancelled };
    process.stdout.write(`Fixture cancel response ${JSON.stringify(proof.cancel)}.\n`);
    proof.events.push({ event: "cancel-response", status: response.status() });
    entered();
    await gate;
    await route.fulfill({ response });
  });
  await page.getByRole("textbox", { name: "Message", exact: true }).fill("I want a slow fixture powerbank between SGD30 and40");
  await page.getByRole("button", { name: "Send message", exact: true }).click();
  await expect.poll(async () => (await stats()).calls).toBe(before.calls + 1);
  process.stdout.write("Fixture SDK request open.\n");
  proof.beforeStop = await account();
  await page.getByRole("button", { name: "Stop research", exact: true }).click();
  process.stdout.write("Fixture Stop clicked.\n");
  await expect.poll(() => proof.cancel?.status).toBeDefined();
  await held;
  await expect.poll(async () => (await stats()).closed).toBe(before.closed + 1);
  await expect.poll(async () => (await account()).workspace.pendingOperationId).toBe(null);
  proof.afterCancel = await account();
  process.stdout.write(`Fixture authoritative baseline ${JSON.stringify(proof.afterCancel)}.\n`);
  const resetResponse = page.waitForResponse((response) => response.url().endsWith("/api/workspace") && response.request().postDataJSON()?.phase === "new-chat");
  await page.getByRole("button", { name: "New chat", exact: true }).click();
  const reset = await resetResponse;
  process.stdout.write(`Fixture reset status ${reset.status()}.\n`);
  proof.reset = { status: reset.status() };
  proof.afterReset = await account();
  proof.stats = await stats();
  await writeFile(`artifacts/issue63/${order}-before-assertion.json`, JSON.stringify(proof, null, 2) + "\n");
  process.stdout.write("Fixture proof captured.\n");
  await page.screenshot({ path: `artifacts/issue63/${order}-before-assertion.png` });
  assert.equal(reset.status(), 409);
  assert.deepEqual(proof.afterReset.workspace, cancelled.workspace);
  proof.result = "passed";
} catch (error) {
  process.stdout.write(`Fixture failure ${error.stack}.\n`);
  proof.result = "failed";
  proof.error = { message: error.message, stack: error.stack };
  process.exitCode = 1;
} finally {
  release();
  process.stdout.write("Fixture gate released.\n");
  await context.close();
  process.stdout.write("Fixture context closed.\n");
  await browser.close();
  process.stdout.write("Fixture browser closed.\n");
  proof.runtimeDiagnostics = runtime.diagnostics();
  await runtime.close();
  process.stdout.write("Fixture runtime closed.\n");
  proof.cleanup = true;
  await writeFile(`artifacts/issue63/${order}-red.json`, JSON.stringify(proof, null, 2) + "\n");
  process.stdout.write(JSON.stringify({ order, cancelStatus: proof.cancel?.status, cancelKeys: proof.cancel?.keys, resetStatus: proof.reset?.status, result: proof.result, cleanup: proof.cleanup }) + "\n");
}
