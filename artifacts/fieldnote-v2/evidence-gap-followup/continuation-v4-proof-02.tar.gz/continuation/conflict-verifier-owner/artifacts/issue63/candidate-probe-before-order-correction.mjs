import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import { chromium, expect } from "@playwright/test";
import { accountRuntime } from "../../scripts/account-test-runtime.mjs";
const browser = await chromium.launch();
const proof = [];
await mkdir("artifacts/fieldnote-v2/accounts", { recursive: true });
async function authenticate(page, email, register) {
  await page.getByRole("button", { name: "Account", exact: true }).click();
  if (register)
    await page
      .getByRole("button", { name: "Create an account", exact: true })
      .click();
  if (register)
    await page
      .getByRole("textbox", { name: "Name", exact: true })
      .fill("Fixture shopper");
  await page.getByRole("textbox", { name: "Email", exact: true }).fill(email);
  await page
    .getByLabel("Password", { exact: true })
    .fill("fixture-browser-password-only");
  const response = page.waitForResponse((result) => result.url().endsWith(`/api/auth/${register ? "sign-up" : "sign-in"}/email`));
  await page
    .getByRole("button", {
      name: register ? "Create account" : "Sign in",
      exact: true,
    })
    .click();
  const result = await response;
  assert.equal(result.ok(), true, `Fixture authentication returned ${result.status()}`);
  await expect(page.getByRole("dialog")).toHaveCount(0);
}
const send = async (page, text) => {
  await page.getByRole("textbox", { name: "Message", exact: true }).fill(text);
  await page.getByRole("button", { name: "Send message", exact: true }).click();
};
const mode = process.argv[2];
const size = { name: `probe-${mode}`, width: 1440, height: 1000 };
const result = { mode, sourceSha256: "032af098e46b554e06d6558d1a8cd56d6d5e3a610c80dbdae7bb1bd270a38d3d", status: "running", cleanup: false };
try {
    {
      const conflictRuntime = await accountRuntime({ web: true });
      const context = await browser.newContext({ viewport: size });
      let release = () => {};
      try {
        const page = await context.newPage();
        await page.goto(conflictRuntime.origin);
        await authenticate(page, `fixture-conflict-${randomUUID()}@example.test`, true);
        const stats = () => page.request.get(`${conflictRuntime.origin}/api/test-stats`).then((response) => response.json());
        const before = await stats();
        const original = "I want a slow fixture powerbank between SGD30 and40";
        await send(page, original);
        await expect.poll(async () => (await stats()).calls).toBe(before.calls + 1);
        const beforeStop = await page.request.get(`${conflictRuntime.origin}/api/account`).then((response) => response.json());
        let entered;
        let cancelled;
        let cancelStatus;
        let cancelCommand;
        const held = new Promise((resolve) => { entered = resolve; });
        const gate = new Promise((resolve) => { release = resolve; });
        await page.route("**/api/workspace", async (route) => {
          const phase = route.request().postDataJSON()?.phase;
          if (phase === "research" && mode === "cancel-first") {
            const response = await route.fetch();
            await route.fulfill({ response });
            return;
          }
          if (phase !== "cancel") return route.continue();
          if (mode === "abort-first") {
            await expect.poll(async () => (await stats()).closed).toBe(before.closed + 1);
            await expect.poll(async () => (await page.request.get(`${conflictRuntime.origin}/api/account`).then((response) => response.json())).workspace.pendingOperationId).toBe(null);
          }
          cancelCommand = route.request().postDataJSON();
          const response = await route.fetch();
          cancelStatus = mode === "unexpected-401" ? 401 : mode === "unexpected-500" ? 500 : mode === "unexpected-409-shape" ? 409 : response.status();
          cancelled = await response.json();
          if (mode === "unexpected-409-shape") cancelled = { error: "Fixture wrong conflict shape" };
          entered();
          await gate;
          await route.fulfill({ response });
        });
        await page.getByRole("button", { name: "Stop research", exact: true }).click();
        await held;
        const cancellation = {
          status: cancelStatus,
          bodyKeys: Object.keys(cancelled ?? {}).slice(0, 10),
          error: typeof cancelled?.error === "string" ? cancelled.error.slice(0, 200) : null,
          submittedRevision: cancelCommand.revision,
        };
        await writeFile(`artifacts/fieldnote-v2/accounts/${size.name}-stop-cancel-response.json`, JSON.stringify(cancellation, null, 2) + "\n");
        assert.ok(cancelStatus === 200 || cancelStatus === 409, `Unexpected cancellation response ${JSON.stringify(cancellation)}`);
        if (cancelStatus === 409)
          assert.deepEqual(cancelled, { error: "Saved conversation changed. Reload it before continuing." });
        else {
          assert.deepEqual(Object.keys(cancelled).sort(), ["operation", "response", "workspace"]);
          assert.equal(cancelled.response, null);
          assert.deepEqual(cancelled.operation, { operationId: cancelCommand.operationId, status: "complete" });
        }
        await expect.poll(async () => (await stats()).closed).toBe(before.closed + 1);
        await expect.poll(async () => (await page.request.get(`${conflictRuntime.origin}/api/account`).then((response) => response.json())).workspace.pendingOperationId).toBe(null);
        const afterCancel = await page.request.get(`${conflictRuntime.origin}/api/account`).then((response) => response.json());
        assert.equal(afterCancel.status, "signed-in");
        assert.deepEqual(afterCancel.user, beforeStop.user);
        assert.equal(cancelCommand.revision, beforeStop.workspace.revision);
        assert.equal(cancelCommand.target, beforeStop.workspace.pendingOperationId);
        assert.equal(afterCancel.workspace.revision, beforeStop.workspace.revision + 1);
        assert.equal(afterCancel.workspace.epoch, beforeStop.workspace.epoch + Number(cancelStatus === 200));
        assert.equal(afterCancel.workspace.pendingPreparedId, null);
        assert.deepEqual(afterCancel.workspace.state.intent, beforeStop.workspace.state.intent);
        if (cancelStatus === 200) {
          assert.deepEqual(afterCancel.workspace, cancelled.workspace);
          assert.deepEqual(afterCancel.workspace.state, beforeStop.workspace.state);
        } else {
          assert.deepEqual(afterCancel.workspace.state.messages.slice(0, -1), beforeStop.workspace.state.messages);
          assert.equal(afterCancel.workspace.state.messages.at(-1)?.text, "Research stopped. Your preferences are retained.");
        }
        const resetResponse = page.waitForResponse((response) => response.url().endsWith("/api/workspace") && response.request().postDataJSON()?.phase === "new-chat");
        await page.getByRole("button", { name: "New chat", exact: true }).click();
        assert.equal((await resetResponse).status(), 409);
        await expect(page.getByText("The server could not start a new chat. Your history stays visible.", { exact: true })).toBeVisible();
        const composer = page.getByRole("textbox", { name: "Message", exact: true });
        await composer.fill("Fixture draft during workspace conflict");
        const current = await page.request.get(`${conflictRuntime.origin}/api/account`).then((response) => response.json());
        assert.deepEqual(current, afterCancel);
        assert.deepEqual(current.workspace.state.intent.budget, { minimum: 30, maximum: 40, currency: "SGD" });
        assert.equal(current.workspace.state.messages.some((message) => message.research), false);
        await expect(page.getByText(original, { exact: true })).toBeVisible();
        assert.equal((await stats()).calls, before.calls + 1);
        await page.screenshot({ path: `artifacts/fieldnote-v2/accounts/${size.name}-stop-reset-conflict.png` });
        const pendingResponse = page.waitForResponse((response) => response.url().endsWith("/api/workspace") && response.request().postDataJSON()?.phase === "cancel");
        release();
        const deliveredCancellation = await pendingResponse;
        assert.equal(deliveredCancellation.status(), cancelStatus);
        if (cancelStatus === 200) await deliveredCancellation.finished();
        else {
          result.rejectedResponseFinished = false;
          void deliveredCancellation.finished().then(() => { result.rejectedResponseFinished = true; }, (error) => { result.rejectedResponseFinishError = error.message; });
        }
        await expect(composer).toHaveValue("Fixture draft during workspace conflict");
        await expect(page.getByText("The server could not start a new chat. Your history stays visible.", { exact: true })).toBeVisible();
        assert.deepEqual(await page.request.get(`${conflictRuntime.origin}/api/account`).then((response) => response.json()), afterCancel);
        await page.reload();
        await expect(page.getByRole("button", { name: "New chat", exact: true })).toBeEnabled();
        await page.getByRole("button", { name: "New chat", exact: true }).click();
        await expect(page.getByRole("heading", { name: "What are you looking for?" })).toBeVisible();
        await send(page, "hello");
        await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
        const recovered = await page.request.get(`${conflictRuntime.origin}/api/account`).then((response) => response.json());
        assert.deepEqual(recovered.user, afterCancel.user);
        assert.equal(recovered.workspace.state.intent.budget, null);
        assert.equal((await stats()).calls, before.calls + 1);
        assert.equal((await stats()).closed, before.closed + 1);
        await page.screenshot({ path: `artifacts/fieldnote-v2/accounts/${size.name}-stop-reset-conflict-recovered.png` });
        proof.push(`${size.name} signed-in Stop returns ${cancelStatus}. New chat before cancellation confirmation reports a 409 conflict without constraint mutation or extra SDK calls. Explicit browser refresh then New chat recovers. The signed-in Account sheet has no reload control.`);
      } finally {
        release();
        await context.close();
        await conflictRuntime.close();
      }
    }

  result.status = "passed";
} catch (error) {
  result.status = "failed";
  result.error = { message: error.message, stack: error.stack };
  process.exitCode = 1;
} finally {
  await browser.close();
  result.cleanup = true;
  result.proof = proof;
  await writeFile(`artifacts/issue63/candidate-${mode}.json`, JSON.stringify(result, null, 2) + "\n");
  process.stdout.write(JSON.stringify(result) + "\n");
}
