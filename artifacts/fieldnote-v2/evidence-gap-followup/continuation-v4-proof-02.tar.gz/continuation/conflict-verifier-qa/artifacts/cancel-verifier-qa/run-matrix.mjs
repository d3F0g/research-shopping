import { chromium } from '@playwright/test';
import { appendFile, writeFile } from 'node:fs/promises';
const logs = [];
const output = 'artifacts/cancel-verifier-qa';
const original = chromium.launch.bind(chromium);
chromium.launch = async (...args) => {
 const browser = await original(...args);
 const newContext = browser.newContext.bind(browser);
 browser.newContext = async (...contextArgs) => {
  const context = await newContext(...contextArgs);
  context.on('page', page => {
   page.on('requestfailed', request => logs.push({kind:'requestfailed',url:request.url(),failure:request.failure()}));
   page.on('pageerror', error => logs.push({kind:'pageerror',message:error.message}));
   page.on('response', response => {if(response.status() >= 400) logs.push({kind:'http-error',url:response.url(),status:response.status()});});
  });
  return context;
 };
 const close = browser.close.bind(browser);
 browser.close = async (...closeArgs) => {
  let index=0;
  for(const context of browser.contexts()) for(const page of context.pages()) {
   await page.screenshot({path:`${output}/closing-${index++}.png`}).catch(()=>{});
  }
  await writeFile(`${output}/browser-diagnostics.json`,JSON.stringify(logs,null,2)+'\n');
  return close(...closeArgs);
 };
 return browser;
};
try {await import('../../scripts/verify-personalization-browser.mjs');}
catch(error) {await writeFile(`${output}/failure.txt`,String(error.stack)+'\n'); throw error;}
