import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {chromium,expect} from '/Users/josiahwong/Documents/research-shopping-v4-integration/node_modules/@playwright/test/index.mjs';
import {accountRuntime} from '/Users/josiahwong/Documents/research-shopping-v4-integration/scripts/account-test-runtime.mjs';
const runtime=await accountRuntime({web:true});
const browser=await chromium.launch();
const dir='/tmp/fieldnote-new-chat-draft-repro';await mkdir(dir,{recursive:true});
try {
 const page=await browser.newPage();
 await Promise.all([page.waitForResponse(r=>r.url()===runtime.origin+'/api/account'&&r.request().method()==='GET'),page.goto(runtime.origin)]);
 const input=page.getByRole('textbox',{name:'Message',exact:true});
 await input.fill('Fixture old draft.');
 await expect(page.getByRole('button',{name:'Send message',exact:true})).toBeEnabled();
 let release,entered;const gate=new Promise(r=>release=r),held=new Promise(r=>entered=r);
 await page.route('**/api/new-chat',async route=>{entered();await gate;await route.continue();});
 await page.getByRole('button',{name:'New chat',exact:true}).click();await held;
 const editable=await input.isEditable();await input.fill('Fixture newly typed draft.');
 const before=await input.inputValue();assert.equal(before,'Fixture newly typed draft.');
 await page.screenshot({path:dir+'/before-response.png'});
 const response=page.waitForResponse(r=>r.url()===runtime.origin+'/api/new-chat');release();await response;
 await expect(input).toHaveValue('');await page.screenshot({path:dir+'/after-response.png'});
 await writeFile(dir+'/proof.json',JSON.stringify({status:'reproduced',source:'9e902bb388bda3bf1b1f6df033208b02faf51a8f',editableWhileResetPending:editable,draftBeforeResponse:before,draftAfterResponse:await input.inputValue(),paidCalls:0,scope:'Wholly synthetic unsent draft; owned local API and PostgreSQL only.'},null,2)+'\n');
 console.log('Reproduced newly typed draft erased by delayed New chat response.');
} finally {await browser.close();await runtime.close();}
