# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v2-chat.spec.ts >> a stale session bootstrap success preserves a newer ordinary guest reply
- Location: tests/e2e/v2-chat.spec.ts:477:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Hi. What are you looking to buy?', { exact: true })
Expected: visible
Timeout: 6000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Hi. What are you looking to buy?', { exact: true }) with timeout 6000ms
  - waiting for getByText('Hi. What are you looking to buy?', { exact: true })

```

```yaml
- banner:
  - text: Fieldnote
  - button "Account"
  - button "Switch to light mode"
  - button "New chat"
- main:
  - region "Messages":
    - log:
      - heading "What are you looking for?" [level=1]
  - button "Scroll to end"
  - group:
    - textbox "Message":
      - /placeholder: Describe what you want to buy…
      - text: Fixture draft after guest reply
    - group:
      - button "Send message"
  - paragraph: Shopping submissions can trigger a paid Exa call. Viewing existing evidence is free.
```

# Test source

```ts
  406 |       await expect(page.getByText("The server could not confirm cancellation. No automatic retry was sent.", { exact: true })).toHaveCount(0);
  407 |       await expect(composer).toHaveValue("Fixture draft after Stop and New chat");
  408 |       await expect(send).toBeEnabled();
  409 |       expect(await calls()).toBe(baseline + 1);
  410 |       await composer.fill("thanks");
  411 |       await send.click();
  412 |       await expect(page.getByText("thanks", { exact: true })).toBeVisible();
  413 |       expect(await calls()).toBe(baseline + 1);
  414 |     } finally {
  415 |       release();
  416 |     }
  417 |   });
  418 | }
  419 | 
  420 | test("a current Stop failure preserves accepted context and allows the next message", async ({ page }) => {
  421 |   await page.goto("/");
  422 |   const composer = page.getByRole("textbox", { name: "Message", exact: true });
  423 |   const send = page.getByRole("button", { name: "Send message", exact: true });
  424 |   const calls = async () => (await page.request.get("/api/test-stats").then((response) => response.json())).calls as number;
  425 |   const baseline = await calls();
  426 |   await composer.fill("I want a slow fixture powerbank under SGD40");
  427 |   await send.click();
  428 |   await expect.poll(calls).toBe(baseline + 1);
  429 |   let attempts = 0;
  430 |   await page.route("**/api/cancel", async (route) => {
  431 |     attempts++;
  432 |     await route.fetch();
  433 |     await route.fulfill({ status: 503, json: { error: "Fixture cancellation unavailable" } });
  434 |   });
  435 |   await composer.fill("Fixture draft during Stop");
  436 |   await page.getByRole("button", { name: "Stop research", exact: true }).click();
  437 |   await expect(page.getByText("The server could not confirm cancellation. No automatic retry was sent.", { exact: true })).toBeVisible();
  438 |   await expect(composer).toHaveValue("Fixture draft during Stop");
  439 |   await expect(page.getByText("SGD 0–40", { exact: true })).toBeVisible();
  440 |   expect(attempts).toBe(1);
  441 |   await composer.fill("hello");
  442 |   await send.click();
  443 |   await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  444 |   await expect(page.getByText("The server could not confirm cancellation. No automatic retry was sent.", { exact: true })).toHaveCount(0);
  445 |   expect(await calls()).toBe(baseline + 1);
  446 |   const current = await page.request.get("/api/session").then((response) => response.json());
  447 |   expect(current.state.intent.budget).toMatchObject({ maximum: 40, currency: "SGD" });
  448 | });
  449 | 
  450 | for (const endpoint of ["account", "session"]) {
  451 |   test(`a current ${endpoint} reload failure retains the draft and supports explicit recovery`, async ({ page }) => {
  452 |     await page.route(`**/api/${endpoint}`, (route) => route.fulfill({ status: 503, json: { error: "Fixture bootstrap unavailable" } }));
  453 |     await page.goto("/");
  454 |     await expect(page.getByText("The server is unavailable. Your draft is retained. Reload your account when it returns.", { exact: true })).toBeVisible();
  455 |     const baseline = (await page.request.get("/api/test-stats").then((response) => response.json())).calls;
  456 |     const composer = page.getByRole("textbox", { name: "Message", exact: true });
  457 |     const send = page.getByRole("button", { name: "Send message", exact: true });
  458 |     await composer.fill("Fixture draft during unavailable account");
  459 |     await expect(send).toBeDisabled();
  460 |     await page.unroute(`**/api/${endpoint}`);
  461 |     await page.getByRole("button", { name: "Account", exact: true }).click();
  462 |     await page.getByRole("button", { name: "Reload account", exact: true }).click();
  463 |     await expect(page.getByText("Accounts are not configured.", { exact: false })).toBeVisible();
  464 |     await page.getByRole("button", { name: "Close", exact: true }).click();
  465 |     await expect(composer).toHaveValue("Fixture draft during unavailable account");
  466 |     await expect(send).toBeEnabled();
  467 |     await expect(page.getByRole("alert")).toHaveCount(0);
  468 |     await composer.fill("hello");
  469 |     await send.click();
  470 |     await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  471 |     expect((await page.request.get("/api/test-stats").then((response) => response.json())).calls).toBe(baseline);
  472 |   });
  473 | }
  474 | 
  475 | for (const endpoint of ["account", "session"]) {
  476 |   for (const outcome of ["success", "failure"]) {
  477 |     test(`a stale ${endpoint} bootstrap ${outcome} preserves a newer ordinary guest reply`, async ({ page }) => {
  478 |       let release!: () => void;
  479 |       let entered!: () => void;
  480 |       let requests = 0;
  481 |       const held = new Promise<void>((resolve) => { entered = resolve; });
  482 |       const gate = new Promise<void>((resolve) => { release = resolve; });
  483 |       await page.route(`**/api/${endpoint}`, async (route) => {
  484 |         if (++requests !== 1) return route.continue();
  485 |         const response = await route.fetch();
  486 |         entered();
  487 |         await gate;
  488 |         await route.fulfill(outcome === "success" ? { response } : { status: 503, json: { error: "Fixture stale bootstrap failure" } });
  489 |       });
  490 |       await page.goto("/");
  491 |       await held;
  492 |       try {
  493 |         await expect(page.getByRole("button", { name: "New chat", exact: true })).toBeEnabled();
  494 |         const baseline = (await page.request.get("/api/test-stats").then((response) => response.json())).calls;
  495 |         const composer = page.getByRole("textbox", { name: "Message", exact: true });
  496 |         const send = page.getByRole("button", { name: "Send message", exact: true });
  497 |         await composer.fill("hello");
  498 |         await send.click();
  499 |         await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  500 |         await composer.fill("Fixture draft after guest reply");
  501 |         const response = page.waitForResponse((response) => response.url().endsWith(`/api/${endpoint}`));
  502 |         release();
  503 |         await (await response).finished();
  504 |         const current = await page.request.get("/api/session").then((response) => response.json());
  505 |         expect(current.state.messages.some((message: { text: string }) => message.text === "hello")).toBe(true);
> 506 |         await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
      |                                                                                           ^ Error: expect(locator).toBeVisible() failed
  507 |         await expect(page.getByRole("alert")).toHaveCount(0);
  508 |         await expect(composer).toHaveValue("Fixture draft after guest reply");
  509 |         await expect(send).toBeEnabled();
  510 |         await composer.fill("thanks");
  511 |         await send.click();
  512 |         await expect(page.getByText("thanks", { exact: true })).toBeVisible();
  513 |         expect((await page.request.get("/api/test-stats").then((response) => response.json())).calls).toBe(baseline);
  514 |       } finally {
  515 |         release();
  516 |       }
  517 |     });
  518 |   }
  519 | }
  520 | 
```