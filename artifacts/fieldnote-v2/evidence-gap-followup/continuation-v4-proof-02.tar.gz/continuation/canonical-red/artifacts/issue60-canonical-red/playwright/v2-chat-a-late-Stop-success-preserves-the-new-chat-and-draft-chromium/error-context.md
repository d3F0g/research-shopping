# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v2-chat.spec.ts >> a late Stop success preserves the new chat and draft
- Location: tests/e2e/v2-chat.spec.ts:369:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByText('I want a slow fixture powerbank under SGD40', { exact: true })
Expected: 0
Received: 1
Timeout:  6000ms

Call log:
  - Expect "toHaveCount" getByText('I want a slow fixture powerbank under SGD40', { exact: true }) with timeout 6000ms
  - waiting for getByText('I want a slow fixture powerbank under SGD40', { exact: true })
    16 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]: Fieldnote
    - generic [ref=e6]:
      - button "Account" [ref=e7]
      - button "Switch to light mode" [ref=e8]
      - button "New chat" [ref=e9]
  - main [ref=e10]:
    - generic [ref=e11]:
      - region "Messages" [ref=e12]:
        - log [ref=e13]:
          - paragraph [ref=e19]: I want a slow fixture powerbank under SGD40
          - button "Current request and preferences" [ref=e21]
      - button "Scroll to end"
    - generic [ref=e23]:
      - group [ref=e25]:
        - textbox "Message" [active] [ref=e26]:
          - /placeholder: Describe what you want to buy…
          - text: Fixture draft after Stop and New chat
        - group [ref=e27]:
          - generic [ref=e28]: SGD 0–40
          - button "Send message" [ref=e29]
      - paragraph [ref=e30]: Shopping submissions can trigger a paid Exa call. Viewing existing evidence is free.
```

# Test source

```ts
  304 |       await expect(page.getByRole("button", { name: "SGD", exact: true })).toBeDisabled();
  305 |       await expect(composer).toHaveValue("SGD");
  306 |       expect(submissions).toEqual([]);
  307 |       expect(await calls()).toBe(baseline);
  308 |       await mkdir("artifacts/fieldnote-v4/e2e", { recursive: true });
  309 |       await page.screenshot({ path: `artifacts/fieldnote-v4/e2e/${viewport.name}-new-chat-pending.png` });
  310 |       const response = page.waitForResponse((result) => result.url().endsWith("/api/new-chat"));
  311 |       release();
  312 |       await response;
  313 |       await expect(page.getByRole("heading", { name: "What are you looking for?" })).toBeVisible();
  314 |       await expect(composer).toHaveValue("SGD");
  315 |       await expect(send).toBeEnabled();
  316 |       expect(submissions).toEqual([]);
  317 |       expect(await calls()).toBe(baseline);
  318 |       await page.screenshot({ path: `artifacts/fieldnote-v4/e2e/${viewport.name}-new-chat-draft-retained.png` });
  319 |       await composer.fill("hello");
  320 |       await send.click();
  321 |       await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  322 |       expect(submissions).toHaveLength(1);
  323 |       expect(await calls()).toBe(baseline);
  324 |       const current = await page.request.get("/api/session").then((r) => r.json());
  325 |       expect(current.state.intent.budget).toBeNull();
  326 |       expect(current.state.intent.requirements).toEqual([]);
  327 |       expect(current.state.messages.some((message: { text: string }) => message.text.includes("powerbank"))).toBe(false);
  328 |     } finally {
  329 |       release();
  330 |     }
  331 |   });
  332 | }
  333 | 
  334 | test("a failed New chat keeps the new draft and history without retrying", async ({ page }) => {
  335 |   await page.goto("/");
  336 |   const composer = page.getByRole("textbox", { name: "Message", exact: true });
  337 |   const send = page.getByRole("button", { name: "Send message", exact: true });
  338 |   await composer.fill("hello");
  339 |   await send.click();
  340 |   await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  341 |   let release!: () => void;
  342 |   let entered!: () => void;
  343 |   let attempts = 0;
  344 |   const held = new Promise<void>((resolve) => { entered = resolve; });
  345 |   const gate = new Promise<void>((resolve) => { release = resolve; });
  346 |   await page.route("**/api/new-chat", async (route) => {
  347 |     attempts++;
  348 |     entered();
  349 |     await gate;
  350 |     await route.fulfill({ status: 503, json: { error: "Fixture reset unavailable" } });
  351 |   });
  352 |   await page.getByRole("button", { name: "New chat", exact: true }).click();
  353 |   await held;
  354 |   try {
  355 |     await composer.fill("Fixture draft after failed reset");
  356 |     await expect(send).toBeDisabled();
  357 |     release();
  358 |     await expect(page.getByText("The server could not start a new chat. Your history stays visible.", { exact: true })).toBeVisible();
  359 |     await expect(composer).toHaveValue("Fixture draft after failed reset");
  360 |     await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  361 |     await expect(send).toBeEnabled();
  362 |     expect(attempts).toBe(1);
  363 |   } finally {
  364 |     release();
  365 |   }
  366 | });
  367 | 
  368 | for (const outcome of ["success", "failure"]) {
  369 |   test(`a late Stop ${outcome} preserves the new chat and draft`, async ({ page }) => {
  370 |     await page.goto("/");
  371 |     const composer = page.getByRole("textbox", { name: "Message", exact: true });
  372 |     const send = page.getByRole("button", { name: "Send message", exact: true });
  373 |     const calls = async () => (await page.request.get("/api/test-stats").then((response) => response.json())).calls as number;
  374 |     const baseline = await calls();
  375 |     const original = "I want a slow fixture powerbank under SGD40";
  376 |     await composer.fill(original);
  377 |     await send.click();
  378 |     await expect.poll(calls).toBe(baseline + 1);
  379 |     let release!: () => void;
  380 |     let entered!: () => void;
  381 |     const held = new Promise<void>((resolve) => { entered = resolve; });
  382 |     const gate = new Promise<void>((resolve) => { release = resolve; });
  383 |     await page.route("**/api/cancel", async (route) => {
  384 |       const response = await route.fetch();
  385 |       entered();
  386 |       await gate;
  387 |       await route.fulfill(outcome === "success" ? { response } : { status: 503, json: { error: "Fixture cancellation unavailable" } });
  388 |     });
  389 |     await page.getByRole("button", { name: "Stop research", exact: true }).click();
  390 |     await held;
  391 |     try {
  392 |       await page.getByRole("button", { name: "New chat", exact: true }).click();
  393 |       await expect(page.getByRole("heading", { name: "What are you looking for?" })).toBeVisible();
  394 |       await composer.fill("hello");
  395 |       await send.click();
  396 |       await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  397 |       await composer.fill("Fixture draft after Stop and New chat");
  398 |       const pendingResponse = page.waitForResponse((response) => response.url().endsWith("/api/cancel"));
  399 |       release();
  400 |       await (await pendingResponse).finished();
  401 |       const current = await page.request.get("/api/session").then((response) => response.json());
  402 |       expect(current.state.intent.budget).toBeNull();
  403 |       expect(current.state.messages.some((message: { text: string }) => message.text === "hello")).toBe(true);
> 404 |       await expect(page.getByText(original, { exact: true })).toHaveCount(0);
      |                                                               ^ Error: expect(locator).toHaveCount(expected) failed
  405 |       await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  406 |       await expect(page.getByText("The server could not confirm cancellation. No automatic retry was sent.", { exact: true })).toHaveCount(0);
  407 |       await expect(composer).toHaveValue("Fixture draft after Stop and New chat");
  408 |       await expect(send).toBeEnabled();
  409 |       expect(await calls()).toBe(baseline + 1);
  410 |       await composer.fill("thanks");
  411 |       await send.click();
  412 |       await expect(page.getByText("thanks", { exact: true })).toBeVisible();
  413 |       expect(await calls()).toBe(baseline + 1);
  414 |     } finally {
  415 |       release();
  416 |     }
  417 |   });
  418 | }
  419 | 
  420 | test("a current Stop failure preserves accepted context and allows the next message", async ({ page }) => {
  421 |   await page.goto("/");
  422 |   const composer = page.getByRole("textbox", { name: "Message", exact: true });
  423 |   const send = page.getByRole("button", { name: "Send message", exact: true });
  424 |   const calls = async () => (await page.request.get("/api/test-stats").then((response) => response.json())).calls as number;
  425 |   const baseline = await calls();
  426 |   await composer.fill("I want a slow fixture powerbank under SGD40");
  427 |   await send.click();
  428 |   await expect.poll(calls).toBe(baseline + 1);
  429 |   let attempts = 0;
  430 |   await page.route("**/api/cancel", async (route) => {
  431 |     attempts++;
  432 |     await route.fetch();
  433 |     await route.fulfill({ status: 503, json: { error: "Fixture cancellation unavailable" } });
  434 |   });
  435 |   await composer.fill("Fixture draft during Stop");
  436 |   await page.getByRole("button", { name: "Stop research", exact: true }).click();
  437 |   await expect(page.getByText("The server could not confirm cancellation. No automatic retry was sent.", { exact: true })).toBeVisible();
  438 |   await expect(composer).toHaveValue("Fixture draft during Stop");
  439 |   await expect(page.getByText("SGD 0–40", { exact: true })).toBeVisible();
  440 |   expect(attempts).toBe(1);
  441 |   await composer.fill("hello");
  442 |   await send.click();
  443 |   await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  444 |   await expect(page.getByText("The server could not confirm cancellation. No automatic retry was sent.", { exact: true })).toHaveCount(0);
  445 |   expect(await calls()).toBe(baseline + 1);
  446 |   const current = await page.request.get("/api/session").then((response) => response.json());
  447 |   expect(current.state.intent.budget).toMatchObject({ maximum: 40, currency: "SGD" });
  448 | });
  449 | 
  450 | for (const endpoint of ["account", "session"]) {
  451 |   test(`a current ${endpoint} reload failure retains the draft and supports explicit recovery`, async ({ page }) => {
  452 |     await page.route(`**/api/${endpoint}`, (route) => route.fulfill({ status: 503, json: { error: "Fixture bootstrap unavailable" } }));
  453 |     await page.goto("/");
  454 |     await expect(page.getByText("The server is unavailable. Your draft is retained. Reload your account when it returns.", { exact: true })).toBeVisible();
  455 |     const baseline = (await page.request.get("/api/test-stats").then((response) => response.json())).calls;
  456 |     const composer = page.getByRole("textbox", { name: "Message", exact: true });
  457 |     const send = page.getByRole("button", { name: "Send message", exact: true });
  458 |     await composer.fill("Fixture draft during unavailable account");
  459 |     await expect(send).toBeDisabled();
  460 |     await page.unroute(`**/api/${endpoint}`);
  461 |     await page.getByRole("button", { name: "Account", exact: true }).click();
  462 |     await page.getByRole("button", { name: "Reload account", exact: true }).click();
  463 |     await expect(page.getByText("Accounts are not configured.", { exact: false })).toBeVisible();
  464 |     await page.getByRole("button", { name: "Close", exact: true }).click();
  465 |     await expect(composer).toHaveValue("Fixture draft during unavailable account");
  466 |     await expect(send).toBeEnabled();
  467 |     await expect(page.getByRole("alert")).toHaveCount(0);
  468 |     await composer.fill("hello");
  469 |     await send.click();
  470 |     await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  471 |     expect((await page.request.get("/api/test-stats").then((response) => response.json())).calls).toBe(baseline);
  472 |   });
  473 | }
  474 | 
  475 | for (const endpoint of ["account", "session"]) {
  476 |   for (const outcome of ["success", "failure"]) {
  477 |     test(`a stale ${endpoint} bootstrap ${outcome} preserves a newer ordinary guest reply`, async ({ page }) => {
  478 |       let release!: () => void;
  479 |       let entered!: () => void;
  480 |       let requests = 0;
  481 |       const held = new Promise<void>((resolve) => { entered = resolve; });
  482 |       const gate = new Promise<void>((resolve) => { release = resolve; });
  483 |       await page.route(`**/api/${endpoint}`, async (route) => {
  484 |         if (++requests !== 1) return route.continue();
  485 |         const response = await route.fetch();
  486 |         entered();
  487 |         await gate;
  488 |         await route.fulfill(outcome === "success" ? { response } : { status: 503, json: { error: "Fixture stale bootstrap failure" } });
  489 |       });
  490 |       await page.goto("/");
  491 |       await held;
  492 |       try {
  493 |         await expect(page.getByRole("button", { name: "New chat", exact: true })).toBeEnabled();
  494 |         const baseline = (await page.request.get("/api/test-stats").then((response) => response.json())).calls;
  495 |         const composer = page.getByRole("textbox", { name: "Message", exact: true });
  496 |         const send = page.getByRole("button", { name: "Send message", exact: true });
  497 |         await composer.fill("hello");
  498 |         await send.click();
  499 |         await expect(page.getByText("Hi. What are you looking to buy?", { exact: true })).toBeVisible();
  500 |         await composer.fill("Fixture draft after guest reply");
  501 |         const response = page.waitForResponse((response) => response.url().endsWith(`/api/${endpoint}`));
  502 |         release();
  503 |         await (await response).finished();
  504 |         const current = await page.request.get("/api/session").then((response) => response.json());
```