# Exact-candidate independent security review

The goal is to preserve the approved UI, close evidence gaps and make manual chat journeys reliable. This report binds the final application candidate and retains the earlier blocking findings as red evidence.

- Base `34dbb00ae95e82239123f7e71552b7f74c679bbe`.
- Previously blocked candidate `afd95024065d6b14cd2d06240de540c8d67a89a1`.
- Current candidate `df32c4b3be6b09280369fc4eb38bf4e127312d41`.
- Independent detached checkout `/Users/josiahwong/Documents/research-shopping-v4-final-security`.
- Hook SHA256 `fd5be428bde269f76e007226adc3e263264ac768fee6477caf8aed7f6cde5c80`.
- Reviewer authored no application changes. Source, maintained scripts, tests, package files and project skills equal the candidate. Changes in this checkout are owned verification artifacts only.

Verdict is PASS for the reviewed source and offline runtime security scope. The reproduced stale Stop and bootstrap publication blockers are fixed on this exact candidate. No unresolved blocking security finding remains in this reviewed diff. Issue #62 remains a separately tracked P2 recovery gap. This verdict does not satisfy the independent publication, live-product, CI or merge gates.

## Scope and source findings

The full base-to-head review covers ten paths. They are `src/client/useFieldnote.ts`, `src/client/App.tsx`, `src/client/ResearchAnswer.tsx`, `src/server/exa-research.ts`, `tests/api/v2-exa.test.ts`, `tests/e2e/v2-chat.spec.ts`, `tests/e2e/v3-evidence-boundaries.spec.ts`, `scripts/verify-personalization-browser.mjs`, `scripts/verify-evidence-history.ts`, and `.agents/skills/verify-research-shopping/scripts/smoke.mjs`.

The final application diff after afd changes only `useFieldnote.ts`. `reload()` now captures both lifecycle generation and submission ownership. It checks both after the account read, after the guest-session read, and before error publication. Account and conversation state publish together after the final ownership check. This preserves an ordinary guest reply even though ordinary messages deliberately do not cancel active research. `stop()` fences both successful cancellation snapshots and failures with its lifecycle generation. Existing monotonic revision checks remain in place.

The earlier reset changes retain new typing, block submission during reset, and fence success, error and readiness. The server schema change emits Draft 7, consistent with the [official Answer contract](https://exa.ai/docs/reference/answer). Strict malformed-response rejection, known-cost retention, one-call behavior and price gates remain intact. This is not proof that the old dialect caused the failed live watches response or that live product acceptance is repaired.

The card change labels AI assessments and source previews without changing eligibility or historical evidence. Both verifier selector edits preserve their existing assertions. Exact blob comparisons confirm no domain, account, workspace, quota, evidence or backend protocol change since afd, and no server change from the original base except the Draft 7 serializer argument.

## Independent runtime evidence

All reviewer invocations used an environment allowlist with `NODE_ENV=test`, `EXA_RESEARCH_ENABLED=false`, `TMPDIR=/tmp`, and `LANG=C LC_ALL=C`. Dependencies were copied into the detached checkout with Vite caches excluded. No user environment file, credential, existing database, private capture, normal preview, ledger or grant was accessed. SDK calls used fake keys and owned loopback substitutes. No paid call occurred.

1. `npm test` passed 456 tests in 14 files. This includes actual SDK HTTP shape rejection, returned-cost retention, price-bound pairs, header and body cancellation, quota behavior, evidence provenance and source-link boundaries. Log `artifacts/fieldnote-v4/security/unit-api.log`.
2. `npm run test:e2e` passed 24 browser tests with owned ports 3297 and 5397. This independently exercises current Stop failure, current account and session reload failures with explicit recovery, stale Stop success and failure, stale bootstrap success and failure, reset draft retention, evidence and card behavior. Log `artifacts/fieldnote-v4/security/e2e.log`.
3. The independent artifact runner passed all 13 adversarial probes through real Chromium, Hono, Better Auth, owned PostgreSQL and the actual Exa SDK. Every JSON proof pins df32 and records `cleanup: true`. Log inventory `artifacts/fieldnote-v4/security/matrix-exits.json`.
4. Independently ran `node scripts/verify-personalization-browser.mjs` successfully on df32. Its 23 recorded outcomes cover desktop and mobile stale account/session success and failure across sign-in, stale Stop success and failure across New chat and sign-in, 409 recovery, delayed reset, actual persistent account research, refresh, independent account isolation, owned-data deletion and mobile sign-out during SDK body consumption. Evidence is `artifacts/fieldnote-v2/accounts/browser.json` and its screenshots, with invocation output in `artifacts/fieldnote-v4/security/accounts-browser.log`. The source's static author-verification disclaimer is unchanged; this invocation was independent.

The 13 probes comprise held-reset Enter/currency/preference submission rejection with no queue, same-valued new draft retention, stale reset success and failure during a newer signed-in reset, current reset failure, late Stop across New chat, late Stop across sign-in, stale account and guest-session bootstrap across sign-in, four paired account/session success/failure cases after an ordinary guest hello, and signed-in 409 recovery.

Original afd reproductions and the blocking verdict remain in `/tmp/fieldnote-v4-afd-security-report.md` and `/Users/josiahwong/Documents/research-shopping-v4-combined-security/artifacts/fieldnote-v4/security/`. The final rerun used the same reviewer-owned reproductions against df32, not replacement success assertions. Inspected final screenshots show the new reply and retained draft after delayed Stop and bootstrap responses.

All final commands exited successfully. The maintained account runner completed its owned cleanup. Every custom proof records cleanup after closing its browser, server and disposable database. E2E listeners on ports 3297 and 5397 are absent. Final source equality and diff-whitespace checks passed. Only the owned review worktree and artifacts remain.

## Accepted recovery gap and remaining gates

Issue #62 remains a P2 recovery gap. A committed signed-in cancellation returns 200 while its client response is held. Immediate New chat still submits the previous revision and receives 409. The entire persisted workspace, account identity, history and both SGD30–40 bounds remain unchanged. There is exactly one cancelled synthetic SDK call and no automatic retry. Explicit browser Reload, then New chat, uses the fresh revision and succeeds. An ordinary hello then remains free. The generic error does not explain this recovery, and unsent-draft persistence across browser reload is not claimed.

No new protocol guard, automatic retry, backend rewrite or relaxed eligibility was needed for the lifecycle fixes. The reproduced P1 stale-publication findings are separate from this intentional conflict boundary.

This report is a code and offline-runtime security review. It does not approve private metadata publication, repository history handling, production deployment, CI, live retrieval, semantic product usefulness, merchant authorization or billing reconciliation. Root owns those gates. The original blank hosted CI cause remains unknown. This review does not claim to have rerun the historical 81-probe audit or the independent visual QA owner's three-viewport acceptance.

## Reproduction and principles

The script `artifacts/fieldnote-v4/security/adversarial-browser.mjs` is retained in both reviewer checkouts. The final matrix ran the default reset set and selectors `late Stop response cannot replace`, `late initial account reload`, `late initial guest snapshot`, `newer guest message`, and `signed-in conflict`. Each selected run owns and removes its temporary runtime and database. `FIELDNOTE_SECURITY_ARTIFACT_DIR` supports a caller-owned output directory. Original red artifacts are preserved.

Prove It Works changed the review from summary acceptance to exact-source browser, socket and database readback. Test Behavior, Not Implementation required visible state, draft, request count and persisted ownership checks. Separate Before Serializing Shared State required distinct checkouts, dependency copies, databases and evidence. Boundary Discipline kept schema compatibility, response validation, eligibility, conflict recovery and live acceptance separate. Model the Domain focused the fix assessment on existing generation and submission ownership rather than extra state or broad guards.
