# Independent security review of the combined Fieldnote candidate

The goal is to preserve the approved UI, close evidence gaps, and make manual chat journeys reliable. The exact candidate is blocked by two reproduced asynchronous ownership defects. The new reset handler passes its targeted checks, but older Stop and bootstrap replies can still publish across newer conversations or sign-in.

## Binding and ownership

- Base `34dbb00ae95e82239123f7e71552b7f74c679bbe`.
- Head `afd95024065d6b14cd2d06240de540c8d67a89a1`.
- Reviewed branch `integrate/fieldnote-v4-draft7-card`.
- Independent detached checkout `/Users/josiahwong/Documents/research-shopping-v4-combined-security`.
- Reviewer authored no application, test, package, skill, or GitHub changes. Only owned review scripts, logs and artifacts changed.
- Dependencies were copied from the integration checkout with `.vite` and `.vite-temp` excluded. No dependency symlink or shared preview cache was used.
- Application source still equals the candidate. `git diff --exit-code HEAD -- src scripts tests package.json package-lock.json .agents` passed.

The ten changed paths are `.agents/skills/verify-research-shopping/scripts/smoke.mjs`, `scripts/verify-evidence-history.ts`, `scripts/verify-personalization-browser.mjs`, `src/client/App.tsx`, `src/client/ResearchAnswer.tsx`, `src/client/useFieldnote.ts`, `src/server/exa-research.ts`, `tests/api/v2-exa.test.ts`, `tests/e2e/v2-chat.spec.ts`, and `tests/e2e/v3-evidence-boundaries.spec.ts`.

## Blocking findings

### P1. Delayed Stop completion restores abandoned guest content

`src/client/useFieldnote.ts` lines 184–205 await cancellation and publish its state or error without an ownership generation check. The guest `accept()` at lines 35–36 compares revisions, but New chat restarts the guest revision sequence. An older cancellation snapshot therefore passes the revision comparison.

Reproduction used the real browser, Hono, Exa SDK and an owned temporary PostgreSQL cluster with a synthetic loopback provider.

1. Submit `I want a slow fixture powerbank under SGD40` and wait for the substitute SDK call.
2. Intercept the first `/api/cancel` response after `route.fetch()` has executed cancellation on the server.
3. Click Stop and wait for the actual SDK response socket to close.
4. Click New chat, wait for the empty view, then send `hello`.
5. Release the old cancellation response.

The browser restores the powerbank and SGD40 and loses the visible hello. A direct `/api/session` read still contains hello and no budget. The typed new draft survives. Exactly one synthetic SDK call occurred, and its response socket closed. A second reproduction substitutes UI Create account and signed-in hello for step 4. The late guest cancellation snapshot then replaces the visible signed-in conversation. `/api/account` remains signed-in and retains hello in the database.

This is blocking even though the unfenced Stop code predates the reviewed diff. Root accepted it for issue #60. The evidence establishes stale client publication, not a database overwrite or data disclosure between two independent accounts.

Evidence under the checkout's `artifacts/fieldnote-v4/security/`:

- `adversarial-proof.json`, last probe.
- `late-stop-after-reset.png`.
- `adversarial-account-proof.json`.
- `late-stop-after-signin.png`.

### P1. Delayed initial reload crosses completed sign-in

`src/client/useFieldnote.ts` lines 48–68 publish account, conversation, error and readiness without fencing either asynchronous read. Development React StrictMode starts two initial reloads, allowing one to complete while another remains outstanding.

Two separate zero-provider-call reproductions passed the newer sign-in before releasing the old response.

1. Hold the first `/api/account` response after fetching a guest result. Let the second bootstrap finish. Send guest hello, create an account through the UI, and send signed-in thanks. Release the old account response. The browser becomes guest and restores guest hello. The server remains signed-in and retains thanks.
2. Seed an owned guest cookie, then hold the first initial `/api/session` response after the guest account result was accepted. Let the second bootstrap finish. Create an account and send thanks. Release the old guest snapshot. The account control remains signed-in, but the visible conversation becomes empty. The server retains thanks.

Both await points need ownership protection. Guarding only the account read leaves the guest-session read vulnerable. Stale error and readiness publication also require review. These tests do not establish the cause of the earlier blank hosted CI symptom in issue #56.

A later independent same-guest matrix also reproduced three stale-publication failures with zero SDK calls. A held initial session success erased a newer ordinary hello without an authentication transition. Held initial account and session failures installed an obsolete unavailable-account error after that hello. A paired held account success preserved the hello because its later session read obtained current state. `probe-newer-guest-message.json` records all four outcomes and cleanup. The selector `newer guest message` reruns the matrix. This binds the ordinary-send ownership case to the existing submission counter, in addition to generation changes for lifecycle transitions.

Evidence under the same directory:

- `probe-late-initial-account-reload.json` and `late-bootstrap-after-signin.png`.
- `probe-late-initial-guest-snapshot.json` and `late-guest-bootstrap-after-signin.png`.

## Passed checks

- Independent `npm test` passed all 456 unit/API tests in 14 files. The suite includes actual SDK HTTP validation of the Draft 7 request, malformed quotation objects, missing required fields, non-object products, known-cost retention, one-call behavior, paired lower/in-range/upper price boundaries, SDK header/body cancellation, source evidence boundaries and quota behavior. Log `artifacts/fieldnote-v4/security/unit-api.log`.
- Independently reran `scripts/verify-personalization-browser.mjs`. Desktop and mobile passed actual UI account creation, held guest-reset response across sign-in, saved SGD30–40 research, refresh, independent account isolation, deletion of owned test shopping data, and mobile sign-out during actual SDK body consumption. Fresh results are in `artifacts/fieldnote-v2/accounts/browser.json` and the corresponding screenshots. This runner's static author-verification disclaimer remains unchanged; this invocation was by the independent reviewer.
- The custom browser probe retained a same-valued `SGD` draft during reset, blocked Enter and currency submission, prevented contextual preference dispatch, and recorded no queued turn or substitute call when reset completed. An ordinary hello remained free.
- Held stale guest reset success and failure could not clear a newer signed-in reset's pending readiness or draft. The newer account retained its messages. Both probes passed.
- A current reset failure kept new typing and visible history, restored send readiness, and made only one reset attempt.
- `git diff --check` passed.
- Blob inventories confirm all domain files and all server files except `exa-research.ts` are identical to the base. Package files, `src/client/api.ts` and `PreferenceEditor.tsx` are also identical. The only server diff is the explicit Draft 7 serialization target. Inventories are `base-blobs.txt` and `head-blobs.txt`.

The [official Answer reference](https://exa.ai/docs/reference/answer) documents JSON Schema Draft 7. I read the canonical build-with-exa skill, ran the documented `npx skills use` command, read its complete output, and read `references/answer.md` from its printed directory. The change matches the documented wire contract. It does not prove that the previously malformed live provider output was caused by the old schema dialect or that live watches research is repaired.

The card diff removes the unlabeled fit rationale from the collapsed card, preserves it behind an AI-unverified label, and qualifies source preview imagery. It changes no eligibility, source retention, merchant policy, money or stored-history semantics. The two verifier changes replace only exact accessible image selectors; their assertions remain intact. Independent visual approval remains the separate QA owner's responsibility.

## Reproduction commands

From the owned detached checkout, the reusable script is `artifacts/fieldnote-v4/security/adversarial-browser.mjs`. Each selected invocation owns a fresh isolated runtime and database. Use one of these exact selectors.

```sh
env -i PATH="$PATH" HOME="$HOME" TMPDIR=/tmp LANG=C LC_ALL=C NODE_ENV=test EXA_RESEARCH_ENABLED=false FIELDNOTE_SECURITY_PROBE='late Stop response cannot resurrect' node artifacts/fieldnote-v4/security/adversarial-browser.mjs
env -i PATH="$PATH" HOME="$HOME" TMPDIR=/tmp LANG=C LC_ALL=C NODE_ENV=test EXA_RESEARCH_ENABLED=false FIELDNOTE_SECURITY_PROBE='late Stop response cannot replace' node artifacts/fieldnote-v4/security/adversarial-browser.mjs
env -i PATH="$PATH" HOME="$HOME" TMPDIR=/tmp LANG=C LC_ALL=C NODE_ENV=test EXA_RESEARCH_ENABLED=false FIELDNOTE_SECURITY_PROBE='late initial account reload' node artifacts/fieldnote-v4/security/adversarial-browser.mjs
env -i PATH="$PATH" HOME="$HOME" TMPDIR=/tmp LANG=C LC_ALL=C NODE_ENV=test EXA_RESEARCH_ENABLED=false FIELDNOTE_SECURITY_PROBE='late initial guest snapshot' node artifacts/fieldnote-v4/security/adversarial-browser.mjs
```

`FIELDNOTE_SECURITY_ARTIFACT_DIR` can redirect results to an existing caller-owned directory. Filtered runs write `probe-<selector>.json` and screenshots. The original proofs above remain preserved. Running without a selector runs the original five-case reset/Stop set. The browser blocks external resource navigation. All provider traffic targets the runtime's loopback SDK substitute.

The independent package and account commands used the same environment allowlist without a probe selector. The account command was `node scripts/verify-personalization-browser.mjs`. No `.env`, existing database, private provider capture, user key, existing quota ledger, grant, or normal preview was used.

## Limits and cleanup

This is a blocking security review, not merge approval. No new candidate binding, hosted CI result, full rerun of the older 81-probe suite, or live-provider acceptance is claimed. Public metadata and repository history publication need root's separate review. The stopped provider history and exposed ancestor issue remain separate and were not inspected or modified. No paid calls, deployment, push, merge or history rewrite occurred.

Every custom browser proof records `cleanup: true`. The standard account runner exited successfully after its own cleanup. Two preliminary temporary PostgreSQL starts failed before application launch because the restricted environment omitted `LC_ALL`. Their own logs identify the locale failure. Setting `LANG=C LC_ALL=C` fixed setup. Both failed, stopped fixture directories were removed after verifying no postmaster PID or listener remained; the failure log is retained. Only owned processes and temporary clusters were stopped. The review checkout and artifacts remain for follow-up.

## Separate signed-in conflict assessment

At root's request, an additional owned runtime probe held an already committed signed-in workspace cancellation response. The cancellation returned 200. Immediate New chat used the previous client revision and received 409. The post-conflict workspace exactly equaled the post-cancel workspace. Account identity, history and both SGD30 and SGD40 bounds remained intact. No research result published. There was one synthetic SDK call and one closed SDK response socket. Before explicit recovery the only workspace commands were cancel and new-chat, so no automatic retry occurred.

After releasing the held response, explicit browser Reload followed by New chat succeeded with the refreshed revision. The saved state was empty, then an ordinary hello succeeded without another SDK call. Evidence is `artifacts/fieldnote-v4/security/probe-signed-in-conflict.json`, `signed-in-conflict-before-recovery.png` and `signed-in-conflict-recovered.png`. Select this probe with `FIELDNOTE_SECURITY_PROBE='signed-in conflict'`.

This is a P2 recovery and usability gap, not a data or authority blocker. The 409 enforces optimistic concurrency before mutation. The generic reset error does not explain the browser-reload recovery. This result does not claim seamless immediate reset, persistence of an unsent draft across browser reload, or acceptance of the still-uncommitted generation fix. It was independently executed on afd and binds the unchanged workspace protocol. The two P1 findings above remain blocking until an exact updated candidate passes review.

## Principles that changed review decisions

- Prove It Works required real browser ordering, server readback and SDK socket-close evidence instead of accepting the author's passing summary.
- Test Behavior, Not Implementation made the probes assert visible conversation, account ownership, retained draft, provider-call count and persisted state. That exposed failures the existing reset tests missed.
- Separate Before Serializing Shared State led to a detached checkout, private dependency copy, fresh disposable databases and separate artifacts.
- Boundary Discipline kept the Draft 7 wire correction separate from strict response rejection, cost retention and unchanged eligibility rules.
- Model the Domain shaped the review artifact as named probes with explicit outcomes and cleanup, and focused the concurrency review on request ownership rather than unrelated new guards.
