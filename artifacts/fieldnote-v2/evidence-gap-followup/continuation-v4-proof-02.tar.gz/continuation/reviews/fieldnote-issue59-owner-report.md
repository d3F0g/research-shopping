# Issue 59 owner report

Preserve the approved Fieldnote UI while making New chat retain new typing and prevent submissions against the abandoned conversation.

Candidate `afd95024065d6b14cd2d06240de540c8d67a89a1` is ready for root's independent review. The isolated branch is `fix/issue-59-new-chat-draft` in `/Users/josiahwong/Documents/research-shopping-new-chat-draft`. Base is `fe5f84984576fb37c75099d9d4401ab7653912ab`. Red regression commit is `783e9ecee3d59d2269131efdfc67e45f19f8fa24`. Fix commit is `afd95024065d6b14cd2d06240de540c8d67a89a1`. No push, PR mutation, merge, deployment or shared-ref rewrite occurred.

## Reproduced failures

The owned PostgreSQL/Hono browser repro at base confirmed four failures. A held New chat request erased newly typed text on completion. Enter during a held reset answered the abandoned $30-40 clarification and caused one local SDK call. The first of two reset responses arriving last erased the newer hello view while the server retained it. A guest reset response arriving after sign-in erased the signed-in hello view while PostgreSQL retained it. All provider responses were explicit automated substitutes. Paid calls were zero.

Rerunnable diagnostic scripts remain at `/tmp/fieldnote-issue59-repro.mjs` and `/tmp/fieldnote-issue59-account-repro.mjs`. Red proof and screenshots are copied under `fieldnote-issue59-repro/` and `fieldnote-issue59-account-repro/` beside this report. The maintained red logs are `fieldnote-issue59-red.log`, `fieldnote-issue59-failure-red.log` and `fieldnote-issue59-account-red.log`.

## Final change

`useFieldnote.ts` adds one private reset-pending boolean. It clears the old draft when the reset starts, preserves later typing, blocks send and duplicate reset initiation, and checks the existing generation before accepting reset success, error or completion. Existing interruption points revoke reset ownership during account transitions. The public ready flag derives account readiness and reset availability. The textarea and actual research cancellation remain unchanged.

`App.tsx` binds the existing New chat and currency buttons to that readiness. No new visible progress status or confirmation was added. API, domain, evidence, provider, historical envelopes and paid-call policy remain unchanged.

`v2-chat.spec.ts` covers desktop/mobile delayed resets with identical SGD text before and after the explicit clear, keyboard submission suppression, disabled duplicate reset and currency controls, zero prepare/research dispatch while pending, no automatic action after completion, fresh-chat constraints, and reset-failure retention. The existing PostgreSQL account browser script covers a late guest reset after sign-in while retaining the signed-in hello, unsent draft and enabled composer. All previous account/security/cancellation checks remain.

## Verification

All final checks below passed on `afd95024065d6b14cd2d06240de540c8d67a89a1` with no source changes.

- `npm test` passed 456 tests in 14 files. See `fieldnote-issue59-exact-unit.log`.
- `npm run build` passed typecheck and build. See `fieldnote-issue59-exact-build.log`. Vite retains its existing advisory for a bundle above 500 kB.
- `PLAYWRIGHT_API_PORT=3263 PLAYWRIGHT_WEB_PORT=5373 npm run test:e2e` passed 15 browser tests. See `fieldnote-issue59-exact-e2e.log`.
- `node scripts/verify-personalization-browser.mjs` passed the real owned PostgreSQL account journeys at desktop/mobile sizes. See `fieldnote-issue59-exact-account.log` and `accounts-exact/browser.json`. The original sign-out during actual SDK body consumption still aborts transport and prevents late publication.
- `npm run verify:registry` matched all 18 recorded official component files. See `fieldnote-issue59-registry.log`.
- The project verification skill passed 1440x1000, 390x844 and 390x600 on the exact commit with `cleanCandidate: true`, `result: passed` and `cleanup: true`. See `verification-skill/proof.json`.

Inspected actual retained-draft desktop/mobile screenshots in `../e2e/`, initial research screenshots at all three skill viewports, and the short-mobile reset screenshot. The minimal header, centered conversation and accessible bottom composer remain. The short mobile conversation scrolls to evidence as designed. The skill separately verifies disclosure reachability and overlap.

Focused Comment Sicko review reported zero comment deletions, suppressions, dead compatibility paths, unrelated edits or unsupported guards. It reviewed the working diff before final whitespace and identical-draft test-input adjustment. Root's independent exact-candidate QA/security remains required. The implementation owner does not approve its own merge.

## Decisions and principles

Fix Root Causes moved draft clearing to the reset initiation and guarded actual observed stale completion paths. Model the Domain kept reset ownership separate from account loading and research activity. Laziness Protocol selected candidate A's one boolean and existing generation over candidate B's wider availability-state replacement. No synchronous mirror ref was added for unobserved same-event callers. Test Behavior, Not Implementation used actual typing, visible history, HTTP dispatch counts and account state. Prove It Works required red browser reproduction, final browser journeys and inspected screenshots. Separate Before Serializing Shared State gave this writer its own worktree and serialized reset commands for one canonical conversation. The two candidate sketches and synthesis are alongside this report.

Configured gpt-6-luna was unavailable. The second design candidate used active-host inheritance. The cross-judge pool had no available known distinct family, so the owner read and scored both sketches without that judge.

## Limits and cleanup

This establishes local browser, Hono, PostgreSQL, account and SDK-substitute behavior. It does not establish live Exa retrieval, billing, current prices, merchant offers or external product usefulness. Broader standalone reload and Stop response ownership races were not assessed or changed. No additional concrete unresolved reset failure was observed.

No private environment file, key, operator provider capture, live ledger, grant or existing database was accessed. The account harness created and removed its own synthetic PostgreSQL cluster and fixture accounting file. The browser, API, web and owned PostgreSQL processes were closed. Ports 3263, 5373, 3273 and 5383 were confirmed free after checks. Original tracked account artifact outputs were restored after copying this run's evidence. The worktree has no source changes and only untracked local artifacts under `artifacts/fieldnote-v4/`.
