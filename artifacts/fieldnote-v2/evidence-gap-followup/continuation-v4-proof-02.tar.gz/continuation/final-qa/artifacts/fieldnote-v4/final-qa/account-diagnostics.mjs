import { chromium } from '@playwright/test';
import { writeFile, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';

const directory = resolve('artifacts/fieldnote-v4/final-qa/account-diagnostics');
await mkdir(directory, { recursive: true });
const pages = [];
const byPage = new Map();
const launch = chromium.launch.bind(chromium);
chromium.launch = async (...args) => {
  const browser = await launch(...args);
  const newContext = browser.newContext.bind(browser);
  browser.newContext = async (...contextArgs) => {
    const context = await newContext(...contextArgs);
    context.on('page', (page) => {
    const record = { id: pages.length + 1, events: [] };
    pages.push(record);
    byPage.set(page, record);
    page.on('console', (message) => record.events.push({ type: 'console', level: message.type(), text: message.text().slice(0, 1000) }));
    page.on('pageerror', (error) => record.events.push({ type: 'pageerror', text: String(error) }));
    page.on('requestfailed', (request) => record.events.push({ type: 'requestfailed', url: request.url(), failure: request.failure() }));
    page.on('response', (response) => {
      const url = new URL(response.url());
      if (!url.pathname.startsWith('/api/')) record.events.push({ type: 'response', url: url.pathname, status: response.status() });
    });
    page.on('domcontentloaded', async () => {
      try { record.initial = await page.locator('html').evaluate((html) => html.outerHTML); } catch {}
    });
    });
    return context;
  };
  const close = browser.close.bind(browser);
  browser.close = async (...closeArgs) => {
    for (const context of browser.contexts()) for (const page of context.pages()) {
      const record = byPage.get(page);
      if (!record) continue;
      try {
        record.final = await page.locator('html').evaluate((html) => html.outerHTML);
        await page.screenshot({ path: `${directory}/open-page-${record.id}.png` });
        record.location = page.url();
      } catch (error) { record.snapshotError = String(error); }
    }
    await writeFile(`${directory}/pages.json`, JSON.stringify(pages, null, 2));
    return close(...closeArgs);
  };
  return browser;
};
try {
  await import('../../../scripts/verify-personalization-browser.mjs');
} catch (error) {
  await writeFile(`${directory}/failure.txt`, String(error.stack ?? error));
  throw error;
}
