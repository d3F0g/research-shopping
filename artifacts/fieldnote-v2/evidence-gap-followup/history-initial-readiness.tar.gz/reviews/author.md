# Initial mixed-history readiness fix

The goal is to preserve the approved UI and finish the evidence follow-up with a reliable, unchanged product-history assertion. Only `scripts/verify-evidence-history.ts` changes. No application, UI, workflow, dependency, billing or private configuration changes.

## Commits

- Base `4af739cfed7861740eb2d5c4a6dcf7c4c46e292b`.
- Red `65bfc4cd41e674e42fad652edf216c8c5f1f2e93`.
- Fix `a123f1afe8253835aadd3dd59ee7881df88c990b`.
- Branch `fix/history-initial-account-readiness` in `/Users/josiahwong/Documents/research-shopping-history-ci`.

## Actual hosted evidence and limit

Downloaded PR CI run44545892487 artifact `research-shopping-browser-evidence`. Its proof records desktop mixed-history/reload success and then fails the mobile initial historical-name matcher. Its exact error is:

```
Locator: getByText('Synthetic Anker Pocket 10', { exact: true }).first()
Expected: visible
Timeout: 5000ms
Error: element(s) not found
```

The hosted artifact lacks initial mobile network/DOM diagnostics, so the original hosted latency and exact cause remain unproven. No rerun was used to dismiss that failure.

## Controlled mechanism

The verifier previously began its five-second DOM assertion after the HTML load event, while the signed-in workspace GET could still be pending. The existing reload fix synchronized only reload. A real owned Chromium CDP rule applies5500ms latency only to the owned `/api/account` request in the mobile context. It is installed before the first navigation and remains active for reload. It does not fabricate a response or change the application.

The red commit retains the original historical-name matcher. It fails in the real browser with the same error. Its bounded fixture diagnostics show a page load, two StrictMode account requests, no account response and no page error before failure. The screenshot shows the loading empty state with disabled composer. The red run exits1 and cleans up the owned database, API, Vite and browser.

The fix registers the exact owned GET response wait before navigation. It requires HTTP200, signed-in status, exact retained historical messages and null stale prepared state before starting the original unchanged five-second DOM assertion. The later independent control-API migration checks remain. The existing reload response validation and original amount matcher remain unchanged. There is no timeout increase, retry, swallowed error or fallback.

## Verification

At clean tracked fix commit a123f1a:

```
npm run verify:evidence:history
status: passed
cleanup: true
```

Both1440x1000 and390x844 browser journeys pass. They retain V2/V3 messages, display V4 source observations, reject stale prepared operations without dispatch, isolate a second account and survive actual owned PostgreSQL/API restart. Mobile initial account response arrived5542ms after page-loaded, and reload response arrived5515ms after page-loaded. These controlled timings identify the tested delay; they do not establish the original CI timing. The original DOM assertions pass after validating each response.

`npm run typecheck` exits0. `git diff --check` passes. Only generated fixture artifacts and the dependency symlink are untracked. No application test suite was repeated because application bytes are unchanged and the modified maintained verifier itself exercises the relevant runtime.

The desktop and mobile initial-result screenshots were inspected directly. They retain the approved dark chat layout, leading source-row observation, uncertainty, fixture label and accessible bottom composer. This author inspection is not independent visual QA.

## Evidence

`/tmp/fieldnote-history-initial-readiness-proof.tar.gz` contains17 regular file members. SHA256 `4b74e3c650566d550c6c5e376fe5f5a61aebfa7b836b922afdde77b9c184fd5f`. Its sibling `-manifest.json` records every member size and hash. Red and green proof, bounded network/DOM diagnostics, screenshots and command logs are separated. The root already runs an independent red/fix check. Independent QA/security and current-head hosted CI remain required.

The automated composition uses only owned local PostgreSQL and injected local SDK traffic with Exa disabled. It reads no private capture, credentials, manual grant, paid ledger or existing database. It proves neither live shopping usefulness nor merchant verification. No push, merge, GitHub mutation, shared-history change or paid call occurred.

## Principles

Model the Domain kept the prerequisite explicit as a validated signed-in workspace response rather than elapsed time. Fix Root Causes synchronized the first navigation as well as reload instead of increasing the matcher timeout. Prove It Works required matching browser red and green runs with the original assertions and actual database restart. No narrating comments or compatibility wrappers were added.
