# Exa Answer Draft7 correction

Preserve the approved Fieldnote UI while correcting the documented Exa Answer request contract. This patch does not establish why the real watches response was malformed and does not repair that retained response.

Base `34dbb00ae95e82239123f7e71552b7f74c679bbe`. Red `7680bd0948fe99eabcf252afe179399399b72233`. Fix `9e902bb388bda3bf1b1f6df033208b02faf51a8f`. Branch `fix/exa-answer-draft7` in the owned `research-shopping-exa-draft7` worktree.

The current [official Answer reference](https://exa.ai/docs/reference/answer) specifies JSON Schema Draft7 for `outputSchema`. The existing Zod call emitted the default2020-12 dialect. The installed SDK passes the supplied schema to the `/answer` request body. The one-line fix selects `target: "draft-7"` explicitly. The native schema, prompt, provider, model, response validation, evidence semantics, current and historical envelopes, quota, transport cancellation and UI remain unchanged.

The actual SDK/local HTTP red test records the wire schema, then fails outside the HTTP handler. Its output is:

```
- "$schema": "http://json-schema.org/draft-07/schema#"
+ "$schema": "https://json-schema.org/draft/2020-12/schema"
Tests 1 failed | 38 passed (39)
```

After the one-line correction, the focused suite passes39 tests. The six new paired cases use wholly synthetic labeled fixture material. Three malformed cases reject quotation objects, missing required fields and non-object product-array items without coercion, partial promotion or a retry. Reported cost remains available even when the research is invalid. Three actual SDK cases retain complete literal source quotations and observed SGD29,35 and41 amounts against the fixed SGD30–40 budget. Only35 is eligible and selected. The lower and upper amounts remain visible observations but cannot become choices.

`npm test` passed456 tests in14 files. `npm run build` passed its typecheck and Vite build, with the existing large-chunk advisory. These checks ran on the exact final two-file source patch before the fix commit. An initial evaluator run correctly refused nine report constructions because the application source was uncommitted and did not match the claimed HEAD. No evaluator implementation or expectation was changed. After committing the correction, `npm run eval:test` passed all29 tests at clean9e902bb. The failed provenance run is retained separately from the successful committed run.

The portable owned-wire proof ran at exact clean9e902bb. It sends four actual SDK requests to one owned127.0.0.1 HTTP server. Every request contains the documented Draft7 schema and the full authoritative fixture intent. It independently checks below-minimum, within-bounds, above-maximum and malformed-quotation outcomes, with exact source quotation preservation and failure-cost retention. The proof records `status: passed`, `cleanup: true`, four SDK requests and zero paid calls. It captures only synthetic wire schema and derived outcomes, with no authentication header, provider key, private capture or operator text. Its source hashes identify the two committed changed files.

Run the proof from the checkout root with:

```sh
EXA_RESEARCH_ENABLED=false node --import tsx fieldnote-exa-draft7-wire-proof.mjs
```

The script is preserved in the proof bundle. `owned-wire-proof.json` is under `artifacts/fieldnote-v4/exa-draft7/` in this owned checkout. Maintained regression commands are `EXA_RESEARCH_ENABLED=false npx vitest run tests/api/v2-exa.test.ts`, `npm test`, `npm run build` and `npm run eval:test`.

A fresh read-only Comment Sicko agent reviewed the two-file diff against34dbb00. It reported zero deletion candidates, comments, suppressions, workarounds or unrelated changes. It changed no file. Deletions, restorations, reruns, encodings and unenforced comment constraints are all zero. No architecture sketch was needed for the explicit compiler-target option.

Tracked source is clean. Only `src/server/exa-research.ts` and `tests/api/v2-exa.test.ts` differ from base. No private environment, provider capture, ledger, grant, existing database or live provider was accessed. No GitHub mutation, push, merge, deployment, shared-history rewrite or paid call occurred. All test servers closed. Independent QA/security, current-head CI, live provider compliance and varied real shopping acceptance remain the parent's separate gates.

Model the Domain kept the existing Zod native contract and changed only its external schema dialect. Boundary Discipline preserved rejection of invalid provider shapes and retained reported billing cost. Test Behavior, Not Implementation checked the actual SDK wire payload and observable choices instead of a helper's internal call. Prove It Works required failing-then-passing HTTP evidence and a committed-head proof. Fix Root Causes limited the correction to a documented request mismatch and left the unproven watches cause explicit.
