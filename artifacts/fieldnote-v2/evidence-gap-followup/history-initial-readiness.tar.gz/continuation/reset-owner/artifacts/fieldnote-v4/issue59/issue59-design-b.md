# Candidate B. One availability state

## Problem

Preserve Fieldnote's approved UI while New chat clears only the old draft, blocks submissions into the abandoned conversation, and rejects late reset responses. The parent's browser proof records all three failures at `fe5f849`. A separate owned PostgreSQL proof records a guest reset overwriting the visible signed-in workspace after authentication. These are supplied runtime findings. This candidate is a source-grounded sketch and has not been implemented or run.

## Usage

App keeps the existing hook interface. The textarea remains editable. `ready` means the current conversation can accept a submission or New chat.

```tsx
const { ready, draft, setDraft, send, reset } = useFieldnote();
<Button disabled={!ready} onClick={reset}>New chat</Button>
<InputGroupButton disabled={!ready || !draft.trim()} onClick={() => send(draft)} />
<InputGroupTextarea value={draft} onChange={event => setDraft(event.target.value)} />
```

Enter and contextual controls still call `send()`. That function owns the admission check, so the UI is not the safety boundary. Actual research retains its current activity and Stop control.

## Shape

Replace the private `ready` boolean with one availability state. Do not add a reset flag or mirror ref.

```ts
type Availability = "loading" | "ready" | "resetting";
const [availability, setAvailability] = useState<Availability>("loading");
const ready = availability === "ready";

async function reset(): Promise<void> {
  // Return unless ready. Interrupt existing work and capture generation.current.
  // Set availability to resetting and clear the old draft before awaiting.
  // Await the existing guest or workspace command.
  // Accept state and focus only if the captured generation is still current.
  // Report errors only for that same generation.
  // In finally, restore ready only for that same generation.
  throw new Error("not implemented");
}

function interrupt(): void {
  // Keep current generation, submission, transport and activity behavior.
  // Restore resetting to ready with a functional availability update.
  // Leave loading unchanged.
  throw new Error("not implemented");
}
```

`reload()` changes its existing false and true writes to `loading` and `ready`. Its response protocol and error behavior stay unchanged. `send()` retains its single `!ready` guard. `reset()` adds the same guard, preventing a second reset through the rendered UI. `interrupt()` already runs at authentication, sign-out, and delete-saved transitions. Its generation increment invalidates the old reset before any later success, error, focus, or finally write.

The only public binding change is `disabled={!ready}` on New chat. The existing Send binding consumes the derived boolean. Currency controls may also consume `!ready` for truthful disabled presentation, while the central send guard remains authoritative.

The module map stays two files. `useFieldnote.ts` owns availability, reset ownership, and all acceptance decisions. `App.tsx` renders the existing controls. No API, domain, account-storage, or evidence contract changes.

Model the Domain replaces two independent booleans with one mutually exclusive state. Fix Root Causes moves the draft clear to the explicit reset request and makes stale completion acceptance conditional. Laziness Protocol preserves the existing generation counter and hook interface.

## Synthesis decision

Parent owns selection. This candidate is structurally different from an independent resetting boolean because account loading and reset admission share one tagged availability state.

## Tradeoffs accepted

- We accept changing the existing readiness writes to preserve one canonical availability value.
- We accept a small coupling in `interrupt()` because interruption must revoke an owned pending reset. It restores only resetting, never loading.
- We accept React event rendering as the admission boundary between UI gestures. The supplied proofs use separate browser actions. A synchronous mirror ref would cover a different caller behavior that has not been demonstrated.
- We accept retaining old history until the server confirms reset. This preserves the current recoverable error behavior while keeping new typing separate.

## Alternatives considered

A separate `resetting` state plus existing generation is smaller in the current hook. It keeps account readiness distinct but allows combinations whose meaning must be inferred. It is a reasonable winner if the parent prioritizes minimum line changes and keeps the public readiness expression in one place.

An explicit reset-token ref plus a rendered snapshot closes synchronous repeated hook calls. It adds mirrored state and cleanup coordination without a demonstrated browser need. It loses on reader load and diff size here.

A reset value added to `activity` would reuse a state variable but is unsafe without wider changes. The current send catch can clear activity after interruption. Activity also controls Stop and Exa progress wording. This would spread reset admission into research lifecycle code.

## Risks to verify

The proposed behavior still needs the maintained red browser cases, reset failure recovery, and existing actual-research cancellation checks. Account transitions already call interrupt. Standalone reload and Stop response ownership remain separate unverified races and are not claimed fixed.

## Next implementation step

Choose the availability representation, move the draft clear, and run the existing delayed-response tests before extending any other lifecycle logic.
