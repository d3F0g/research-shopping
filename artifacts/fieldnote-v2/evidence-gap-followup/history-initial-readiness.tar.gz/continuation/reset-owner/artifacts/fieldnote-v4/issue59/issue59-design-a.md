# Candidate A

## Usage

Users can type the next message as soon as they select New chat. The existing hook still exposes `ready`, `send`, and `reset`. App disables New chat while the conversation cannot accept submissions.

```tsx
const { ready, draft, setDraft, send, reset } = useFieldnote();

<Button onClick={reset} disabled={!ready} aria-label="New chat">
	New chat
</Button>

<InputGroupTextarea value={draft} onChange={(e) => setDraft(e.target.value)} />
<InputGroupButton disabled={!ready || !draft.trim()} type="submit" />

<Button disabled={!ready || Boolean(activity)} onClick={() => send(unit, questionId)}>
	{unit}
</Button>
```

The existing Enter, form-submit, and contextual-edit handlers continue calling `send`. The hook rejects those calls while reset is pending. The textarea remains editable. The cancellation control continues to follow actual research activity.

## Shape

```ts
// Existing account-load readiness remains unchanged.
const [ready, setReady] = useState(false);
const [resetting, setResetting] = useState(false);
const generation = useRef(0); // Existing generation.

function interrupt(): void;
async function reset(): Promise<void>;
async function send(
	text: string,
	questionId?: string,
	edit?: PrepareInput["edit"],
	expectedRevision?: number,
): Promise<void>;

return { /* existing return fields */ ready: ready && !resetting };
```

`resetting` represents one independent fact. An outstanding New chat operation still owns the visible conversation. It does not represent research or account loading. `generation` remains the identity used to reject obsolete asynchronous completion.

The implementation stays in `src/client/useFieldnote.ts`. App adds the existing `ready` binding to New chat and the existing currency-choice button. No new exported types or API fields are needed.

The transitions are bounded.

1. `reset` returns immediately when `!ready || resetting`. A repeated click neither dispatches nor clears a newly typed draft.
2. An accepted reset calls `interrupt`, captures `generation.current`, sets `resetting` true, and clears the old draft, error, and focus before awaiting the existing request.
3. `send` extends its first guard with `resetting`. This covers Enter and contextual edits as well as the disabled submit button.
4. Reset success checks the captured generation before applying either the workspace result or guest conversation. Completion never writes the draft.
5. Reset failure checks the same generation before setting the existing error. It retains text typed after reset began.
6. Reset `finally` clears `resetting` only if the captured generation still matches. An obsolete reset cannot reopen controls belonging to a newer reset.
7. `interrupt` clears `resetting` alongside its existing generation increment and transport cancellation. Existing authentication, sign-out through `stop`, and saved-data deletion therefore revoke reset ownership immediately.

Use one generation check after the awaited result and before every success-side write. Put equivalent checks around the catch-side and finally-side writes. There is no asynchronous boundary between a successful check and those writes.

## Problem and evidence

The supplied browser proof records a discarded new draft, a paid-request path using abandoned clarification context, and an older reset response replacing a newer chat. The substitute provider received one local call and zero paid calls. See `/tmp/fieldnote-issue59-repro/proof.json`.

The hook currently clears the draft after the reset request at `src/client/useFieldnote.ts:223`, leaves `send` eligible at line 84, and applies reset responses without identity checks at lines 211 through 222. These decisions explain the observed failures.

The account proof records a held guest reset response replacing the signed-in conversation after it displayed `hello`. The account server still retains `hello`. See `/tmp/fieldnote-issue59-account-repro/proof.json`. `authenticated` already calls `interrupt` at line 232, so the existing generation provides the required invalidation point.

## Rationale and tradeoffs

Fix Root Causes moves draft clearing to the accepted user action and closes `send` before old context can dispatch. It also checks reset completion identity at the state owner.

Model the Domain keeps account readiness and reset ownership separate. Reset is not an Exa activity. The public `ready` flag derives the combined submission permission, so App need not coordinate two flags.

Laziness Protocol reuses the existing generation and account-transition interruption points. The candidate adds one local boolean and no request queue, new reducer, or reload framework.

Separate Before Serializing Shared State favors one outstanding reset because these requests mutate the same canonical conversation. The hook declines duplicate reset initiation instead of allowing competing writes.

The candidate accepts React event-state publication as the current browser contract. It does not add a synchronous mirror ref for unproven calls that invoke the same captured callback twice within one event. Browser tests must verify repeated clicks and Enter during the held response.

## Alternative considered

Reusing `setReady(false)` and restoring it from reset would save the extra boolean, but gives reset responsibility for account readiness. An authentication or sign-out interruption can supersede that responsibility before reset settles. Keeping one reset flag avoids expanding all account readiness paths or allowing stale reset cleanup to mark an account ready.

## Verification and limits

Test Behavior, Not Implementation makes the existing browser outcomes the acceptance contract. Hold success and failure responses, type a new draft, attempt Enter and contextual submission, and assert the retained text and absence of new dispatch. Confirm New chat cannot issue a second overlapping reset. Confirm a normal submission works after release. Repeat the authenticated workspace proof and release the obsolete guest response last. Assert visible history, controls, and draft remain current.

The candidate does not claim broader overlapping-account-reload correctness. That path was not reproduced and needs no new framework for these reset defects. No application files were modified and no runtime verification of this proposed shape was performed.

## Synthesis and next step

The parent owns synthesis against the second candidate. Implement this hook-local reset flag and generation fence, then rerun the held-response browser proofs and failure case.

The design phases completed here are Ground and Sketch. Agree, Implement, and Scrap belong to the parent and were not performed by this design runner.
