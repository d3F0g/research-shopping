# Issue 59 design choice

Candidate A selected. Both candidates retain editable typing, central send admission, reset response identity, unchanged transport semantics, and unchanged UI structure. A adds one private resetting fact and reuses account readiness and operation generation. B replaces account readiness with a loading/ready/resetting union, requiring more lifecycle changes with no stronger result for the reproduced cases. A has the smaller boundary and preserves current account behavior. No graft needed. No synchronous mirror ref because distinct real UI gestures flush React state and no same-event invocation is present.

Configured second architect model gpt-6-luna was unavailable. Candidate B used active-host inheritance. The configured cross-judge pool has no available known distinct family, so cross-judge skipped and owner read/scored both candidates. Relevant criteria were draft preservation, zero old-context dispatch, stale response rejection, preserved account/research semantics and smallest coherent diff. Both designs pass the first four on source analysis; A wins scope. Runtime results are separate and pending.

Task sequence. Reproduce on owned browser done. Add red regression checks done. Compare two bounded designs done. Implement hook and bindings done. Run affected browser/core/build checks pending. Cleanup review, candidate commit and exact-commit smoke pending. Root independent QA/security and GitHub operations remain root-owned.

Throughput checkpoint. Browser and account runtime checks use owned distinct ports and local provider fixtures. Design ran in two waves because root independent QA held a slot. No other application writers share this branch.
