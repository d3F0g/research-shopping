# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v3-evidence-boundaries.spec.ts >> 1440px separates AI fit claims and source previews from eligibility
- Location: tests/e2e/v3-evidence-boundaries.spec.ts:69:3

# Error details

```
Error: expect(locator).not.toBeVisible() failed

Locator:  locator('[data-slot="card"]').filter({ has: getByText('Fixture Meridian Sunglasses - Silver', { exact: true }) }).getByText('Fixture AI claims the selected product fits the requested price range.')
Expected: not visible
Received: visible
Timeout:  6000ms

Call log:
  - Expect "not toBeVisible" locator('[data-slot="card"]').filter({ has: getByText('Fixture Meridian Sunglasses - Silver', { exact: true }) }).getByText('Fixture AI claims the selected product fits the requested price range.') with timeout 6000ms
  - waiting for locator('[data-slot="card"]').filter({ has: getByText('Fixture Meridian Sunglasses - Silver', { exact: true }) }).getByText('Fixture AI claims the selected product fits the requested price range.')
    16 × locator resolved to <p>Fixture AI claims the selected product fits the r…</p>
       - unexpected value "visible"

```

```yaml
- paragraph: Fixture AI claims the selected product fits the requested price range.
```

# Test source

```ts
  4   | import type { TurnResponse } from "../../src/domain/conversation";
  5   | 
  6   | for (const viewport of [{ width: 1440, height: 1000 }, { width: 390, height: 844 }]) {
  7   |   test(`${viewport.width}px rejects money-only fit and ambiguous catalog attribution`, async ({ page }) => {
  8   |     await page.setViewportSize(viewport);
  9   |     await page.route("https://manufacturer.com/**", (route) => route.abort());
  10  |     await page.goto("/");
  11  |     const directory = "artifacts/fieldnote-v4/boundary-browser";
  12  |     await mkdir(directory, { recursive: true });
  13  |     const outcomes = [];
  14  |     const scenarios = [
  15  |       { id: "suffix-money", message: "Find a suffix money-only fixture USB-C powerbank between SGD30 and40", observed: 35 },
  16  |       { id: "bare-money", message: "Find a bare money-only fixture USB-C powerbank", observed: 35 },
  17  |       { id: "spaced-target", message: "Find spaced catalog ambiguity fixture sunglasses between SGD800 and1000", observed: 868 },
  18  |       { id: "bare-variant", message: "Find bare catalog ambiguity fixture sunglasses between SGD800 and1000", observed: 868 },
  19  |       { id: "qualified-target", message: "Find qualified catalog ambiguity fixture sunglasses between SGD800 and1000", observed: 868, adverse: true },
  20  |       { id: "distinct-peer", message: "Find distinct catalog ambiguity fixture sunglasses between SGD800 and1000", observed: 868 },
  21  |     ];
  22  |     for (const scenario of scenarios) {
  23  |       if (outcomes.length) {
  24  |         await page.getByRole("button", { name: "New chat", exact: true }).click();
  25  |         await expect(page.getByRole("heading", { name: "What are you looking for?", exact: true })).toBeVisible();
  26  |       }
  27  |       const response = page.waitForResponse((response) => response.url().endsWith("/api/turn") && response.request().postDataJSON()?.phase === "research");
  28  |       await page.getByRole("textbox", { name: "Message", exact: true }).fill(scenario.message);
  29  |       await page.getByRole("button", { name: "Send message", exact: true }).click();
  30  |       const result = await (await response).json() as TurnResponse;
  31  |       expect(result.kind).toBe("research");
  32  |       if (result.kind !== "research") throw new Error("Expected fixture comparison");
  33  |       expect(result.research.choice).toBeNull();
  34  |       expect(result.research.products.every((product) => product.requestMatch.status === "unknown" && !product.eligible)).toBe(true);
  35  |       const product = result.research.products[0]!;
  36  |       if (scenario.observed === 868) {
  37  |         expect(product.price).toBeNull();
  38  |         expect(product.priceObservation?.amount).toBe(868);
  39  |         expect(product.priceObservation?.row.context.text).toContain("SGD 999");
  40  |       } else expect(product.price?.amount).toBe(scenario.observed);
  41  |       await expect(page.getByText("Fixture data. Automated test substitute.", { exact: true })).toBeVisible();
  42  |       await expect(page.getByText(result.research.summary, { exact: true })).toBeVisible();
  43  |       if (scenario.observed === 868) await expect(page.getByText(/Provider-reported, unverified: Price as listed on Fixture Index/)).toBeVisible();
  44  |       await expect(page.getByRole("textbox", { name: "Message", exact: true })).toBeInViewport();
  45  |       expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  46  |       if ("adverse" in scenario) {
  47  |         await expect(page.getByText(/Source context: For Gold only/)).toBeVisible();
  48  |         await expect(page.getByText(/Provider price assessment contradicted, unverified/)).toBeVisible();
  49  |       }
  50  |       await page.screenshot({ path: `${directory}/${viewport.width}-${scenario.id}.png` });
  51  |       if ("adverse" in scenario) {
  52  |         const disclosure = page.getByRole("button", { name: "Evidence and tradeoffs for Fixture Meridian Sunglasses - Silver", exact: true });
  53  |         await disclosure.click();
  54  |         await expect.poll(() => disclosure.evaluate((element) => element.parentElement!.querySelector("[data-slot=trace-collapsible-content]")!.getAnimations().length)).toBe(0);
  55  |         const context = page.locator("blockquote").filter({ hasText: "New Silver colorway" });
  56  |         await expect(context).toContainText("SGD 999");
  57  |         await expect(context).toContainText("For Gold only.");
  58  |         await context.evaluate((element) => element.scrollIntoView({ block: "end" }));
  59  |         await expect(context).toBeInViewport();
  60  |         await page.screenshot({ path: `${directory}/${viewport.width}-${scenario.id}-context.png`, animations: "disabled" });
  61  |       }
  62  |       outcomes.push({ id: scenario.id, summary: result.research.summary, choice: result.research.choice, products: result.research.products });
  63  |     }
  64  |     await writeFile(`${directory}/${viewport.width}-proof.json`, JSON.stringify({ commit: execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(), viewport, fixtureOnly: true, outcomes }, null, 2) + "\n");
  65  |   });
  66  | }
  67  | 
  68  | for (const viewport of [{ width: 1440, height: 1000 }, { width: 390, height: 844 }]) {
  69  |   test(`${viewport.width}px separates AI fit claims and source previews from eligibility`, async ({ page }) => {
  70  |     await page.setViewportSize(viewport);
  71  |     const directory = "artifacts/fieldnote-v4/card-interpretation";
  72  |     await mkdir(directory, { recursive: true });
  73  |     const rationale = "Fixture AI claims the selected product fits the requested price range.";
  74  |     const productName = "Fixture Meridian Sunglasses - Silver";
  75  |     let unresolved = true;
  76  |     let literal = "";
  77  |     await page.route("https://manufacturer.com/**", (route) => route.fulfill({
  78  |       contentType: "image/svg+xml",
  79  |       body: '<svg xmlns="http://www.w3.org/2000/svg" width="180" height="100"><rect width="180" height="100" fill="#777"/><text x="90" y="55" text-anchor="middle" fill="white">Fixture page preview</text></svg>',
  80  |     }));
  81  |     await page.route("**/api/session", async (route) => {
  82  |       const response = await route.fetch();
  83  |       const body = await response.json();
  84  |       if (unresolved) for (const message of body.state.messages) {
  85  |         const snapshot = message.research;
  86  |         if (!snapshot) continue;
  87  |         const product = snapshot.products.find((entry: { name: string }) => entry.name === productName);
  88  |         if (!product) continue;
  89  |         product.requestMatch.rationale = rationale;
  90  |         const source = snapshot.sources.find((entry: { id: string }) => entry.id === product.identity.support[0]?.sourceId);
  91  |         if (source) source.imageUrl = "https://manufacturer.com/fixture-page-preview.svg";
  92  |         literal = product.identity.support[0].context.text;
  93  |       }
  94  |       await route.fulfill({ response, json: body });
  95  |     });
  96  |     await page.goto("/");
  97  |     const composer = page.getByRole("textbox", { name: "Message", exact: true });
  98  |     await composer.fill("Find spaced catalog ambiguity fixture sunglasses between SGD800 and1000");
  99  |     await page.getByRole("button", { name: "Send message", exact: true }).click();
  100 |     const card = page.locator('[data-slot="card"]').filter({ has: page.getByText(productName, { exact: true }) });
  101 |     await expect(card.getByText("SGD 868.00", { exact: true })).toBeVisible();
  102 |     await expect(card.getByText(/^Applicability to the selected variant is unresolved/)).toBeVisible();
  103 |     await expect(card.getByText(/^Unresolved:/)).toBeVisible();
> 104 |     await expect(card.getByText(rationale, { exact: false })).not.toBeVisible();
      |                                                                   ^ Error: expect(locator).not.toBeVisible() failed
  105 |     await expect(card.getByText("Source-supported option", { exact: true })).toHaveCount(0);
  106 |     const preview = card.getByRole("img", { name: `Source page preview for ${productName}`, exact: true });
  107 |     await expect(preview).toBeVisible();
  108 |     await expect.poll(() => preview.evaluate((image: HTMLImageElement) => image.complete && image.naturalWidth > 0)).toBe(true);
  109 |     await expect(card.getByText("Source page preview. Product image and exact variant unverified.", { exact: true })).toBeVisible();
  110 |     await expect(page.getByText(productName, { exact: true })).toBeInViewport();
  111 |     await expect(composer).toBeInViewport();
  112 |     await page.screenshot({ path: `${directory}/${viewport.width}-unresolved.png` });
  113 |     const disclosure = card.getByRole("button", { name: `Evidence and tradeoffs for ${productName}`, exact: true });
  114 |     await disclosure.scrollIntoViewIfNeeded();
  115 |     await disclosure.focus();
  116 |     await disclosure.press("Enter");
  117 |     const interpretation = card.getByText(rationale, { exact: false });
  118 |     await expect(interpretation).toBeVisible();
  119 |     await expect(interpretation).toContainText("AI assessment, unverified:");
  120 |     await expect(card.locator("blockquote").first()).toHaveText(literal, { useInnerText: true });
  121 |     await interpretation.scrollIntoViewIfNeeded();
  122 |     await expect(composer).toBeInViewport();
  123 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  124 |     await page.screenshot({ path: `${directory}/${viewport.width}-assessment.png`, animations: "disabled" });
  125 |     const original = await page.request.get("/api/session").then((response) => response.json());
  126 |     const retained = original.state.messages.find((message: { research?: { products: { name: string }[] } }) => message.research?.products[0]?.name === productName).research;
  127 |     expect(retained.products[0].price).toBeNull();
  128 |     expect(retained.products[0].eligible).toBe(false);
  129 |     expect(retained.choice).toBeNull();
  130 |     expect(retained.products[0].identity.support[0].context.text).toBe(literal);
  131 |     unresolved = false;
  132 |     await page.getByRole("button", { name: "New chat", exact: true }).click();
  133 |     await composer.fill("Find a fixture powerbank between SGD30 and40");
  134 |     await page.getByRole("button", { name: "Send message", exact: true }).click();
  135 |     const eligible = page.locator('[data-slot="card"]').filter({ has: page.getByText("Fixture Powerbank Model A", { exact: true }) });
  136 |     await expect(eligible.getByText("Source-supported option", { exact: true })).toBeVisible();
  137 |     await expect(eligible.getByRole("img", { name: "Source page preview for Fixture Powerbank Model A", exact: true })).toBeVisible();
  138 |     await expect(page.getByText(/^Fixture Powerbank Model A is a source-supported option/)).toBeInViewport();
  139 |     await expect(composer).toBeInViewport();
  140 |     await page.screenshot({ path: `${directory}/${viewport.width}-eligible.png` });
  141 |     await writeFile(`${directory}/${viewport.width}-proof.json`, JSON.stringify({ commit: execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(), viewport, fixtureOnly: true, providerRationale: rationale, literalContext: literal, eligibilityUnchanged: true, keyboardDisclosure: true }, null, 2) + "\n");
  142 |   });
  143 | }
  144 | 
```