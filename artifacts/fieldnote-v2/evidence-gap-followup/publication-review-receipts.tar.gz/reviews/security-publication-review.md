# Public exposure scan and sanitized-tree binding

**Sanitized-tree scope PASS; exposed-history HOLD.** Application security PASS remains bound to `fd1f505c116e5112af5597292c5f6c1d9499b824`. Current tip `5717e0f832fdb300761deb2ae6cc26a72739be4b` and local candidate `0da9a7ac49e04cf65f72274a14606ae931bea62c` share tree `9ee56d4e402c64c292a0ce8f0190bf2ccbf54975`. All 244 nonmetadata entries match the reviewed application by Git mode/type/blob. Only resume, state and decision-log metadata changed from exposed `7f1f5cd5b2818ad76432cf2582e1bc445bbb7266`. No heavy runtime tests were repeated.

Confirmed public disclosure locations at 7f, without reproducing values:

- `.codex/pstack-runs/fieldnote-v2/resume.md:39`: raw human-case detail and absolute private capture path/basename.
- `.codex/pstack-runs/fieldnote-v2/resume.md:21` and `:37`: absolute private diagnostics-directory references.
- File SHA256: `d91326f66d4e3098c19b29ad5dfd9dada69e32d1abc82c5ef110806feba48329`.

The recursive public-only scan covered 53 changed Git paths, 3589 UTF-8 files, 33 tar archives, 50 trace ZIPs and 937409518 plaintext bytes. No depth/size/error skips occurred. Eight additional matches are generic fixture quotation-tail overlap on explicitly Fixture-marked QA source lines; they do not reproduce the identifying quote prefix or private path. Their exact nested paths, line numbers, digests and classifications are recorded in `public-exposure-scan-7f1f5cd.json`. No credential-like token/assignment pattern was detected. That is not a guarantee that every possible credential form is absent. Binary image contents were not OCR-scanned.

The 571 metadata was read and checked. It contains sanitized operational facts, an explicit publication correction, the shared-history restriction and outstanding live acceptance. It contains none of the known private capture path/basename or identifying quote-prefix signatures, and no absolute private diagnostics path. All archives are unchanged from the scanned 7f tree.

The current tip 571 still has 7f as its parent, so the earlier exposure remains in shared history. The local candidate 0da has fd1 as parent and does not have 7f as an ancestor, but its identical sanitized tree does not establish removal from remote history, caches, PR references or existing copies. No rewrite, force-push, GitHub operation, private-file access, credential change or deployment was performed. Root retains authorization and remediation decisions. The old metadata/publish PASS was withdrawn and remains withdrawn for 7f.

Commands included `git diff --name-only 7f1f5cd 5717e0f832fdb300761deb2ae6cc26a72739be4b`, `git show` for the three changed metadata blobs, complete nonmetadata `git ls-tree -r` comparisons with fd1, `git rev-parse <commit>^{tree}`, `git rev-parse 0da9a7ac49e04cf65f72274a14606ae931bea62c^`, and `git merge-base --is-ancestor 7f1f5cd <commit>`. A bounded inline Python hashlib/tarfile/zipfile scan read public Git blobs and nested members in memory, without extracting or executing them. Match seeds came only from the already-public 7f resume. No private capture, environment, key, ledger, grant, existing database or unrelated session was opened.

Full60 remains inconclusive and varied manual live usefulness remains outstanding. A sanitized-tree binding is not complete historical erasure, CI approval, product acceptance or merge approval.
