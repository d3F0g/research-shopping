# Issue 56 security and publication-tree review

Verdict: **SCOPED SECURITY / CURRENT PUBLICATION-TREE PASS** for `d4648c98217f7e3333e471235f68649ef0c0b649`. **Exposed-history HOLD and varied live acceptance remain outstanding.** Original application base is `33fadc7e3cfde2207528adb32b650287e758d343`; the runtime-reviewed application head is `fd1f505c116e5112af5597292c5f6c1d9499b824`; the prior sanitized metadata tip is `5717e0f832fdb300761deb2ae6cc26a72739be4b`.

The owned checkout is detached at the exact reviewed head with no application edits. All 243 other nonmetadata entries match fd1 by Git mode/type/blob. The only nonmetadata delta is `scripts/verify-evidence-history.ts`, blob `2c6427aeb4054fe59e76339059ce81134ae24eda`. Application, UI, tests, evaluator, dependencies, configuration, workflows and project skills remain identical to the scoped application PASS. Eleven metadata/evidence paths changed from the sanitized tip.

## Verifier boundary

The response waiter is registered before reload and belongs to the browser page. It matches the exact owned origin and `/api/account` URL plus GET method; a separate control API request cannot satisfy it. The verifier requires HTTP 200, signed-in status and equality of the entire saved workspace before running the unchanged default five-second visible-amount assertion. No prior assertion, timeout, fixture check, isolation check or stale-dispatch check was removed or relaxed. There is no sleep or retry around the failing assertion.

The 5500 ms CDP rule targets only that exact owned account URL on the mobile context. It persists as a regression condition, rather than manufacturing a response. Context/browser closure disposes of the CDP session. The fixture runtime binds loopback ports, accepts only owned temporary PostgreSQL or the exact CI fixture service, explicitly disables live Exa, clears the real key/ledger configuration, and constructs the SDK with its own loopback substitute and test credential. The new code adds no external destination or private-data reader.

Diagnostic events contain event type, timestamp, optional status and error message; they do not read headers, cookies or request/response bodies. Failure DOM text is capped at 30000 characters and comes from the explicit fixture browser. Event/message collection is not separately count/length capped, so this is a fixture-scoped diagnostic, not a general private production logging facility. It must remain in that composition. The recorded failure JSON contains a 144-character empty/loading DOM prefix. I viewed its archived screenshot: it shows the empty/loading UI, with no private captured shopping content.

The success marker follows full account validation and the original visible-amount assertion. A rejected waiter, reload, response decode, assertion or diagnostic write cannot mark the proof passed. Promise.all observes both response and reload promises, and the existing outer finally closes browser/runtime and writes the proof. Diagnostics failing can mask an earlier failure, but cannot turn it into a pass. Existing initialization/cleanup edge cases were not newly exercised; no cleanup redesign was introduced.

## Evidence and runtime attribution

The committed Issue 56 archive SHA256 is `d4bebb4162c0506fd9863f24b76910b9b6b6b7c0cb67a9beefae90d50af6207c`. All 14 regular relative members match manifest sizes and hashes, with no traversal or links. The exact verifier blob matches author head `44d2ec292f49dadda80a7ca58897808a7fcbbb44`. Its preserved green proof records both viewports passed and cleanup true. The mobile event timeline records the browser account response 5524 ms after page load, followed by validation. The desktop timeline records 41 ms. The preserved controlled red and original CI proofs remain failed records with cleanup true.

These are inspected author artifacts, not a claim that security reran the full browser/PG gate. Independent QA is separately running the maintained gate on exact d464. Per the assigned scope, I did not duplicate that heavy journey. The independent application runtime security evidence remains bound to unchanged fd1 application code. The original CI failure's exact browser latency remains unproven; the controlled regression supports the verifier synchronization correction without inventing that missing measurement.

An initial archive-check helper accidentally applied the reload-event schema to every JSON file because the directory name also contains reload. I corrected the reviewer check to inspect the filename. It then validated both success event files and the failure diagnostic file; no application or test source was modified.

## Publication review

The new resume/state/decision entries retain sanitized operational facts, explicit history-remediation limits, and the outstanding live acceptance gate. AGENTS adds a publication check and prohibits private operator text, capture locators and configuration in tracked handoffs. The workflow document replaces an incorrect timeless private-visibility assertion with a dated root observation and a requirement to check live visibility. This review did not query GitHub or independently certify its current visibility.

A targeted scan covered the changed public plaintext and every text member of the new archive: 24 text files total, plus visual inspection of the one failure PNG. It found no known raw identifying-case prefix, private capture locator, absolute private diagnostics path or credential-like token pattern. This is bounded detection, not a guarantee against every unknown sensitive value. Other archives are unchanged from the prior public recursive scan and retain that scan's explicit limits.

`7f1f5cd5b2818ad76432cf2582e1bc445bbb7266` remains an ancestor of d464. Therefore current-tree sanitization is not shared-history erasure. The earlier metadata/publish PASS remains withdrawn for the exposed tree. This review authorizes neither a force-push nor removal of shared history; those decisions remain with root and the required fresh authorization. The obsolete local history proposal was not reused or approved here.

## Commands and artifacts

Commands ran in `/Users/josiahwong/Documents/research-shopping-v2-evidence-security`:

```sh
git checkout --detach d4648c98217f7e3333e471235f68649ef0c0b649
git diff --stat 5717e0f832fdb300761deb2ae6cc26a72739be4b..d4648c98217f7e3333e471235f68649ef0c0b649
git diff fd1f505c116e5112af5597292c5f6c1d9499b824..d4648c98217f7e3333e471235f68649ef0c0b649 -- scripts/verify-evidence-history.ts
git show d4648c9:scripts/verify-evidence-history.ts
git show d4648c9:scripts/account-test-runtime.mjs
git show d4648c9:tests/helpers/account-runtime.ts
git show d4648c9:scripts/test-postgres.mjs
git show d4648c9:.github/workflows/ci.yml
git diff 5717e0f..d4648c9 -- AGENTS.md docs/engineering-workflow.md docs/fieldnote-evidence-followup.md .audit/fieldnote-v2/evidence-gap/history-reload-issue56.md .codex/pstack-runs/fieldnote-v2/resume.md .codex/pstack-runs/fieldnote-v2/state.json
git ls-tree -r fd1f505c116e5112af5597292c5f6c1d9499b824
git ls-tree -r d4648c98217f7e3333e471235f68649ef0c0b649
git merge-base --is-ancestor 7f1f5cd d4648c9
```

Inline Python standard-library checks compared the nonmetadata Git entries, authenticated archive/member bytes with hashlib/tarfile, validated recorded event keys and DOM bounds, compared exact verifier blobs, inspected proof/timeline values, and scanned only the new public material for known exposure signatures. Results are in `artifacts/fieldnote-v2/evidence-gap-security/v4/issue56-security-binding-d4648c9.json`; the inspected public screenshot is `issue56-red-failure.png` beside it.

No private file, environment, key, ledger, grant, real database, real provider, paid action, GitHub mutation, deployment or merge was accessed. No independent permission sandbox is claimed. The full application suite was not rerun because application behavior is unchanged. Current-head CI and independent QA still need their own receipts. Full60 remains inconclusive, and varied manual live usefulness is not established. This is a pre-publication security/tree review, not a merge or complete-history-remediation PASS.
