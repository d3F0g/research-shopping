# Independent QA: Issue56 final candidate

Verdict: **PASS within verifier/runtime, unchanged application/visual, and targeted current-tree publication scope.** This is not merge approval: current hosted CI and varied live product acceptance remain outstanding.

Reviewed exact head `d4648c98217f7e3333e471235f68649ef0c0b649`. Application baseline and previous independent code/visual PASS: `fd1f505c116e5112af5597292c5f6c1d9499b824`. Metadata comparison baseline: `5717e0f832fdb300761deb2ae6cc26a72739be4b`. Reviewer did not author the change or modify application files. Owned checkout: `/Users/josiahwong/Documents/research-shopping-v2-evidence-qa`.

## Fresh exact-head runtime proof

Read installed poteto workflow, project verification skill, project AGENTS and affected script. Executed the actual maintained `scripts/verify-evidence-history.ts`, equivalent to package target `verify:evidence:history`, without editing/copying it. Used sanitized allowlisted process environment (`PATH`, `HOME`, `TMPDIR`, locale/timezone when present, `NODE_ENV=test`, `EXA_RESEARCH_ENABLED=false`). Existence-only checks established no Vite .env files in this isolated checkout. No env contents, credentials, private capture, ledger, grant, existing database, billable provider or GitHub action was accessed.

Execution command inside the sanitized child environment:

```sh
node --import tsx scripts/verify-evidence-history.ts
```

The maintained proof reports exact head, `status: passed`, `cleanup: true`. It started its own temporary PostgreSQL17, actual API/auth/Hono/SDK loopback substitute and browser. Both 1440×1000 and390×844 passed: unchanged V2/V3 historical messages beside V4 observations; stale prepared request interrupted with no SDK dispatch; second account isolation; PostgreSQL/API restart; exact saved workspace restored; observed868 remains an unverified source row with unresolved applicability and fit. Mobile delayed only browser account endpoint by5500ms. Actual account response arrived5515ms after page-loaded; HTTP200, signed-in status and exact saved workspace were validated before the existing default five-second amount rendering assertion passed. No render timeout enlargement, arbitrary sleep, generic retry or dropped migration/history/isolation assertion.

Fresh evidence (relative to checkout):

- `artifacts/fieldnote-v2/evidence-gap-qa/d4648c9/maintained-history.log`
- `artifacts/fieldnote-v4/history-browser/proof.json`
- `artifacts/fieldnote-v4/history-browser/1440-reload.json`
- `artifacts/fieldnote-v4/history-browser/390-reload.json`
- Four inspected PNGs in that directory: `1440-current-observation.png`, `1440-literal-evidence.png`, `390-current-observation.png`, `390-literal-evidence.png`.

Screenshots retain dark chat-first minimal header, centered conversation and compact bottom composer, fixture labels, useful observed amount first, prominent unresolved attribution/purchase conditions/fit, concise collapsed evidence and readable expanded literal evidence. Mobile quotation sits above the accessible composer; no horizontal overflow. Details scroll within the conversation rather than displacing the composer. New app/UI code is absent.

The seven product principles remain bound to the previous exact application proof: (1) open objective and necessary clarifications, (2) separate hard constraints/preferences, (3) attributable uncertain evidence, (4) useful observation first, (5) concise disclosure-based detail, (6) session preference and presentation adaptation, (7) no redundant notifications. Fresh history/UI proof directly rechecks3–5 and retained session state; unchanged source binding carries the earlier broader runtime matrix, not a claim of fresh rerunning every scenario. Prior fd1 actual tests included budget changes, ambiguity, unavailable/conflicting evidence, dissatisfaction, provider errors, merchant-link policy, ordinary messages, theme persistence and isolation; no source changed beneath those results.

## Source equality and deliberate reuse

Commands:

```sh
git rev-parse HEAD
git diff --name-only fd1f505c116e5112af5597292c5f6c1d9499b824 HEAD -- src tests evals .github package.json package-lock.json .agents/skills/verify-research-shopping vite.config.ts vitest.config.ts vitest.postgres.config.ts playwright.config.ts tsconfig.json
git diff --name-only fd1f505c116e5112af5597292c5f6c1d9499b824 HEAD -- scripts
git diff 5717e0f832fdb300761deb2ae6cc26a72739be4b HEAD -- .codex/pstack-runs/fieldnote-v2 AGENTS.md docs .audit/fieldnote-v2/evidence-gap artifacts/fieldnote-v2/evidence-gap-followup/EVIDENCE.md
```

First scoped diff is empty. Scripts diff contains only `scripts/verify-evidence-history.ts`. Thus application/UI/CSS, tests, evals, workflows, packages and official verification skill are byte-identical to independently passed fd1. Reuse previous450 unit/API,29 current eval,10 browser, both TypeScript checks, build, official registry and three-viewport verification skill results; those broad suites were not repeated for this isolated verifier change. Previous full60 result remains11passed/48blocked/1unsupported/0failed/0critical/0infra140turns; it does not establish broad product acceptance. The maintained exact-head history verifier was freshly run, replacing reliance on owner summaries.

## Current-tree public metadata scope

Read changed metadata, guard, engineering workflow correction, state/resume/decisions, evidence index and Issue56 report. They distinguish controlled delay reproduction from unknown original CI cause, current-tip correction from historical removal, owner runs from independent runs, and code proof from outstanding live acceptance. The PUBLIC repository statement is root's reported live GitHub verification, not an independent GitHub lookup by this reviewer.

Scanned175 committed public plaintext metadata files with previously captured quotation/identity/provider and private-location needles derived exclusively from the already-public7f Git blob without printing values: zero matches. This is targeted known-exposure detection, not comprehensive secret detection. Existing generic location references in unchanged earlier issue snapshots were previously reported separately and are not newly introduced captured-case copies.

Verified exact committed `history-reload-issue56.tar.gz` SHA256 `d4bebb4162c0506fd9863f24b76910b9b6b6b7c0cb67a9beefae90d50af6207c`; all14 manifest members are unique regular relative files with safe paths, matching size and SHA256. Parsed7 JSON members; scanned textual members with the same needles, zero matches. Contents are the explicitly synthetic controlled-red/fix verifier evidence. No private file was opened. Machine-readable binding/publication result:
`artifacts/fieldnote-v2/evidence-gap-qa/d4648c9/publication-and-binding.json`.

## Limits and remaining gates

No code/visual/verifier or targeted current-tip publication blocker found. Original hosted CI network latency is unproven; this checks the durable artificial latency regression and correct browser bootstrap synchronization. Root must inspect actual current-head hosted CI after authorized push.

Varied real request-to-comparison-and-recommendation usefulness remains outstanding. Synthetic/API/browser/history results and source counts cannot pass it. Root holds merge for that existing product acceptance gate; no additional human design approval is introduced.

Earlier7f remains in shared ancestry. Current-tree cleanliness does not erase earlier objects, clones or caches. No history mutation, force push or GitHub write was performed or authorized by this review. No paid or private-data checks were performed.
