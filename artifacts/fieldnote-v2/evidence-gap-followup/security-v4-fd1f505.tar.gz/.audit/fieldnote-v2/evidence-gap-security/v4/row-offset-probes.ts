import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { initialConversation } from '../../../../src/domain/conversation';
import { ResearchSnapshotSchema } from '../../../../src/domain/research';
import { projectExaAnswer } from '../../../../src/server/exa-research';
import { validCurrentProvenance } from '../../../../evals/v2/provenance';
import { catalogMaterial } from '../../../../tests/helpers/v3-catalog-material';
const head=process.env.REVIEW_HEAD!;
const intent={...initialConversation().intent,productDescription:'Fixture sunglasses',budget:{minimum:800,maximum:1000,currency:'SGD'}};
const name='Fixture Meridian Sunglasses - Silver';
const results=[];
for(const row of [`${name} \n\n SGD 868 `,`${name}\r\n\tSGD\t868 \t`,`${name}\n\n\tSGD 868\t`,`${name}\n\n 868 SGD `]){
 const raw=catalogMaterial(intent);raw.citations[0]!.text=raw.citations[0]!.text.replace(`${name} \n\n SGD 868 `,row)+'\n\nFixture context\n\nSGD 999';
 if(row.includes('868 SGD')){raw.answer.products[0]!.identity.support[0]!.quote=`${name} 868 SGD`;raw.answer.products[0]!.price.assessment.support[0]!.quote='868 SGD';}
 const result=projectExaAnswer(raw,intent);assert.equal(result.status,'ready');if(result.status!=='ready')throw new Error('Expected fixture');
 const p=result.research.products[0]!,obs=p.priceObservation!;assert.equal(p.price,null);assert.equal(obs?.amount,868);assert.equal(obs.row.literal.text,row);assert.equal(obs.row.literal.start,raw.citations[0]!.text.indexOf(row));assert.equal(obs.row.literal.end,obs.row.literal.start+row.length);assert.equal(obs.row.context.text,raw.citations[0]!.text);assert(ResearchSnapshotSchema.safeParse(result.research).success);assert(validCurrentProvenance(result.research,p,raw));results.push({row,start:obs.row.literal.start,end:obs.row.literal.end,price:null,amount:obs.amount});
}
await writeFile(`artifacts/fieldnote-v2/evidence-gap-security/v4/row-offset-probes-${head.slice(0,7)}.json`,JSON.stringify({head,fixtureOnly:true,status:'pass',results},null,2));console.log(JSON.stringify({head,passed:results.length}));
