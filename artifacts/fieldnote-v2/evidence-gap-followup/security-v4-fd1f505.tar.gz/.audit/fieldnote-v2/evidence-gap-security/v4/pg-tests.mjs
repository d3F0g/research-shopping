import { spawn, spawnSync } from 'node:child_process';
import { mkdtemp, readdir, readFile, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { fixtureDatabase } from '../../../../scripts/test-postgres.mjs';
const root=await mkdtemp('/tmp/fieldnote-security-v3-');
process.env.TMPDIR=root;
let fixture;
try {
 fixture=await fixtureDatabase();
 const child=spawn(process.execPath,['node_modules/vitest/vitest.mjs','run','--config','vitest.postgres.config.ts','--no-cache','--configLoader','runner','--reporter=json','--outputFile=artifacts/fieldnote-v2/evidence-gap-security/v4/8ea7db2-postgres-tests.json'],{stdio:'inherit',env:{PATH:process.env.PATH,TMPDIR:root,EXA_RESEARCH_ENABLED:'false',TSX_DISABLE_CACHE:'1',NODE_ENV:'test',FIELDNOTE_TEST_DATABASE_URL:fixture.url}});
 const code=await new Promise(resolve=>child.once('exit',resolve));
 if(code!==0)throw new Error(`Owned PostgreSQL tests failed with ${code}`);
} catch(error) {
 for(const entry of await readdir(root)){try{console.error(await readFile(join(root,entry,'postgres.log'),'utf8'));}catch{}}
 throw error;
} finally {
 if(fixture)await fixture.stop();
 else for(const entry of await readdir(root))spawnSync('/opt/homebrew/bin/pg_ctl',['-D',join(root,entry,'data'),'-m','fast','-w','stop'],{stdio:'ignore'});
 await rm(root,{recursive:true,force:true});
}
