import assert from 'node:assert/strict';
import { createServer, type Server } from 'node:http';
import { randomUUID } from 'node:crypto';
import { writeFile } from 'node:fs/promises';
import { getRequestListener } from '@hono/node-server';
import { createApp } from '../../../../src/server/app';
import { createConversationService } from '../../../../src/server/conversations';
import { createExaProductResearch } from '../../../../src/server/exa-research';
import { nativeMaterial } from '../../../../tests/helpers/v2-material';
import { catalogMaterial } from '../../../../tests/helpers/v3-catalog-material';
const head=process.env.REVIEW_HEAD!;
const results:any[]=[];
const servers:Server[]=[];
async function listen(server:Server){servers.push(server);await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));const address=server.address();assert(address&&typeof address!=='string');assert.equal(address.address,'127.0.0.1');return `http://127.0.0.1:${address.port}`;}
try {
 for(const scenario of [
  {kind:'money',quote:null},
  {kind:'money',quote:'35 SGD'},
  {kind:'money',quote:'35'},
  {kind:'money',quote:'35 Singapore dollars'},
  {kind:'money',quote:'Singapore dollars 35'},
  {kind:'money',quote:'(35 SGD)'},
  {kind:'money',quote:'35 SGD.'},
  {kind:'money',quote:'SGD35–40'},
  {kind:'money',quote:'Price: SGD 35, tax included.'},
  {kind:'money',quote:'35 SGD / unit'},
  {kind:'catalog',heading:null},
  {kind:'catalog',heading:'Fixture Other Silver Sunglasses'},
  {kind:'catalog',heading:'Silver'},
  {kind:'catalog',heading:'Silver colorway'},
  {kind:'catalog',heading:'Meridian Sunglasses Silver Edition'},
  {kind:'catalog',heading:'Spring collection'},
  {kind:'catalog',heading:'Gift set'},
  {kind:'catalog',heading:'For Gold only.'},
 ]){
  let calls=0;const reservations:any[]=[];const settlements:any[]=[];const logs:any[]=[];
  const upstream=await listen(createServer(async(request,response)=>{
   calls++;let input='';for await(const chunk of request)input+=chunk;
   const intent=JSON.parse(JSON.parse(input).systemPrompt.split('Current authoritative shopping intent: ')[1]);
   let raw:any=scenario.kind==='money'?nativeMaterial(intent):catalogMaterial(intent);
   if(scenario.kind==='money'&&scenario.quote){
    const money=scenario.quote==='35'?'SGD 35':scenario.quote;
    raw=JSON.parse(JSON.stringify(raw).replaceAll('SGD 35',money));
    raw.answer.products[0].requestMatch=structuredClone(raw.answer.products[0].requestMatch);
    raw.answer.products[0].requestMatch.support=[{url:raw.citations[0].url,quote:scenario.quote}];
   }
   if(scenario.kind==='catalog'&&scenario.heading)raw.citations[0].text+=`\n\n${scenario.heading}\n\nSGD 999`;
   response.setHeader('content-type','application/json');response.end(JSON.stringify(raw));
  }));
  const sdk=createExaProductResearch('FIXTURE_ROUND2_KEY',{baseUrl:upstream,timeoutMs:1500});
  const research=async(...args:Parameters<typeof sdk>)=>{const result=await sdk(...args);if(result.status==='ready')result.research.dataKind='test-fixture';return result;};
  const conversations=createConversationService({research,quota:{reserve:async(...args)=>{reservations.push(args);return 'admitted';},settle:async(...args)=>{settlements.push(args);}}});
  const server=createServer();const base=await listen(server);
  const app=createApp({conversations,logger:event=>logs.push(event)},{apiPort:Number(new URL(base).port)});
  server.on('request',getRequestListener(app.fetch));
  const session=await fetch(base+'/api/session');const cookie=session.headers.get('set-cookie')!.split(';')[0]!;
  const post=async(body:any)=>{const response=await fetch(base+'/api/turn',{method:'POST',headers:{cookie,'content-type':'application/json',origin:'http://127.0.0.1:5173'},body:JSON.stringify(body)});assert.equal(response.status,200);return response.json();};
  const prepared=await post({phase:'prepare',operationId:randomUUID(),message:scenario.kind==='money'?'Find fixture USB-C powerbank between SGD30 and40':'Find fixture sunglasses between SGD800 and1000'});
  assert.equal(prepared.kind,'prepared');
  const response=await post({phase:'research',preparedId:prepared.preparedId});
  assert.equal(response.kind,'research');
  const snapshot=response.research,product=snapshot.products[0];
  assert.equal(snapshot.dataKind,'test-fixture');assert.equal(calls,1);assert.equal(reservations.length,1);assert.equal(settlements.length,1);
  assert(!JSON.stringify(logs).includes('FIXTURE_ROUND2_KEY'));
  const observation=product.priceObservation;
  const expectedSafe=scenario.kind==='money'?scenario.quote===null?product.requestMatch.status==='supported'&&snapshot.choice?.productId==='model-a':product.requestMatch.status==='unknown'&&snapshot.choice===null:product.price===null&&observation?.amount===868&&observation.currency==='SGD'&&observation.attribution.status==='unknown'&&!('variant' in observation)&&observation.row.origin.kind==='source-context'&&observation.row.context.start===0&&observation.row.context.end===snapshot.sources[0].text.length&&observation.row.context.text===snapshot.sources[0].text&&observation.reportedAssessment.support[0].origin.reportedQuote==='SGD 868'&&!observation.reportedConditionsResolved&&snapshot.choice===null&&!product.eligible;
  assert.equal(snapshot.evidenceVersion,4);
  if(scenario.kind==='catalog'&&scenario.heading)assert(observation?.row.context.text.includes(scenario.heading+'\n\nSGD 999'));
  results.push({scenario,requestMatch:product.requestMatch.status,price:product.price&&{amount:product.price.amount,conditionsResolved:product.price.conditionsResolved},priceObservation:observation,eligible:product.eligible,choice:snapshot.choice,calls,reservations:reservations.length,settlements:structuredClone(settlements),expectedSafe});
  for(const active of servers.splice(0)){active.closeAllConnections();await new Promise<void>(resolve=>active.close(()=>resolve()));}
 }
}finally{for(const server of servers){server.closeAllConnections();await new Promise<void>(resolve=>server.close(()=>resolve()));}}
const report={head,fixtureOnly:true,results};
await writeFile(`artifacts/fieldnote-v2/evidence-gap-security/v4/structural-runtime-${head.slice(0,7)}.json`,JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
assert(results.every(row=>row.expectedSafe),'Money-only fit must be unknown and catalog rows must remain unattributed observations');
