import assert from 'node:assert/strict';
import { createServer, type Server } from 'node:http';
import { randomUUID } from 'node:crypto';
import { writeFile } from 'node:fs/promises';
import { getRequestListener } from '@hono/node-server';
import { createApp } from '../../../../src/server/app';
import { createConversationService } from '../../../../src/server/conversations';
import { createExaProductResearch } from '../../../../src/server/exa-research';
import { nativeMaterial } from '../../../../tests/helpers/v2-material';
import { catalogMaterial } from '../../../../tests/helpers/v3-catalog-material';
const head=process.env.REVIEW_HEAD!;
const results:any[]=[];
const servers:Server[]=[];
async function listen(server:Server){servers.push(server);await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));const address=server.address();assert(address&&typeof address!=='string');assert.equal(address.address,'127.0.0.1');return `http://127.0.0.1:${address.port}`;}
try {
 for(const scenario of [{"kind": "money", "quote": "SGD35 plus SGD5", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35plusSGD5", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 minus SGD5", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35minusSGD5", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 times 3", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35times3", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 multiplied by 3", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 divided by 3", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "3 X SGD35", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 X 3 x 2", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 x 3", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35x3", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 each", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 per piece", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 per item", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 for one item", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 for 3 pieces", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 excl. GST", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 incl. tax", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 excl VAT", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 incl GST", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 excl.GST", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 incl.tax", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 excluding\nGST", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 including\ntax", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 for\t3\tunits", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 per\nitem", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "35 United\tStates dollars", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 + SGD5", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 / 3", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "SGD35 × 3", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "(SGD35–40)", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "Price: SGD35, tax included.", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "35 Singapore dollars", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "United States dollars35", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "35 Singapore\ndollars", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "United\nStates\ndollars35", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "35 Singapore\tdollars", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "United\tStates\tdollars35", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "35 Singapore\r\ndollars", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "United\r\nStates\r\ndollars35", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "35 Singapore dollars", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "United States dollars35", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "35 Singapore  \tdollars", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "United  \tStates  \tdollars35", "noBudget": true, "moneyOnly": true}, {"kind": "money", "quote": "RTX4080", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "USB 3", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "ABC35", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "USDock35", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "🕶 35", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "Fixture unfamiliar object with 35 apertures", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "X35", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "RTX4080x3", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "35 X-ray", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "Orinth 35 x 3 spectrometer", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "SGD35 for Orinth lunar spectrometer", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "X 35", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "35X", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "Fixture plus35", "noBudget": true, "moneyOnly": false}, {"kind": "money", "quote": "Fixture each35", "noBudget": true, "moneyOnly": false}]){  let calls=0;const reservations:any[]=[];const settlements:any[]=[];const logs:any[]=[];
  const upstream=await listen(createServer(async(request,response)=>{
   calls++;let input='';for await(const chunk of request)input+=chunk;
   const intent=JSON.parse(JSON.parse(input).systemPrompt.split('Current authoritative shopping intent: ')[1]);
   let raw:any=scenario.kind==='money'?nativeMaterial(intent):catalogMaterial(intent);
   if(scenario.kind==='money'&&scenario.quote){
    raw.citations[0].text+='\n\nFixture retained wording: '+scenario.quote+'.';
    raw.answer.products[0].requestMatch=structuredClone(raw.answer.products[0].requestMatch);
    raw.answer.products[0].requestMatch.support=[{url:raw.citations[0].url,quote:scenario.quote}];
   }
   if(scenario.kind==='catalog'&&scenario.heading)raw.citations[0].text+=`\n\n${scenario.heading}\n\nSGD 999`;
   response.setHeader('content-type','application/json');response.end(JSON.stringify(raw));
  }));
  const sdk=createExaProductResearch('FIXTURE_ROUND2_KEY',{baseUrl:upstream,timeoutMs:1500});
  const research=async(...args:Parameters<typeof sdk>)=>{const result=await sdk(...args);if(result.status==='ready')result.research.dataKind='test-fixture';return result;};
  const conversations=createConversationService({research,quota:{reserve:async(...args)=>{reservations.push(args);return 'admitted';},settle:async(...args)=>{settlements.push(args);}}});
  const server=createServer();const base=await listen(server);
  const app=createApp({conversations,logger:event=>logs.push(event)},{apiPort:Number(new URL(base).port)});
  server.on('request',getRequestListener(app.fetch));
  const session=await fetch(base+'/api/session');const cookie=session.headers.get('set-cookie')!.split(';')[0]!;
  const post=async(body:any)=>{const response=await fetch(base+'/api/turn',{method:'POST',headers:{cookie,'content-type':'application/json',origin:'http://127.0.0.1:5173'},body:JSON.stringify(body)});assert.equal(response.status,200);return response.json();};
  const prepared=await post({phase:'prepare',operationId:randomUUID(),message:scenario.kind==='money'?scenario.noBudget?'Find fixture USB-C powerbank':'Find fixture USB-C powerbank between SGD30 and40':'Find fixture sunglasses between SGD800 and1000'});
  assert.equal(prepared.kind,'prepared');
  const response=await post({phase:'research',preparedId:prepared.preparedId});
  assert.equal(response.kind,'research');
  const snapshot=response.research,product=snapshot.products[0];
  assert.equal(snapshot.dataKind,'test-fixture');assert.equal(calls,1);assert.equal(reservations.length,1);assert.equal(settlements.length,1);
  assert(!JSON.stringify(logs).includes('FIXTURE_ROUND2_KEY'));
  const observation=product.priceObservation;
  const span=product.requestMatch.support[0];
  assert.equal(span?.origin.reportedQuote,scenario.quote);assert.equal(span?.literal.text,scenario.quote);
  const expectedSafe=scenario.moneyOnly?product.requestMatch.status==='unknown'&&!product.eligible&&snapshot.choice===null:product.requestMatch.status==='supported';
  assert.equal(snapshot.evidenceVersion,4);
  if(scenario.kind==='catalog'&&scenario.heading)assert(observation?.row.context.text.includes(scenario.heading+'\n\nSGD 999'));
  results.push({scenario,requestMatch:product.requestMatch.status,price:product.price&&{amount:product.price.amount,conditionsResolved:product.price.conditionsResolved},priceObservation:observation,eligible:product.eligible,choice:snapshot.choice,calls,reservations:reservations.length,settlements:structuredClone(settlements),expectedSafe});
  for(const active of servers.splice(0)){active.closeAllConnections();await new Promise<void>(resolve=>active.close(()=>resolve()));}
 }
}finally{for(const server of servers){server.closeAllConnections();await new Promise<void>(resolve=>server.close(()=>resolve()));}}
const report={head,fixtureOnly:true,results};
await writeFile(`artifacts/fieldnote-v2/evidence-gap-security/v4/lexer-runtime-${head.slice(0,7)}.json`,JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
assert(results.every(row=>row.expectedSafe),'Money-only fit must be unknown and catalog rows must remain unattributed observations');
