import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { createServer, type Server } from 'node:http';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { Pool } from 'pg';
import { getRequestListener } from '@hono/node-server';
import { fixtureDatabase } from '../../../../scripts/test-postgres.mjs';
import { createApp } from '../../../../src/server/app';
import { createAccounts } from '../../../../src/server/accounts';
import { migrate } from '../../../../src/server/account-migrations';
import { createResearchExecutor } from '../../../../src/server/research-executor';
import { createExaProductResearch } from '../../../../src/server/exa-research';
import { reduceTurn } from '../../../../src/domain/turn-reducer';
import { emptyWorkspace } from '../../../../src/domain/workspace';
import { actualStoredConversationV2 } from '../../../../tests/helpers/v2-stored-material';
import { actualStoredConversationV3 } from '../../../../tests/helpers/v3-stored-material';
import { catalogMaterial } from '../../../../tests/helpers/v3-catalog-material';
const head=process.env.REVIEW_HEAD!;const wrapper=Number(process.env.REVIEW_WRAPPER??3);
const root=await mkdtemp('/tmp/fieldnote-security-history-');process.env.TMPDIR=root;
const fixture=await fixtureDatabase();
const servers=new Set<Server>();let pool:Pool|undefined;let calls=0;const reservations:unknown[]=[];const settlements:unknown[]=[];const logs:unknown[]=[];
async function listen(server:Server){servers.add(server);await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));const a=server.address();assert(a&&typeof a!=='string');assert.equal(a.address,'127.0.0.1');return a.port;}
async function close(server:Server){server.closeAllConnections();await new Promise<void>(resolve=>server.close(()=>resolve()));servers.delete(server);}
let output:unknown;
try{
 const provider=createServer(async(req,res)=>{let text='';for await(const chunk of req)text+=chunk;calls++;const request=JSON.parse(text);const intent=JSON.parse(request.systemPrompt.split('Current authoritative shopping intent: ')[1]);res.setHeader('content-type','application/json');res.end(JSON.stringify(catalogMaterial(intent)));});
 const providerPort=await listen(provider);const sdk=createExaProductResearch('fixture-owned-history-key',{baseUrl:`http://127.0.0.1:${providerPort}`});
 const execute=createResearchExecutor({research:async(request,signal)=>{const r=await sdk(request,signal);if(r.status==='ready')r.research.dataKind='test-fixture';return r;},quota:{reserve:async(...args)=>{reservations.push(args);return'admitted';},settle:async(...args)=>{settlements.push(args);}}});
 async function start(){pool=new Pool({connectionString:fixture.url});await migrate(pool);const server=createServer();const port=await listen(server);const base=`http://127.0.0.1:${port}`;const accounts=createAccounts(pool,base,'fixture-owned-history-secret-long-enough',{reduce:reduceTurn,research:execute});const app=createApp({accounts,accountCapability:'configured',logger:event=>logs.push(event)},{apiPort:port,webPort:port});server.on('request',getRequestListener(app.fetch));return{server,base};}
 let api=await start();
 async function json(path:string,cookie='',data?:unknown){const response=await fetch(api.base+path,{method:data===undefined?'GET':'POST',headers:{cookie,origin:api.base,'content-type':'application/json'},...(data===undefined?{}:{body:JSON.stringify(data)})});const result=await response.json();return{status:response.status,body:result,cookie:response.headers.getSetCookie().map(v=>v.split(';')[0]).join('; ')};}
 async function signup(){const result=await json('/api/auth/sign-up/email','',{name:'Fixture history reviewer',email:`fixture-${randomUUID()}@example.test`,password:'fixture-owned-password-only'});assert.equal(result.status,200);assert(result.cookie);return result;}
 const a=await signup();const b=await signup();await json('/api/account',a.cookie);await json('/api/account',b.cookie);
 const state=wrapper===2?actualStoredConversationV2():actualStoredConversationV3();if(wrapper===3)state.messages.unshift(...actualStoredConversationV2().messages);
 const old={...emptyWorkspace(),schema:wrapper,state};const historical=structuredClone(old.state.messages);const oldPrepared=randomUUID(),oldRunning=randomUUID(),preparedId=randomUUID(),stamp=new Date().toISOString();
 old.receipts=[{operationId:oldPrepared,preparedId,digest:'a'.repeat(64),status:'prepared',createdAt:stamp},{operationId:oldRunning,digest:'b'.repeat(64),status:'running',createdAt:stamp}];
 const session=(await pool!.query('SELECT id FROM "session" WHERE "userId"=$1',[a.body.user.id])).rows[0];old.pending={operationId:oldPrepared,preparedId,sessionId:session.id,revision:0,epoch:0,intentDigest:'c'.repeat(64),deadline:new Date(Date.now()+120000).toISOString(),status:'prepared'};
 await pool!.query('UPDATE fieldnote_v2_workspace SET data=$2::jsonb WHERE user_id=$1',[a.body.user.id,JSON.stringify(old)]);
 const migrated=await json('/api/account',a.cookie);assert.equal(migrated.status,200);assert.deepEqual(migrated.body.workspace.state.messages,historical);assert.equal(migrated.body.workspace.pendingPreparedId,null);
 const stored=(await pool!.query('SELECT revision,epoch,data FROM fieldnote_v2_workspace WHERE user_id=$1',[a.body.user.id])).rows[0];assert.equal(stored.data.schema,4);assert(stored.data.receipts.every((r:any)=>r.status==='interrupted'));assert.equal(Number(stored.revision),1);assert.equal(Number(stored.epoch),1);
 const stale=await json('/api/workspace',a.cookie,{phase:'research',revision:0,preparedId});assert.equal(stale.status,200);assert.equal(stale.body.operation.status,'interrupted');assert.equal(calls,0);assert.equal(reservations.length,0);
 const held=await json('/api/workspace',a.cookie,{phase:'prepare',revision:migrated.body.workspace.revision,operationId:randomUUID(),message:'Which is best?'});assert.equal(held.status,200);assert.equal(calls,0);assert(!held.body.workspace.pendingPreparedId);assert.deepEqual(held.body.workspace.state.messages.slice(0,historical.length),historical);
 const prepared=await json('/api/workspace',a.cookie,{phase:'prepare',revision:held.body.workspace.revision,operationId:randomUUID(),message:'Find catalog fixture sunglasses between SGD800 and1000'});assert.equal(prepared.status,200);assert(prepared.body.workspace.pendingPreparedId);
 const researched=await json('/api/workspace',a.cookie,{phase:'research',revision:prepared.body.workspace.revision,preparedId:prepared.body.workspace.pendingPreparedId});assert.equal(researched.status,200);assert.equal(researched.body.response.kind,'research');assert.equal(researched.body.response.research.evidenceVersion,4);assert.equal(researched.body.response.research.choice,null);assert.equal(calls,1);assert.equal(reservations.length,1);assert.deepEqual((settlements[0] as unknown[]).slice(1),[0.005,true]);
 const before=(await json('/api/account',a.cookie)).body.workspace;assert.deepEqual(before.state.messages.slice(0,historical.length),historical);assert.deepEqual(before.state.messages.filter((m:any)=>m.research).map((m:any)=>m.research.evidenceVersion),wrapper===2?[2,4]:[2,3,4]);assert.deepEqual((await json('/api/account',b.cookie)).body.workspace.state.messages,[]);
 const guessed=await json('/api/workspace',b.cookie,{phase:'research',revision:0,preparedId:prepared.body.workspace.pendingPreparedId});assert.equal(guessed.status,409);assert.equal(calls,1);
 await close(api.server);await pool!.end();pool=undefined;await fixture.restart();api=await start();
 const after=(await json('/api/account',a.cookie)).body.workspace;assert.deepEqual(after,before);assert.deepEqual((await json('/api/account',b.cookie)).body.workspace.state.messages,[]);assert.equal(calls,1);
 const repeated=await json('/api/workspace',a.cookie,{phase:'research',revision:prepared.body.workspace.revision,preparedId:prepared.body.workspace.pendingPreparedId});assert.equal(repeated.status,200);assert.equal(calls,1);
 const logText=JSON.stringify(logs);assert(!logText.includes('fixture-owned-history-key'));assert(!logText.includes('Fixture Meridian'));assert(!logText.includes(a.body.user.email));
 output={head,wrapper,fixtureOnly:true,status:'pass',oldMessagesPreserved:historical.length,evidenceVersions:wrapper===2?[2,4]:[2,3,4],stalePreparedInterrupted:true,oldRunningInterrupted:true,historicalHeldReplyFree:true,accountIsolation:true,postgresAndApiRestartPreserved:true,providerCalls:calls,reservations:reservations.length,settlements:settlements.length,normalLogsPrivate:true};
}finally{for(const server of [...servers])await close(server);await pool?.end();await fixture.stop();await rm(root,{recursive:true,force:true});}
await writeFile(`artifacts/fieldnote-v2/evidence-gap-security/v4/history-runtime-${head.slice(0,7)}-wrapper${wrapper}.json`,JSON.stringify(output,null,2));console.log(JSON.stringify(output));
