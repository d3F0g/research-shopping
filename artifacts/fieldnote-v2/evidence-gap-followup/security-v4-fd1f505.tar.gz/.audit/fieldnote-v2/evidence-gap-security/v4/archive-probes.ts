import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { historicalReportArchive, additionalArchivedReports } from '../../../../evals/history-fieldnote-v2/archive';
import { historicalReportDigest } from '../../../../evals/history-fieldnote-v2/report';
import { validateReport } from '../../../../evals/v2/report';
import { summarize } from '../../../../evals/frozen-v4/report';

const head=process.env.REVIEW_HEAD!;
assert.equal(execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),head);
const base='33fadc7e3cfde2207528adb32b650287e758d343';
assert.equal(historicalReportArchive.sourceCommit,base);
assert.equal(historicalReportArchive.reports.length,13);
assert.equal(additionalArchivedReports.length,6);
const allowedArchives=new Set(['artifacts/fieldnote-v2/evidence-gap-followup/owner-33fadc7-checks.tar.gz','artifacts/fieldnote-v2/evidence-gap-followup/owner-651-checkpoint.tar.gz','artifacts/fieldnote-v2/evidence-gap-followup/owner-579ec53-checkpoint.tar.gz','artifacts/fieldnote-v2/evidence-gap-followup/owner-ccfb87c-checkpoint.tar.gz']);
const root='/Users/josiahwong/Documents/research-shopping-v2/';
const results=[];
const digest=(bytes:Buffer|string)=>createHash('sha256').update(bytes).digest('hex');
function checkPayload(bytes:Buffer, expected:string, origin:unknown){
 const report=JSON.parse(bytes.toString('utf8'));
 assert.equal(historicalReportDigest(report),expected);
 validateReport(report);
 const mutations=[
  ['erase-checks',(value:any)=>{for(const row of value.cases)row.checks=[];}],
  ['all-pass-checks',(value:any)=>{for(const row of value.cases)for(const check of row.checks)check.status='pass';}],
  ['invent-critical-check',(value:any)=>{value.cases[0].checks.push({id:'fixture-forged-security-check',turn:null,status:'pass',critical:true,expected:true,observed:true,evidence:[]});}],
  ['unknown-run',(value:any)=>{value.runId='fixture-unregistered-historical-run';}],
  ['embedded-code',(value:any)=>{value.implementationInputs.grading[0].text+='\nthrow new Error("FIXTURE_NEVER_EXECUTE_ARCHIVED_CODE")';}],
 ] as const;
 for(const [name,mutate]of mutations){
  const changed=structuredClone(report);mutate(changed);
  for(const row of changed.cases)row.verdict=!row.observation?'blocked':row.checks.some((c:any)=>c.status==='fail')?'fail':row.checks.some((c:any)=>c.status==='blocked')?'blocked':row.checks.some((c:any)=>c.status==='unsupported')?'unsupported':'pass';
  changed.summary=summarize(changed.cases);
  assert.notEqual(historicalReportDigest(changed),expected,name);
  assert.throws(()=>validateReport(changed),/archive digest/,name);
 }
 results.push({origin,sha256:expected,summary:report.summary,mutationRejections:mutations.map(([name])=>name)});
}
for(const entry of historicalReportArchive.reports){
 const pinned=execFileSync('git',['rev-parse',`${base}:${entry.path}`],{encoding:'utf8'}).trim();
 assert.equal(pinned,entry.blob);
 const bytes=execFileSync('git',['cat-file','blob',pinned],{maxBuffer:64*1024*1024});
 assert.equal(createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex'),entry.blob);
 assert.deepEqual(await readFile(entry.path),bytes);
 checkPayload(bytes,entry.sha256,{kind:'base-git-blob',base,path:entry.path,blob:pinned});
}
for(const entry of additionalArchivedReports){
 assert(allowedArchives.has(entry.archive));
 const path=root+entry.archive;
 assert.equal(digest(await readFile(path)),entry.archiveSha256);
 const bytes=execFileSync('tar',['-xOf',path,entry.member],{maxBuffer:64*1024*1024});
 checkPayload(bytes,entry.sha256,{kind:'explicit-public-archive',archive:entry.archive,archiveSha256:entry.archiveSha256,member:entry.member});
}
const output={head,base,verdict:'pass',payloads:results.length,totalMutationRejections:results.length*5,results};
await writeFile(`artifacts/fieldnote-v2/evidence-gap-security/v4/archive-probes-${head.slice(0,7)}.json`,JSON.stringify(output,null,2));
console.log(JSON.stringify({head,payloads:results.length,totalMutationRejections:results.length*5,verdict:'pass'}));
