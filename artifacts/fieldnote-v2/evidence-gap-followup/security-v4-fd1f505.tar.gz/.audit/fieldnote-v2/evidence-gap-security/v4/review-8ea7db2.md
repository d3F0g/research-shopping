# Independent security review of structural evidence version 4

Verdict: **ISSUES**, provisional at `8ea7db2679b3f59353255a35e222f4a41d64c9b5`. Original base is `33fadc7e3cfde2207528adb32b650287e758d343`; this round reviews the structural delta from `ccfb87cdcbbebb4ca4b376fd6747cbbf9372b9cf`. The catalog-attribution blocker is repaired in the tested V4 representation. One money-only fit blocker remains. Final UI and monetary repairs have not yet been assigned for exact-head review.

I reviewed the root V4 decision and both price-rethink architecture reports, the assigned source delta, and `docs/security-model.md`. I did not author application changes. The isolated checkout is `/Users/josiahwong/Documents/research-shopping-v2-evidence-security`, but it shares host permissions and is not an independent permission sandbox. Writes were limited to the assigned audit/artifact directories and owned temporary local resources. Root separately installed its byte-authenticated public ccfb archive in the test fixture location.

No private environment, key, ledger, grant, capture, existing database, real user history, provider, paid operation, GitHub mutation, credential change, or deployment was accessed. All runtime transport and database data are explicit fixtures. Only the four specifically authorized root-public archives were read.

## Remaining money-only fit blocker

Actual local Exa SDK and Hono requests with no budget still select model-a when request-match support consists only of any of:

- `35 SGD per item`
- `35 SGD x 1`
- `35 Singapore  dollars` (two spaces between currency-name words)

Each response reports requestMatch=supported, eligible=true, and a model-a choice. Price is null. A missing optional budget cannot turn an amount-only quotation into support for the full shopping objective. This agrees with independent QA's class-level finding. Root has assigned another repair.

`expanded-money-runtime.ts` preserves 21 paired actual HTTP/SDK scenarios and deliberately exits nonzero after writing all outcomes. Every scenario uses a fresh local session with one injected admission, one SDK request, and one settlement. The earlier currency names, punctuation/wrappers, numeric prefixes/suffixes, price prose, and complete-objective positive controls now pass.

## Structural price observation behavior verified

The 18-case `structural-runtime.ts` harness passes on this head. Catalog positives, real other-brand peers, partial target headings, `Silver colorway`, `Meridian Sunglasses Silver Edition`, `Spring collection`, `Gift set`, and wrong-variant context all retain:

- `price: null`;
- literal source amount SGD868 in `priceObservation`;
- unknown computed attribution and no variant field;
- a source-origin row and the entire uncut source as context, including SGD999 and every qualifier;
- the actual provider quote `SGD 868`, provider assessment, conditions, and resolved flag under separate reported metadata;
- no budget eligibility or choice in these fixtures.

There is no peer classification or deletion in the new fallback. The full source remains unchanged. Direct exact-variant price evidence remains in the applicable-price path and the complete-objective SGD35 control remains eligible. A range, two money values, and a quantity-bearing amount line produce neither an applicable price nor a scalar catalog observation; the original source text remains stored.

The independent observation probe rejects 19 forgeries. The schema rejects altered amount/currency, invented variant or attribution authority, wrong source, forged offsets/text, partial/gapped complete context, cut metadata, provider-origin source row, source-origin provider report, and simultaneous applicable price plus observation. The independent current evaluator also rejects altered native status, scope, rationale, conditions, resolved flag, and provider wording even when the snapshot alone cannot know the original native value.

The probe additionally verifies bounded JSON answer strings; exact preservation of an actual adverse native assessment and native conditions; source-instruction and oversized-source withholding; unsafe source URL exclusion; escaped script/event-handler strings in the new visible metadata; noopener/noreferrer links; stock/delivery uncertainty; inability of observations to satisfy a budget; free held detail/best/cheaper replies; unchanged historical messages; and open nonmonetary descriptions such as RTX4080, USB3, ABC35, USDock35, emoji, and unfamiliar prose.

An initial reviewer-harness expectation used `Find a cheaper option`, which is an explicit research request. The free held-comparison control was corrected to the supported `Something cheaper` command before the passing run. No product code changed for that correction.

## Mixed history and archive integrity verified

Two independent owned PostgreSQL clusters exercised actual Hono, SDK, migration, API restart, and PostgreSQL restart:

- Wrapper 2 to wrapper 4 retained all four original V2 messages exactly, then appended current evidence4 beside evidence2.
- Wrapper 3 to wrapper 4 retained all eight mixed V2/V3 messages exactly, then appended evidence4 beside evidence2/evidence3. The old V3 amount and semantics were preserved, not promoted into new proof.

Both migrations incremented revision/epoch, cleared pending preparation, interrupted old prepared/running receipts, prevented stale dispatch, and kept historical replies free. Cross-account reads and guessed preparations remained isolated. Each run made exactly one explicit current fixture SDK call, admission, and settlement. API/database restart preserved the complete workspace exactly; cached retries made no extra call. Normal logs excluded fixture content, credential, and email sentinels. All owned clusters and servers were stopped and removed.

The frozen V3 schema delta only exports its existing ShoppingIntentSchema. Its old validator and old binding implementation retain their semantics. Workspace3 has a separate frozen reader; current workspace4 accepts the V2/V3/V4 union. Current paid-action and reassessment paths dispatch on evidence4 explicitly.

The archive probe authenticates 19 historical payloads: 13 actual base33 Git blobs, four reports from the previously authorized public V2 archives, and the actual old V3 reports from the authorized579 and ccfb archives. It verifies Git blob identity or archive SHA-256 before reading each payload and comparing its code-owned digest. All original payloads validate; 95 altered-check, unknown-run, and embedded-code mutations reject. Historical payloads are not executed or regraded through the current evaluator. The current adapter/assertion versions are independent of the admitted historical versions.

## Other verification and binding

The full application suite passes 399 tests, zero failures, with the checkout-root-writing diagnostic test skipped for ownership. The current evaluation suite passes 29 tests. The owned PostgreSQL suite passes 28 tests. These passing suites do not override the independent money-only red cases.

The diagnostic writer, research executor, conversation service, HTTP app, account service, workspace store, safe-URL policy, and package/lock files are unchanged from reviewed ccfb. The thirteen actual HTTP/diagnostic/cancellation/provider-failure/settlement runtime groups from ccfb therefore remain evidence for those unchanged mechanisms. This round reran the changed provider projection through actual SDK/Hono transport and the changed history representation through real owned PostgreSQL. It does not claim the entire old harness was rerun at8ea.

The CI delta adds the current V4 screenshot path. No elevated permission, credential, deployment, or external-provider composition was added. Browser layout and final UI copy remain independent QA's scope.

## Commands and artifacts

All reviewer harnesses are under `.audit/fieldnote-v2/evidence-gap-security/v4/`; their outputs are under `artifacts/fieldnote-v2/evidence-gap-security/v4/`. Commands use a cleared environment and disable live Exa composition.

```sh
env -i PATH="$PATH" REVIEW_HEAD=8ea7db2679b3f59353255a35e222f4a41d64c9b5 EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v4/structural-runtime.ts
env -i PATH="$PATH" REVIEW_HEAD=8ea7db2679b3f59353255a35e222f4a41d64c9b5 EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v4/expanded-money-runtime.ts
env -i PATH="$PATH" REVIEW_HEAD=8ea7db2679b3f59353255a35e222f4a41d64c9b5 EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v4/observation-probes.ts
env -i PATH="$PATH" REVIEW_HEAD=8ea7db2679b3f59353255a35e222f4a41d64c9b5 EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v4/archive-probes.ts
env -i PATH="$PATH" LC_ALL=C REVIEW_HEAD=8ea7db2679b3f59353255a35e222f4a41d64c9b5 REVIEW_WRAPPER=2 EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v4/history-runtime.ts
env -i PATH="$PATH" LC_ALL=C REVIEW_HEAD=8ea7db2679b3f59353255a35e222f4a41d64c9b5 REVIEW_WRAPPER=3 EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v4/history-runtime.ts
env -i PATH="$PATH" LC_ALL=C EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node .audit/fieldnote-v2/evidence-gap-security/v4/pg-tests.mjs
env -i PATH="$PATH" EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node node_modules/vitest/vitest.mjs run --no-cache --configLoader runner -t '^(?!.*rejects capture within the current source checkout)' --reporter=json --outputFile=artifacts/fieldnote-v2/evidence-gap-security/v4/8ea7db2-app-tests.json
env -i PATH="$PATH" EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx --test evals/v2/tests/*.test.ts
```

The expanded money runtime is expected red at this head. All other listed commands pass. No private data is needed to reproduce the blocker or passing controls.

Full60 remains inconclusive, with 11 pass, 48 blocked, 1 unsupported, zero fail. This review does not establish live usefulness, real billing, merchant authorization, inventory, or delivery. Source containment does not establish semantic entailment or protection from every possible instruction. Root retains CI, repository-policy, and merge decisions; no new human approval is requested.
