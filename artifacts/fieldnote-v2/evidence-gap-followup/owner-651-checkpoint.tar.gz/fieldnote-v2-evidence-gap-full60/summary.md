# Fieldnote V2 product evaluation

Application 5383a70e9ac54e322006e359c2a59d608851deab. Dataset 1.0.0. Contract fieldnote-v2-grounded-1.0.0.

Executed 60/60. Passed 0. Failed 59. Blocked 0. Unsupported 1. Infrastructure errors 0.
Critical assertion failures 101 across 59 scenarios. Deterministic acceptance fail.

Synthetic local SDK transport. Exa credits 0. Interpreter calls 0. Semantic and browser quality remain unassessed here.

- FN-CU-001. research-query-intent:1.
- FN-CU-002. research-query-intent:0, research-query-intent:1.
- FN-CU-003. research-query-intent:0, research-query-intent:1.
- FN-CU-004. research-query-intent:0, research-query-intent:1.
- FN-CU-005. research-query-intent:0, research-query-intent:1.
- FN-PE-001. research-query-intent:0, research-query-intent:1, research-query-intent:2.
- FN-PE-002. research-query-intent:0, research-query-intent:1, research-query-intent:2.
- FN-PE-003. research-query-intent:0, research-query-intent:1.
- FN-PE-004. research-query-intent:0, research-query-intent:1.
- FN-PE-005. research-query-intent:0, research-query-intent:1.
- FN-CC-001. research-query-intent:1.
- FN-CC-002. research-query-intent:0.
- FN-CC-003. research-query-intent:1.
- FN-CC-004. research-query-intent:0, research-query-intent:1.
- FN-CC-005. research-query-intent:0.
- FN-BC-001. research-query-intent:0, research-query-intent:1.
- FN-BC-002. research-query-intent:0.
- FN-BC-003. research-query-intent:0, research-query-intent:1.
- FN-BC-004. research-query-intent:0.
- FN-BC-005. research-query-intent:0.
- FN-MR-001. research-query-intent:0, research-query-intent:1.
- FN-MR-002. research-query-intent:0, research-query-intent:1, research-query-intent:2.
- FN-MR-003. research-query-intent:0, research-query-intent:1.
- FN-MR-004. research-query-intent:0, research-query-intent:1.
- FN-MR-005. research-query-intent:0, research-query-intent:1, research-query-intent:2.
- FN-CD-001. research-query-intent:0, research-query-intent:2.
- FN-CD-002. research-query-intent:0, research-query-intent:1, research-query-intent:2.
- FN-CD-003. research-query-intent:0, research-query-intent:1.
- FN-CD-004. research-query-intent:0, research-query-intent:1, research-query-intent:2.
- FN-CD-005. research-query-intent:0, research-query-intent:1, research-query-intent:2.
- FN-RT-001. research-query-intent:0.
- FN-RT-002. research-query-intent:0.
- FN-RT-003. research-query-intent:0.
- FN-RT-004. research-query-intent:0, research-query-intent:1.
- FN-PR-001. research-query-intent:0, research-query-intent:1.
- FN-PR-002. research-query-intent:0, research-query-intent:1.
- FN-PR-003. research-query-intent:0, research-query-intent:1.
- FN-PR-004. research-query-intent:0, research-query-intent:1.
- FN-PR-005. research-query-intent:0, research-query-intent:1.
- FN-PQ-001. research-query-intent:0.
- FN-PQ-002. research-query-intent:0.
- FN-PQ-003. research-query-intent:0.
- FN-PQ-004. research-query-intent:0.
- FN-PQ-005. research-query-intent:0.
- FN-EH-001. research-query-intent:0.
- FN-EH-002. research-query-intent:0.
- FN-EH-003. research-query-intent:0.
- FN-EH-004. research-query-intent:0.
- FN-EH-005. research-query-intent:0, research-query-intent:1.
- FN-UI-001. research-query-intent:0.
- FN-UI-002. research-query-intent:0.
- FN-UI-003. research-query-intent:0, research-query-intent:1, research-query-intent:2.
- FN-UI-004. research-query-intent:0, research-query-intent:1.
- FN-UI-005. research-query-intent:0, research-query-intent:1.
- FN-ER-001. research-query-intent:0, research-query-intent:2.
- FN-ER-002. research-query-intent:0.
- FN-ER-003. research-query-intent:0.
- FN-ER-004. research-query-intent:0.
- FN-ER-005. research-query-intent:0, research-query-intent:1.

## Limits

- All sixty original public conversations, milestones and research materials remain frozen. Historical reports keep their original schemas and identities.
- V2 raw state and HTTP outputs are retained. The mechanical projection renames requirement text and budget maximum for historical normative checks without inventing accepted constraints or evidence.
- The full-intent request assertion binds actual accepted V2 intent. V2 choice eligibility checks literal supported identity, request and hard requirements plus numeric bounds and price conditions; it does not manufacture the old provider budget assessment.
- Synthetic materials establish conditional deterministic behavior, never live discovery, real product relevance, current prices, stock, merchant authorization or shopping usefulness.
- Literal quote containment establishes provenance, not semantic entailment. Provider source-based assessments remain interpretations.
- No interpreter is supplied. This differs from the historical fixed-proposal treatment and forbids causal model-quality claims.
- Semantic judgment and human calibration are not run. Browser acceptance is assessed separately and cannot be inferred from HTTP checks.
- Execution provenance is recorded but not cryptographically authenticated. Embedded evaluator source is never executed.
- Blocked and unsupported checks remain outside assessed denominators. Frozen failures are retained.
