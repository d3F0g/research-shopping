import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, writeFile, readFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import path from "node:path";

const checkout = process.argv[2] ?? "/tmp/fieldnote-dc61-ci-investigation";
const output = process.argv[3] ?? "/tmp/fieldnote-dc61-ci-notes/native-probe";
const mode = process.argv[4] ?? "native-default-second";
assert.ok(["native-default-first", "native-default-second", "native-cache-disabled-first"].includes(mode));
await mkdir(output, { recursive: true });
const { chromium } = await import(pathToFileURL(path.join(checkout, "node_modules/playwright/index.mjs")));
const environment = { PATH: process.env.PATH, NODE_ENV: "test", EXA_RESEARCH_ENABLED: "false", API_PORT: "3298", VITE_API_PORT: "3298", WEB_PORT: "5398", CI65_HELD_SEQUENCE: mode === "native-default-second" ? "2" : "1", PLAYWRIGHT_BROWSERS_PATH: "/Users/josiahwong/Library/Caches/ms-playwright" };
const children = [];
const serverLogs = [];
function start(args) {
  const child = spawn(process.execPath, args, { cwd: checkout, env: environment, stdio: ["ignore", "pipe", "pipe"] });
  child.stdout.on("data", (chunk) => serverLogs.push(String(chunk)));
  child.stderr.on("data", (chunk) => serverLogs.push(String(chunk)));
  children.push(child);
  return child;
}
let browser;
const report = { mode, exactCommit: "dc61d3bae93fd347495ecbb5973d7877513ec91d", interception: "No Playwright route, route.fetch, fulfill, or request-header overrides", environment: Object.keys(environment), samples: [] };
const digest = (text) => createHash("sha256").update(text).digest("hex").slice(0, 12);
const target = "http://127.0.0.1:5398";
async function untilReady(url) {
  for (let count = 0; count < 150; count++) {
    try { if ((await fetch(url)).ok) return; } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error("Owned diagnostic server did not start");
}
try {
  start(["--import", "tsx", "artifacts/playwright-results/ci65/native-server.ts"]);
  start(["node_modules/vite/bin/vite.js", "--host", "127.0.0.1"]);
  await untilReady(target + "/api/health");
  browser = await chromium.launch({ headless: true, env: environment });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();
  report.browserVersion = browser.version();
  const cdp = await context.newCDPSession(page);
  await cdp.send("Network.enable");
  if (mode === "native-cache-disabled-first") await cdp.send("Network.setCacheDisabled", { cacheDisabled: true });
  const browserEvents = [];
  report.browserEvents = browserEvents;
  report.networkEvents = [];
  cdp.on("Network.requestWillBeSent", (event) => { if (new URL(event.request.url).pathname.startsWith("/api/")) report.networkEvents.push({ event: "requestWillBeSent", path: new URL(event.request.url).pathname, requestId: event.requestId, timestamp: event.timestamp }); });
  cdp.on("Network.responseReceived", (event) => { if (new URL(event.response.url).pathname.startsWith("/api/")) report.networkEvents.push({ event: "responseReceived", path: new URL(event.response.url).pathname, requestId: event.requestId, timestamp: event.timestamp }); });
  page.on("request", (request) => { if (new URL(request.url()).pathname.startsWith("/api/")) browserEvents.push({ event: "request", path: new URL(request.url()).pathname }); });
  page.on("response", async (response) => {
    if (!new URL(response.url()).pathname.startsWith("/api/")) return;
    const headers = await response.allHeaders();
    const cookie = headers["set-cookie"]?.match(/fieldnote-session=([^;]+)/)?.[1];
    browserEvents.push({ event: "response", path: new URL(response.url()).pathname, status: response.status(), cookieDigest: cookie ? digest(cookie) : null });
  });
  await page.goto(target);
  const composer = page.getByRole("textbox", { name: "Message", exact: true });
  const send = page.getByRole("button", { name: "Send message", exact: true });
  await send.waitFor({ state: "visible" });
  await composer.fill("hello");
  if (mode === "native-default-first") {
    for (let count = 0; browserEvents.filter((event) => event.event === "request" && event.path === "/api/session").length < 2 && count < 100; count++) await new Promise((resolve) => setTimeout(resolve, 20));
    report.beforeRelease = { status: await fetch(target + "/api/ci65/status").then((response) => response.json()), sendEnabled: await send.isEnabled(), logicalSessionRequests: browserEvents.filter((event) => event.event === "request" && event.path === "/api/session").length };
    assert.equal(report.beforeRelease.logicalSessionRequests, 2);
    assert.equal(report.beforeRelease.status.sessionCount, 1);
    assert.equal(report.beforeRelease.sendEnabled, false);
    await page.screenshot({ path: path.join(output, "default-before-release.png"), fullPage: true });
    await fetch(target + "/api/ci65/release");
  }
  for (let count = 0; !(await send.isEnabled()) && count < 100; count++) await new Promise((resolve) => setTimeout(resolve, 20));
  assert.equal(await send.isEnabled(), true);
  let statusBefore;
  for (let count = 0; count < 100; count++) {
    statusBefore = await fetch(target + "/api/ci65/status").then((response) => response.json());
    if (statusBefore.events.some((event) => event.event === "native-response-held" && event.sequence === Number(environment.CI65_HELD_SEQUENCE))) break;
    await new Promise((resolve) => setTimeout(resolve, 20));
  }
  assert.equal(statusBefore.sessionCount, 2);
  assert.equal(statusBefore.events.some((event) => event.event === "native-response-held"), true);
  if (mode === "native-default-first") {
    report.afterRelease = { status: statusBefore, sendEnabled: await send.isEnabled(), cookieDigests: (await context.cookies(target)).filter((cookie) => cookie.name === "fieldnote-session").map((cookie) => digest(cookie.value)) };
    assert.equal(statusBefore.sessions.length, 2);
    assert.equal(statusBefore.events.filter((event) => event.event === "response-created" && event.path === "/api/session")[1].requestSession, null);
    report.verdict = "Holding the first native response left the composer unready until release; two empty-cookie bootstrap requests still created distinct sessions";
    await page.screenshot({ path: path.join(output, "default-after-release.png"), fullPage: true });
  } else {
  async function sample(name) {
    const cookies = await context.cookies(target);
    const actualBrowserSession = await page.evaluate(async (sampleName) => (await fetch("/api/session?ci65=" + encodeURIComponent(sampleName))).json(), name);
    const snapshots = {};
    for (const label of ["session-1", "session-2"]) snapshots[label] = await fetch(target + "/api/ci65/snapshot/" + label).then((response) => response.json());
    const currentStatus = await fetch(target + "/api/ci65/status").then((response) => response.json());
    const cookieSession = currentStatus.sessions.find((session) => session.digest === digest(cookies.find((cookie) => cookie.name === "fieldnote-session").value))?.session;
    const sample = { name, cookieSession, cookieDigest: digest(cookies.find((cookie) => cookie.name === "fieldnote-session").value), actualBrowserSession, snapshots, uiText: await page.getByRole("log").innerText(), draft: await composer.inputValue(), sendEnabled: await send.isEnabled() };
    report.samples.push(sample);
    await page.screenshot({ path: path.join(output, name + ".png"), fullPage: true });
    return sample;
  }
  await composer.fill("hello");
  await send.click();
  await page.getByText("Hi. What are you looking to buy?", { exact: true }).waitFor();
  await composer.fill("Fixture draft after guest reply");
  const before = await sample("before-release");
  assert.equal(before.actualBrowserSession.state.messages.some((message) => message.text === "hello"), true);
  const response = page.waitForResponse((response) => new URL(response.url()).pathname === "/api/session");
  await fetch(target + "/api/ci65/release");
  await (await response).finished();
  const after = await sample("after-release");
  assert.notEqual(after.cookieDigest, before.cookieDigest);
  assert.equal(after.actualBrowserSession.state.messages.some((message) => message.text === "hello"), false);
  assert.equal(after.snapshots[before.cookieSession].snapshot.state.messages.some((message) => message.text === "hello"), true);
  assert.equal(after.uiText.includes("Hi. What are you looking to buy?"), true);
  assert.equal(after.draft, "Fixture draft after guest reply");
  await composer.fill("thanks");
  await send.click();
  await page.getByText("thanks", { exact: true }).waitFor();
  const followup = await sample("after-followup");
  assert.equal(followup.actualBrowserSession.state.messages.some((message) => message.text === "hello"), false);
  assert.equal(followup.actualBrowserSession.state.messages.some((message) => message.text === "thanks"), true);
  await page.reload();
  await composer.waitFor();
  await page.getByText("thanks", { exact: true }).waitFor();
  const reloaded = await sample("after-reload");
  assert.equal(reloaded.uiText.includes("hello"), false);
  report.events = await fetch(target + "/api/ci65/status").then((response) => response.json());
  report.browserEvents = browserEvents;
  report.verdict = "Reproduced native browser cookie ownership switch and retained-history loss after follow-up/reload";
  }
} catch (error) {
  report.error = String(error.stack ?? error);
  try { report.failureStatus = await fetch(target + "/api/ci65/status").then((response) => response.json()); } catch {}
  process.exitCode = 1;
} finally {
  await browser?.close();
  for (const child of children) child.kill("SIGTERM");
  await Promise.all(children.map((child) => new Promise((resolve) => child.once("exit", resolve))));
  report.cleanup = "Browser and both owned child servers closed";
  await writeFile(path.join(output, "proof.json"), JSON.stringify(report, null, 2));
  await writeFile(path.join(output, "servers.log"), serverLogs.join(""));
  console.log(JSON.stringify({ verdict: report.verdict, error: report.error, proof: path.join(output, "proof.json"), cleanup: report.cleanup }));
}
