import { createHash } from "node:crypto";
import { serve } from "@hono/node-server";
import { createApp } from "../../../src/server/app";
import { createConversationService } from "../../../src/server/conversations";

if (process.env.NODE_ENV !== "test" || process.env.EXA_RESEARCH_ENABLED !== "false") throw new Error("Local diagnostic environment required");
const conversations = createConversationService({ unavailableReason: "disabled" });
const app = createApp({ conversations }, { apiPort: 3298, webPort: 5398 });
const events: object[] = [];
const labels = new Map<string, string>();
const ids = new Map<string, string>();
let sessionCount = 0;
const heldSequence = Number(process.env.CI65_HELD_SEQUENCE ?? "1");
let release!: () => void;
const gate = new Promise<void>((resolve) => { release = resolve; });
function label(header: string | null) {
  const id = header?.match(/(?:^|; )fieldnote-session=([^;]+)/)?.[1];
  if (!id) return null;
  if (!labels.has(id)) {
    const name = `session-${labels.size + 1}`;
    labels.set(id, name);
    ids.set(name, id);
  }
  return labels.get(id);
}
const server = serve({
  hostname: "127.0.0.1", port: 3298,
  fetch: async (request) => {
    const path = new URL(request.url).pathname;
    if (path === "/api/ci65/status") return Response.json({ events, sessionCount, heldSequence, sessions: [...labels].map(([id, session]) => ({ session, digest: createHash("sha256").update(id).digest("hex").slice(0, 12) })) });
    if (path === "/api/ci65/release") {
      events.push({ event: "release-requested", time: performance.now() });
      release();
      return Response.json({ released: true });
    }
    if (path.startsWith("/api/ci65/snapshot/")) {
      const name = path.split("/").at(-1)!;
      const id = ids.get(name);
      if (!id) return Response.json({ error: "Unknown diagnostic session" }, { status: 404 });
      const snapshotRequest = new Request("http://127.0.0.1:3298/api/session", { headers: { cookie: `fieldnote-session=${id}` } });
      const response = await app.fetch(snapshotRequest);
      return Response.json({ session: name, snapshot: await response.json() });
    }
    const sequence = path === "/api/session" ? ++sessionCount : null;
    const requestSession = label(request.headers.get("cookie"));
    if (path.startsWith("/api/")) events.push({ event: "request", path, sequence, requestSession, time: performance.now() });
    const response = await app.fetch(request);
    if (path.startsWith("/api/")) {
      const snapshot = await response.clone().json();
      events.push({ event: "response-created", path, sequence, requestSession, cookieSession: label(response.headers.get("set-cookie")), snapshot, time: performance.now() });
    }
    if (sequence === heldSequence) {
      events.push({ event: "native-response-held", sequence, signalAborted: request.signal.aborted, time: performance.now() });
      request.signal.addEventListener("abort", () => events.push({ event: "native-request-aborted", sequence, time: performance.now() }));
      await gate;
      events.push({ event: "native-response-released", sequence, signalAborted: request.signal.aborted, time: performance.now() });
    }
    return response;
  },
});
for (const signal of ["SIGINT", "SIGTERM"] as const) process.on(signal, () => server.close(() => process.exit(0)));
