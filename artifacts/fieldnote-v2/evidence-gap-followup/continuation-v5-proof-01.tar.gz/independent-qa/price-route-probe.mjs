import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
const root = process.argv[2];
const load = (file) => import(pathToFileURL(`${root}/${file}`).href);
const [{ createApp }, { createConversationService }, { createExaProductResearch }, { nativeMaterial }] = await Promise.all([
  load('src/server/app.ts'), load('src/server/conversations.ts'), load('src/server/exa-research.ts'), load('tests/helpers/v2-material.ts'),
]);
const cases = [
  { name: 'Markdown', text: 'Fixture data. Fixture Powerbank Model A is a USB-C powerbank.\n\n| Model | Price |\n| Model A | SGD 437 |\n\nOne unit, tax included. No membership or voucher is required.' },
  { name: 'prose', text: 'Fixture data. Fixture Powerbank Model A is a USB-C powerbank.\n\nChoose Model A for your order. The tag reads 437 SGD for one unit, tax included.' },
];
let selected, calls = 0;
const upstream = createServer(async (request, response) => {
  let body = '';
  for await (const part of request) body += part;
  assert.equal(request.url, '/answer');
  calls++;
  const input = JSON.parse(body);
  const intent = JSON.parse(input.systemPrompt.split('Current authoritative shopping intent: ')[1]);
  const original = nativeMaterial(intent);
  const material = JSON.parse(JSON.stringify(original).replaceAll(JSON.stringify(original.citations[0].text).slice(1, -1), JSON.stringify(selected.text).slice(1, -1)));
  material.citations[0].text = selected.text;
  material.answer.products[0].price.amount = 437;
  response.setHeader('content-type', 'application/json');
  response.end(JSON.stringify(material));
});
await new Promise((resolve) => upstream.listen(0, '127.0.0.1', resolve));
const sdk = createExaProductResearch('fixture-only-key', { baseUrl: `http://127.0.0.1:${upstream.address().port}`, timeoutMs: 1000 });
const app = createApp({ conversations: createConversationService({ research: async (request, signal) => {
  const result = await sdk(request, signal);
  if (result.status === 'ready') result.research.dataKind = 'test-fixture';
  return result;
}, quota: { reserve: async () => 'admitted', settle: async () => {} } }) });
const results = [];
try {
  for (selected of cases) {
    const first = await app.request('http://localhost:3000/api/turn', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ phase: 'prepare', operationId: randomUUID(), message: 'a USB-C powerbank between SGD400 and500' }) });
    assert.equal(first.status, 200);
    const prepared = await first.json();
    assert.equal(prepared.kind, 'prepared');
    const response = await app.request('http://localhost:3000/api/turn', { method: 'POST', headers: { 'content-type': 'application/json', cookie: first.headers.get('set-cookie').split(';')[0] }, body: JSON.stringify({ phase: 'research', preparedId: prepared.preparedId }) });
    assert.equal(response.status, 200);
    const answer = await response.json();
    assert.equal(answer.kind, 'research');
    results.push({ name: selected.name, evidenceVersion: answer.research.evidenceVersion, choice: answer.research.choice, eligible: answer.research.products[0].eligible, priceEvidence: answer.research.products[0].priceEvidence, sourceText: answer.research.sources[0].text });
  }
  assert.equal(calls, 2);
  const expectedEligible = process.argv[3] === 'green';
  assert(results.every((result) => result.eligible === expectedEligible));
  assert(results.every((result) => Boolean(result.choice) === expectedEligible));
  console.log(JSON.stringify({ commit: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(), fixtureOnly: true, route: 'Hono app.request through actual Exa SDK and owned HTTP /answer', calls, expectedEligible, results }, null, 2));
} finally {
  upstream.closeAllConnections();
  await new Promise((resolve, reject) => upstream.close((error) => error ? reject(error) : resolve()));
}
