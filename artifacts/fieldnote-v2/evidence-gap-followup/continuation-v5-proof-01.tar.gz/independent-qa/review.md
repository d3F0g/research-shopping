# Independent V5 functional and visual QA

The goal is useful source-backed Fieldnote recommendations while preserving the approved minimal dark-first chat UI. This review passes the scoped offline engineering and visual gates. Live retrieval, semantic relevance and shopping usefulness remain unproved.

The reviewer authored no application, maintained test, evaluator, or skill changes. No GitHub mutation or paid call occurred. The reviewer did not access private environment files, diagnostic captures, billing records, grants, the operator database, or the human preview.

## Exact scope

- Base is `dc61d3bae93fd347495ecbb5973d7877513ec91d`.
- Broad runtime candidate is `4c867e2dc77983019218f4390e834e727f97c5c4`.
- Final candidate is `347f3a17bd5881918f49edd361f4cd4527ae832c`.
- Owned worktree is `/tmp/fieldnote-v5-qa`. It has no tracked or untracked source changes.
- `final-source-and-archive-binding.json` records identical Git object IDs for `src`, `tests`, `scripts`, the project verification skill, package and lock files, and Vite, Playwright and Vitest configuration between runtime and final candidates. The final delta changes evaluator projection/assertions/tests and root documentation/archive records. It does not require a repeat of unchanged application checks.
- The separate baseline worktree `/tmp/fieldnote-v5-qa-base` was pinned to the base. It used its own dependency copy without Vite/cache directories.

## Commands and results

Commands ran from the owned worktree through `env -i` with only PATH, HOME, `NODE_ENV=test`, `EXA_RESEARCH_ENABLED=false`, and `LC_ALL=C`. Browser commands also received the installed Playwright cache path. No env-file option was used. Vite test configuration disables env loading, and the project skill uses `envFile: false` explicitly.

| Command | Result | Evidence |
| --- | --- | --- |
| `npm test` | 582 passed across 19 files | `initial-checks/unit.log` |
| `npm run build` | Passed, including typecheck. Nonblocking bundle-size warning remains. | `initial-checks/build.log` |
| `PLAYWRIGHT_API_PORT=3898 PLAYWRIGHT_WEB_PORT=5998 npm run test:e2e` | All maintained 31 tests passed. | `initial-checks/e2e.log` |
| `VERIFY_API_PORT=3873 VERIFY_WEB_PORT=5983 VERIFY_ARTIFACT_DIR=... node .agents/skills/verify-research-shopping/scripts/smoke.mjs` | Three viewports passed. Source was clean. Cleanup is true. | `initial-checks/skill/proof.json` and `initial-checks/skill.log` |
| `npm run test:postgres` | All 28 tests passed against an owned PostgreSQL 17 cluster. | `postgres.log` |
| `npm run verify:evidence:history` | Actual browser, Hono, Better Auth and PostgreSQL checks passed at desktop and mobile sizes. | `history.log` and `history-browser/proof.json` |
| `npm run verify:accounts:browser` | Full guest/authentication, stale success/failure, cancellation, isolation, refresh and deletion matrix passed at desktop and mobile sizes. | `accounts-browser.log` and `accounts/browser.json` |
| `npm run verify:accounts:restart` | Actual normal API and PostgreSQL restarts preserved typed currency draft, both accepted bounds, immutable messages and deletion. Research stayed disabled. | `restart.log` |
| `npm run verify:accounts:crash` | Actual SIGKILL during local SDK body consumption retained the pending reservation, prevented replay dispatch and late publication, and preserved ledger bytes. Only a disposable fixture ledger was used. | `crash.log` |
| `npm run verify:registry` | All 18 official component files match recorded CLI output. | `registry.log` |
| `npm run eval:preservation` | All 389 frozen assets unchanged. Repeated only after the final archive/evaluator delta. | `preservation.log` and `final-preservation.log` |
| `npm run eval:typecheck` | Passed on final candidate. | `eval-typecheck.log` |
| `npm run eval:test` | All 36 evaluator integrity tests passed on final candidate. | `eval-test.log` |
| `npm run eval -- --out artifacts/exa-owner/independent-v5-qa/eval-current` | Executed 60 cases and 140 turns. 11 passed, 0 failed, 48 blocked, 1 unsupported, 0 infrastructure errors and 0 critical failures. Acceptance remains inconclusive. | `eval-run.log`, `eval-current/report.json` and `eval-current/summary.md` |

The broad application tests ran at 4c867e2. Evaluator checks and the extra browser probe ran at final 347f3a1. All command sessions exited with status 0.

## Independent reproductions

`price-route-probe.mjs` defines two explicitly synthetic complete source formats, Markdown and ordinary prose. It drives actual Hono prepare/research requests and the actual Exa SDK against an owned loopback HTTP `/answer` server. Each source format produces exactly one local provider call.

`price-baseline.json` records both formats on dc61d3b. Both retained the source but produced an ineligible product and no choice. `price-candidate.json` records the same complete price evidence on the current native contract at 4c867e2. Both produced eligible Model A and a computed choice. This proves the ordinary-format regression and the scoped repair. It does not prove that a real provider will produce valid native assessments or retrieve relevant products.

The maintained V5 API pairs cover complete ordinary formatting against buyer restrictions, tax exclusions, conditional prices, quantity, installments, variant contradiction, shipping costs, competing amounts, exact minimum/maximum boundaries, ambiguous currency and incomplete source context. Their negative assertions use the current projector and research route. Grouped native price tests cover all 181 synthetic money occurrences, exact occurrence coverage, scope, overlap, missing groups, forged stored evidence, source-owned reviews and honest serialized bounds.

The evaluator delta now projects actual bound attribution offsets and the distinct native money witness, preserving their origin labels. Its mutation controls fail forged offsets, amounts, currency and a borrowed quote. Whitespace-aligned native wording remains explicit. An equality check against the actual raw response prevents the compatibility block from hiding a forged projection. The full 60-case result remains inconclusive because blocked cases and unassessed usefulness remain explicit.

`extra-browser.mjs` runs the real final app at 390 by 600 with the same local SDK composition. It verifies Enter versus Shift+Enter, ordinary free replies, an unfamiliar ultrasonic bat detector objective, dissatisfaction without a call or preference change, hard-brand retention, a flexible cheaper preference without inventing a budget, maximum change with minimum retained, currency change with both bounds retained, and atomic rejection of an unsupported compound edit. The exact earlier messages remain unchanged. `extra-browser-proof.json` and `extra-short-mobile-context-recovery.png` retain the result. Its synthetic powerbank response does not establish relevance to the unfamiliar objective.

The maintained native session tests exercise cancellation before response headers and during held response bodies. They inspect actual cookie ownership, exact two-turn history, draft retention, authoritative server state, follow-up, refresh and independent contexts. They do not claim cross-tab arbitration between independent roots sharing a cookie.

Mixed V2, V3 and V4 historical messages survive migration beside a new V5 snapshot. Actual authenticated browser/API/PostgreSQL restart checks retain the historical messages, reject stale prepared research without another local call, preserve unknown price/fit blockers, and isolate another account. Unit checks separately assert the serialized historical message/question bytes before and after migration.

## Visual inspection

I inspected these 29 screenshots directly. Paths below are relative to this report directory.

- `initial-checks/skill/desktop-01-dark-empty.png`, `desktop-02-light-empty.png`, `desktop-05-research-initial.png`, and `desktop-06-evidence.png`.
- `initial-checks/skill/mobile-03-ordinary.png`, `mobile-04-currency-question.png`, `mobile-05-research-initial.png`, and `mobile-08-preferences.png`.
- `initial-checks/skill/short-mobile-02-light-empty.png`, `short-mobile-05-research-initial.png`, `short-mobile-06-evidence.png`, `short-mobile-07-comparison.png`, `short-mobile-08-preferences.png`, and `short-mobile-11-provider-error.png`.
- `usefulness-browser/1440-prices-dark.png`, `390-prices-dark.png`, `1440-buyer-restriction.png`, `390-buyer-restriction.png`, `1440-held-light.png`, and `390-held-light.png`.
- `history-browser/1440-current-observation.png`, `390-current-observation.png`, `1440-literal-evidence.png`, and `390-literal-evidence.png`.
- `maintained-e2e/e2e/held-replies/short-mobile-battery-concise.png` and `short-mobile-battery-details.png`.
- `accounts/mobile-saved-research.png` and `mobile-stop-reset-conflict-recovered.png`.
- `extra-short-mobile-context-recovery.png`.

The screenshots retain the small header, centered conversation, dark first visit and compact bottom composer. The leading recommendation and first product name are visible before manual scrolling at 1440 by 1000, 390 by 844 and 390 by 600. Long evidence scrolls within the conversation. Text wraps without document overflow. The composer stays reachable. Controls and disclosure text remain readable. The skill also verifies hit-test points and nonoverlap with the floating scroll control. Held comparisons stay concise until details are explicitly requested. Full expanded evidence is long but remains scrollable. Observed money, AI interpretation, unresolved price applicability and unknown stock/delivery remain distinguishable.

## Archive and cleanup

The final archive was read without extraction or execution. Its 60 regular members match every manifest size and SHA256. All 53 retired loose files equal their 4c867e2 Git blobs byte for byte. The original five reports and nested original archive and manifest are exact. A current-source search found no imports or references from `src`, `tests`, `scripts`, `.agents`, `evals`, package/build configuration or workflows to those retired directories. `final-source-and-archive-binding.json` records these results.

Generated artifacts were relocated beneath this ignored evidence directory after the maintained helpers completed. Their proof files retain the original output locations, so use the paths in this report for the current copies. No maintained source was modified. The deterministic restart/crash output files already tracked by the repository remain byte-identical, as confirmed by the empty Git diff.

All owned helper processes exited. Ports 3898, 5998, 3873 and 5983 are free. The skill and extra probe both report cleanup true. Owned PostgreSQL helpers completed cleanup. The disposable baseline worktree was removed after its proof was retained. The QA worktree is retained for packaging evidence.

## Verdict and limits

Functional QA passes for this scoped offline migration and session repair. Independent visual QA passes for the inspected desktop, mobile and short-mobile states. No new blocking defect was reproduced. This is not a security verdict or merge authorization.

The documented signed-in Stop/New chat conflict remains fail-closed and requires an explicit browser refresh. The account sheet does not provide a signed-in reload action. Draft preservation across that explicit browser refresh is not established. This is a known separately tracked recovery limitation, not a newly waived finding.

No genuine Exa retrieval, one-call model compliance, semantic relevance, recommendation quality, current price, inventory, delivery or merchant authorization is established here. Quote containment proves provenance only. Frozen synthetic checks, source counts, schema validity and a passing build cannot satisfy those live acceptance gates. Root owns current CI, independent security review, publication review and the live-product/merge decision.

The Prove It Works principle changed the review from trusting owner summaries to rerunning real browser/API/SDK/PostgreSQL checks and inspecting screenshots. Test Behavior, Not Implementation required the baseline/fixed price pair and observable cookie/history/draft assertions. Separate Before Serializing Shared State required owned worktrees, ports, dependency copies and disposable PostgreSQL clusters. Model the Domain kept the independent source-format probe as an explicit case table. Technical Writing and Unslop kept the report factual and separated technical passes from unassessed product claims.
