import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { createServer } from 'node:net';
import { writeFile, createWriteStream } from 'node:fs';
import { promisify } from 'node:util';
import { chromium, expect } from '@playwright/test';
const directory = 'artifacts/exa-owner/independent-v5-qa';
const ports = [3898, 5998];
async function free(port) {
  const socket = createServer();
  await new Promise((resolve, reject) => { socket.once('error', reject); socket.listen(port, '127.0.0.1', resolve); });
  await new Promise((resolve) => socket.close(resolve));
}
await Promise.all(ports.map(free));
const env = { PATH: process.env.PATH, HOME: process.env.HOME, LC_ALL: 'C', NODE_ENV: 'test', EXA_RESEARCH_ENABLED: 'false', API_PORT: '3898', VITE_API_PORT: '3898', WEB_PORT: '5998' };
const children = [], log = createWriteStream(`${directory}/extra-server.log`);
function launch(args) {
  const child = spawn(process.execPath, args, { env, detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout.pipe(log, { end: false }); child.stderr.pipe(log, { end: false }); children.push(child);
}
let browser, cleanup = false;
const proof = { fixtureOnly: true, journeys: [], cleanup: false };
try {
  launch(['--import', 'tsx', 'tests/helpers/browser-server.ts']);
  launch(['--input-type=module', '-e', "import { createServer } from 'vite';const server=await createServer({envFile:false});await server.listen();"]);
  const origin = 'http://127.0.0.1:5998';
  for (let i = 0; i < 100; i++) {
    try { if ((await fetch(`${origin}/api/health`)).ok) break; } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  const health = await fetch(`${origin}/api/health`).then((r) => r.json());
  assert.equal(health.provider, 'exa'); assert.equal(health.automaticPaidChecks, false);
  browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 390, height: 600 }, colorScheme: 'light' });
  await context.route('https://**', (route) => route.abort());
  const page = await context.newPage();
  await page.goto(origin);
  const composer = page.getByRole('textbox', { name: 'Message', exact: true });
  const send = page.getByRole('button', { name: 'Send message', exact: true });
  const session = () => context.request.get(`${origin}/api/session`).then((r) => r.json());
  const calls = () => context.request.get(`${origin}/api/test-stats`).then((r) => r.json()).then((r) => r.calls);
  async function submit(message) {
    const answer = page.waitForResponse((r) => r.url().endsWith('/api/turn') && r.request().postDataJSON()?.phase === 'prepare');
    await composer.fill(message); await send.click(); await answer;
    await expect(page.getByRole('status')).toHaveCount(0);
    const current = await session(); proof.journeys.push({ message, intent: current.state.intent, assistant: current.state.messages.at(-1).text, calls: await calls() });
    return current.state;
  }
  await expect(send).toBeDisabled();
  await composer.fill('hello'); await composer.press('Shift+Enter');
  await expect(composer).toHaveValue('hello\n');
  await composer.press('Enter');
  await expect(page.getByText('Hi. What are you looking to buy?', { exact: true })).toBeVisible();
  assert.equal(await calls(), 0);
  const first = await submit('Find an ultrasonic bat detector between SGD30 and40');
  assert.match(first.intent.productDescription, /ultrasonic bat detector/);
  assert.deepEqual(first.intent.budget, { minimum: 30, maximum: 40, currency: 'SGD' });
  const original = JSON.stringify(first.messages);
  const disappointed = await submit("I don't like any of these.");
  assert.equal(await calls(), 1); assert.deepEqual(disappointed.intent, first.intent);
  assert.match(disappointed.messages.at(-1).text, /What should change/);
  let current = await submit('Only Lumenvale.');
  const hard = current.intent.requirements.filter((r) => r.strength === 'hard');
  current = await submit('Something cheaper.');
  assert.deepEqual(current.intent.budget, first.intent.budget);
  assert(hard.every((r) => current.intent.requirements.some((v) => v.id === r.id && v.text === r.text && v.strength === 'hard')));
  current = await submit('Make it 50.');
  assert.deepEqual(current.intent.budget, { minimum: 30, maximum: 50, currency: 'SGD' });
  current = await submit('Actually, USD.');
  assert.deepEqual(current.intent.budget, { minimum: 30, maximum: 50, currency: 'USD' });
  const accepted = current.intent, beforeCompound = await calls();
  current = await submit('make it 60 and remove that requirement');
  assert.deepEqual(current.intent, accepted); assert.equal(await calls(), beforeCompound);
  assert.equal(JSON.stringify(current.messages.slice(0, first.messages.length)), original);
  await expect(composer).toBeInViewport(); assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await page.screenshot({ path: `${directory}/extra-short-mobile-context-recovery.png` });
  proof.result = 'passed';
  proof.limits = 'Explicit synthetic native evidence through actual Hono and SDK local HTTP. Novel input acceptance only, no factual relevance or live usefulness claim. Keyboard Enter and Shift+Enter only, no OS IME claim.';
} finally {
  await browser?.close();
  for (const child of children) if (child.exitCode === null && child.signalCode === null) { const exited = once(child, 'exit'); process.kill(-child.pid, 'SIGTERM'); await exited; }
  await Promise.all(ports.map(free)); cleanup = true; proof.cleanup = cleanup;
  await promisify(writeFile)(`${directory}/extra-browser-proof.json`, JSON.stringify(proof, null, 2)); log.end();
}
