# Grounding and implementation boundary

## Current flow

Observed source at `dc61d3bae93fd347495ecbb5973d7877513ec91d` supplies the following architecture.

`src/server/exa-research.ts` privately owns `NativeProduct`, `NativeAnswerSchema`, the prompt, source retention, and projection. `retainSources` keeps ten safe distinct URLs and up to 24,000 characters per source. Its completeness flag records overflow, duplicate URL conflict, and text cuts. `bindAssessment` binds reported quotes and may downgrade positive assessments. `bindPrice` calls the sentence parser for each supporting context and every source. That couples semantic attribution to a fixed sentence grammar and makes unrelated monetary syntax relevant to qualification.

`src/server/price-evidence.ts` owns that grammar. Its `assertion` accepts exact variant subjects with `costs`, `is priced at`, or `has a price of`, or a plain heading followed by money. Its condition vocabulary is also finite. `catalogPriceObservation` adds a separate strict two-line scalar fallback. A Markdown title and table row need neither match even when the source and native interpretation are otherwise complete.

`src/domain/research.ts` currently re-exports V4 types. `assessProduct` separately checks exact identity, request match, every hard group, conditions, currency, and both numerical budget bounds. These gates remain. `src/domain/research-history-v4.ts` validates V4 storage and its catalog fallback. `workspace.ts` currently accepts V2, V3, and V4 evidence in workspace schema 4. `conversation.ts` currently references current evidence plus V2 and V3. A current-export change alone would lose the V4 union member.

`src/client/ResearchAnswer.tsx` displays existing price and catalog observations through the approved card and disclosure components. `src/domain/rendered-evidence.ts` owns quote provenance labels. The implementation must preserve these visual structures.

## New ownership

| Owner file | Exact responsibility |
| --- | --- |
| `src/server/exa-research.ts` | Replace private native price field with `priceReview`, prompt, and schema within the existing single Exa answer operation. Parse native wire shape, map canonical safe URLs to retained source IDs, and pass a `ReportedPriceReview` into the domain boundary. Retain mapping failures. Remove old normal-path sentence-parser and catalog fallback calls. |
| `src/domain/price-evidence.ts` | Own V5 binding, explicit-money lexer, source coverage, immutable evidence types, and pure qualification. Private helpers are not exported. No provider, network, storage, or UI imports. |
| `src/domain/research-history-v5.ts` | Own V5 snapshot schema with `version: 2`, `evidenceVersion: 5`, and `priceEvidence`. V5 validation checks source references, real offsets, coverage, literal money, and recomputed eligibility consistency. New domain types derive from this authoritative schema. |
| `src/domain/research.ts` | Export current V5 domain. Keep all identity, objective, hard-criterion, currency, and minimum/maximum eligibility gates. Replace only the price gate with `qualifyingObservedPrice`. |
| `src/domain/rendered-evidence.ts` | Add version-dispatched price presentation without recomputing historical meaning. Keep provenance labels. |
| `src/client/ResearchAnswer.tsx` and free detail reply owner in `src/domain/turn-reducer.ts` | Consume the same presentation projection. Existing component composition and layout remain. Preserve adverse passages, qualification labels, and no-dispatch local detail behavior. |
| New `src/domain/workspace-history-v4.ts` | Freeze actual schema-4 envelope and message union, including explicit V4 research import and existing active intent shape. This is a copy of actual behavior, not a widened synthetic decoder. |
| `src/domain/workspace.ts` and `conversation.ts` | Introduce workspace schema 5 and explicitly include V2/V3/V4/V5 research and renderable kinds. Upgrade only active workspace envelope and validated current preferences. Preserve historical research, questions, requests, messages, receipts, and snapshot intent unchanged. |

The final implementation must avoid an import cycle between the V5 schema and price logic. Define authoritative price schemas and pure validators in the one price module. V5 imports that module, while it imports no research snapshot types. Current `research.ts` imports both. The display adapter accepts the explicitly versioned union, parses once, and trusts the resulting types.

The provider's private wire schema and domain report are intentionally different. The former has citation URLs and transport bounds. The latter has retained source IDs and reported domain claims. Derive the shared judgment shape from the authoritative domain schema where practical. Do not maintain two hand-copied semantic status lists. The domain binder checks provenance and money against source content. It does not reparse an already validated network envelope.

Bound the report to ten source reviews per product, twelve relevant monetary observations, and sixteen terms per product. These are evidence capacity limits, not a commerce-language vocabulary. A truthful overflow becomes explicit unresolved evidence. Source text and its cut provenance remain available under the existing source limits. An implementation may raise these bounds if serialized workspace tests justify it, but may never drop adverse information to keep a positive result.

## Version and compatibility decision

Keep request envelope version 2 and intent version 2 because their meaning does not change. Bump evidence to 5 because qualification semantics and observation shape change. Give the private native answer contract an explicit independent revision of 2. If the actual SDK's documented schema dialect rejects a constant discriminator, select revision 2 through the exact requested response schema and adapter configuration, never by guessing from a partially accepted payload. This design requires no Exa request-field change beyond the established structured answer payload. Implementation must still read the canonical Exa setup output before editing its contract.

Freeze `research-history-v3.ts`, `research-history-v4.ts`, `workspace-history-v2.ts`, `workspace-history-v3.ts`, and their V3/V4 binding semantics. Copy the actual current workspace-4 decoder before changing current imports. Import V4 explicitly wherever current unions previously implied it. Never decode old evidence through V5 or recalculate old prices, blockers, choice, rationale, snapshots, or historical requests. New qualification never grants historical retry or paid actions. Restart migration interrupts old pending receipts by the existing rule. It does not prepare new work.

Keep the old parser only where an actual frozen historical decoder requires it. Delete unused normal-price exports and their current call sites in the same implementation wave. Old parser suites remain useful only if they still test a real frozen path. Re-express their behavioral assertions against V5. Do not label a disconnected old parser suite as coverage of the replacement.

## Scope limits

This design changes source-based evidence interpretation, not the approved UI or intent reducer. It introduces no merchant API, stock claim, fixture fallback, product registry, inference service, runtime model, automatic retry, or extra paid operation. A source amount can become useful comparison information while remaining ineligible. Unassigned amount, unresolved currency, conflicts, buyer conditions, and incomplete source context are legitimate outcomes.

The root's supplied private-replay conclusion is evidence of the symptom only. This seat did not inspect its raw payload, diagnostics, ledger, or grants. The proposed ordinary Markdown positive cases are synthetic tests. They do not establish live usefulness.

## Principle decisions

- Fix Root Causes changed the chosen repair from sentence-pattern expansion to replacement of the semantic price boundary.
- Model the Domain changed the representation from one price plus catalog fallback to one per-source record of candidates, other amounts, conditions, and scope.
- Boundary Discipline changed which checks the server claims to prove. Provenance, amount, explicit currency, source completeness, and coverage are deterministic. Meaning stays a source-based AI judgment.
- Type System Discipline changed the qualification interface. Only bound explicit money can enter an applicable result. Unknown currency remains a separate variant.
- Laziness Protocol limited the design to one existing Exa answer, one authoritative price model, and a small presentation adapter.
- Prove It Works changed acceptance from green parser tests to paired SDK, API, browser, history, and authorized real-product evidence.

## Red-flag screen

The application does not coordinate parse stages. The price module owns the full operation. Private native wire types stay in the provider adapter. There is one current price model and qualification implementation. Presentation derives price labels instead of storing a second price copy. Frozen historical decoders are explicit read-only contracts, not alternative ways to produce current research. Tests must prevent new imports of historical qualification helpers from current research. Source review state is immutable and scoped to one response, so this design creates no new shared mutable actor state.
