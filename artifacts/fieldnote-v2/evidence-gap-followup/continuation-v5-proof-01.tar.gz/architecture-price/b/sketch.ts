/* Design sketch only. Bodies deliberately throw. Types show ownership, not production code. */

// Caller 1. The existing Exa adapter, after parsing one answer and retaining sources.
// const priceEvidence = bindPriceReview(reportedPriceReview, {
//   product: { id: p.id, name: p.name, variant: p.variant }, sources,
// });
// const product = assessProduct({ ...identityAndCriteria, priceEvidence }, intent);

// Caller 2. Server eligibility. This replaces the old price-specific branch only.
// const price = qualifyingObservedPrice(product.priceEvidence, product.variant);
// if (intent.budget && price.kind === "unresolved") blockers.push(...price.blockers);
// if (intent.budget && price.kind === "applicable") {
//   compareBothBoundsInExplicitCurrency(price.money, intent.budget);
// }
// The full identity, requestMatch, and hard-requirement gates still run independently.

// Caller 3. Existing chat product card and free local detail reply.
// const display = presentPrice(snapshot.evidenceVersion, product);
// renderExistingPriceLine(display.headline, display.qualifications);
// renderExistingEvidenceDisclosure(display.assessments, display.passages);
// No research dispatch, preferences mutation, or eligibility recomputation on old history.

type Brand<T, Name extends string> = T & { readonly __brand: Name };
type SourceId = Brand<string, "SourceId">;
type ObservationId = Brand<string, "ObservationId">;
type MinorUnits = Brand<number, "PositiveSafeMinorUnits">;
type Currency = Brand<string, "ExplicitCurrency">;
type SafeUrl = Brand<string, "SafeUrl">;
type Span = Readonly<{ start: number; end: number; text: string }>;

type RetainedSource = Readonly<{
	id: SourceId;
	url: SafeUrl;
	text: string;
	originalLength: number;
	textTruncated: boolean;
}>;

type SourceSet = Readonly<{
	items: readonly RetainedSource[];
	completeness: "complete" | "cut" | "overflow" | "conflicting-url";
	// Actual cut provenance belongs here. Native quotations cannot repair it.
}>;

type BoundPassage = Brand<Readonly<{
	sourceId: SourceId;
	origin: Readonly<{
		kind: "provider";
		reportedQuote: string;
		match: "literal" | "whitespace";
	}>;
	literal: Span;
	context: Span;
}>, "BoundPassage">;

type AiJudgment = Readonly<{
	kind: "source-based-ai";
	status: "supported" | "unknown" | "contradicted" | "conflict";
	scope: "exact-variant" | "product-family" | "unclear";
	rationale: string;
	support: readonly BoundPassage[];
}>;

type ExplicitMoney = Brand<Readonly<{
	minorUnits: MinorUnits;
	currency: Currency;
	// Both tokens bind to the same provider-cited observation passage.
	amountSpan: Span;
	currencySpan: Span;
	passage: BoundPassage;
}>, "BoundExplicitMoney">;

type ObservedAmount = Readonly<{
	id: ObservationId;
	value:
		| { kind: "explicit-money"; money: ExplicitMoney }
		| { kind: "unresolved-money"; passage: BoundPassage; reason: string };
	// These are AI labels, never deterministic semantic proof.
	role: "candidate" | "superseded" | "other-variant" | "range" | "installment" | "bundle" | "unclear";
	attribution: AiJudgment;
	relationToCandidate: AiJudgment;
}>;

type PriceTerm = Readonly<{
	text: string;
	applicability: AiJudgment;
	resolution:
		| { kind: "source-supported"; assessment: AiJudgment }
		| { kind: "buyer-dependent" }
		| { kind: "unknown" }
		| { kind: "adverse"; assessment: AiJudgment };
}>;

type SourcePriceReview = Readonly<{
	sourceId: SourceId;
	// This declares assessment of the complete retained source, not just the quotes.
	// The server checks complete coverage, not whether the AI read or understood it.
	reviewedExtent: "entire-source";
	relation:
		| { kind: "selected-product"; assessment: AiJudgment }
		| { kind: "other-product"; assessment: AiJudgment }
		| { kind: "no-monetary-claim"; rationale: string }
		| { kind: "unclear"; rationale: string };
	observations: readonly ObservedAmount[];
	terms: readonly PriceTerm[];
}>;

export type PriceEvidence = Brand<Readonly<{
	semantics: "source-review-v1";
	availability: "reviewed" | "no-report" | "invalid-report";
	reviews: readonly SourcePriceReview[];
	candidateId: ObservationId | null;
	// Boundary derives failures. Native input cannot set or clear them.
	boundaryBlockers: readonly string[];
}>, "PriceEvidence">;

type ProductTarget = Readonly<{ id: string; name: string; variant: string | null }>;

type ReportedPassage = Readonly<{ sourceId: SourceId; quote: string }>;
type ReportedJudgment = Omit<AiJudgment, "support"> & Readonly<{
	support: readonly ReportedPassage[];
}>;
type ReportedObservation = Omit<ObservedAmount, "value" | "attribution" | "relationToCandidate"> & Readonly<{
	value: Readonly<{
		amount: number | null;
		currency: string | null;
		passage: ReportedPassage;
	}>;
	attribution: ReportedJudgment;
	relationToCandidate: ReportedJudgment;
}>;
type ReportedTerm = Readonly<{
	text: string;
	applicability: ReportedJudgment;
	resolution:
		| { kind: "source-supported"; assessment: ReportedJudgment }
		| { kind: "buyer-dependent" }
		| { kind: "unknown" }
		| { kind: "adverse"; assessment: ReportedJudgment };
}>;
type ReportedSourceReview = Readonly<{
	sourceId: SourceId;
	reviewedExtent: "entire-source";
	relation:
		| { kind: "selected-product"; assessment: ReportedJudgment }
		| { kind: "other-product"; assessment: ReportedJudgment }
		| { kind: "no-monetary-claim"; rationale: string }
		| { kind: "unclear"; rationale: string };
	observations: readonly ReportedObservation[];
	terms: readonly ReportedTerm[];
}>;

// Adapter parses the private native schema and converts URLs to retained source IDs.
// It does not assess semantics or discard failed references.
export type ReportedPriceReview = Readonly<{
	availability: "reviewed" | "no-report" | "invalid-report";
	reviews: readonly ReportedSourceReview[];
	candidateId: ObservationId | null;
	adapterFailures: readonly string[];
}>;

export function bindPriceReview(
	report: ReportedPriceReview,
	context: Readonly<{ product: ProductTarget; sources: SourceSet }>,
): PriceEvidence {
	// Pseudocode. Bind adapter-validated reports to retained safe source IDs.
	// Require exact source coverage. Adapter failures remain blockers.
	// Bind all native passages uniquely, with original quote and bounded complete context.
	// Retain all observed amounts, terms, adverse statuses, and invalidity reasons.
	// Bind decimal amount and explicit denomination inside each observation passage.
	// Do not infer denomination from a different paragraph, user budget, seller, or host.
	// Scan all retained source text for money tokens solely as an omission alarm.
	// Any uncovered token blocks qualification. Token scanning never proves absence of terms.
	// Treat unrecognized tokens conservatively. Support spelling is a money lexer concern.
	// Complete coverage of tokens is necessary, never sufficient for semantic qualification.
	// Preserve all actual cut, overflow, conflict, and source-instruction blockers.
	throw new Error("not implemented");
}

export type PriceQualification =
	| Readonly<{
		kind: "applicable";
		basis: "source-based-ai";
		money: ExplicitMoney;
		variant: string;
		conditions: readonly PriceTerm[];
	}>
	| Readonly<{ kind: "unresolved"; blockers: readonly string[] }>;

export function qualifyingObservedPrice(
	evidence: PriceEvidence,
	selectedVariant: string | null,
): PriceQualification {
	// Pseudocode. Require valid complete source coverage and exactly one selected candidate.
	// Candidate needs explicit money and supported exact selected-variant attribution.
	// Every source relation and other amount's role must be resolved by AI assessment.
	// Reject conflicts, unclear scopes, mixed variants, ranges, and missing mandatory totals.
	// Another amount can be excluded only with retained, supported scope or supersession evidence.
	// Buyer-dependent terms never qualify in this change. Do not infer user entitlements.
	// Relevant terms require supported source resolution. Preserve adverse terms in output.
	// A different product may have money. Its supported scoped review does not poison this one.
	// This result says applicable observed money, never verified offer, stock, or delivery.
	throw new Error("not implemented");
}

type PricePresentation = Readonly<{
	headline: string;
	qualifications: readonly string[];
	assessments: readonly AiJudgment[];
	passages: readonly BoundPassage[];
}>;

export function presentPrice(evidenceVersion: 2 | 3 | 4 | 5, product: unknown): PricePresentation {
	// Pseudocode. Dispatch to the frozen decoder for the declared version.
	// V2/V3/V4 read saved values without invoking V5 qualification.
	// V5 derives observed amount and honest qualifications from PriceEvidence.
	// Unknown variant money stays labeled as unassigned source money.
	// Render all relevant terms and conflicts through existing disclosure components.
	throw new Error("not implemented");
}
