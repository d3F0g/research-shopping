# Candidate B plan

1. Ground. Complete. Read shared grounding and current public source at dc61d3bae93fd347495ecbb5973d7877513ec91d.
2. Sketch. Complete. Produce usage, domain signatures, a source review contract, and paired acceptance cases.
3. Agree. Root's architecture synthesis owns this step. No human checkpoint is requested.
4. Implement. Skip. This seat is design only.
5. Scrap. Root revisits the contract if paired cases or real-source proof refute it.

Throughput checkpoint. One source review boundary replaces current price sentence recognition. A separate V5 decoder freezes older evidence. A single application owner implements the selected design. Independent reviewers inspect the exact commit. This seat performs no source edits, runtime changes, provider calls, or private reads.
