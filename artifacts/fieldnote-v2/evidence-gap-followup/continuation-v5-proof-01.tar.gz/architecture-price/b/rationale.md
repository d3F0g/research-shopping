# Ordinary source price interpretation

## Problem

Preserve Fieldnote's approved chat UI and make ordinary research produce useful, honest prices and recommendations. At dc61d3b, `bindPrice` delegates semantic attribution to `assessPriceContext`, which accepts a small sentence grammar. A complete Markdown heading and price table can fail before price uncertainty is assessed. Another product's monetary prose can make an otherwise applicable price unresolved. The root's private replay established three relevant products with null prices. That replay does not establish that any particular price deserves qualification. Bare dollars, variant ambiguity, conditions, conflicting observations, and discarded context remain real blockers.

## Usage

The provider adapter submits one existing Exa operation with a structured source-review answer contract. It calls `bindPriceReview` once per returned product. The boundary checks quotations, currency tokens, amounts, source completeness, and coverage. It retains the provider's semantic judgments as AI judgments. `qualifyingObservedPrice` returns a source-based applicable observation or explicit blockers. The existing server eligibility calculation consumes that result. The chat card displays an observed amount with its qualifications, and its existing disclosure displays every relevant adverse passage. See `sketch.ts` for three call sites before the types.

## Shape

A price review owns one product's observations across every retained source. Each source entry states whether its text concerns the selected product, another product, or an unresolved relationship. Relevant entries retain every monetary observation and condition. The provider identifies current price, previous price, range, installment, another variant, and unclear amounts semantically. It supplies literal supporting passages and explanations. The server binds amount and explicit currency inside each observation's own passage. It never moves a currency or price across passages merely because their numbers match. This follows Model the Domain and Type System Discipline.

One `priceEvidence` field replaces the current dual `price` and catalog-row fallback in new evidence only. Presentation and eligibility derive from that field. A source review cannot manufacture merchant verification, inventory, or a shopper entitlement. The same Exa response supplies semantic interpretation. There is no second inference service or additional call. This follows Laziness Protocol.

Qualification requires complete retained sources, coverage of every source, an exact-variant supported candidate, a deterministic money binding, and no unresolved relevant competitor or term. An explicitly scoped unrelated source does not poison the candidate merely because it mentions money. Missing coverage, an unclear relationship, dropped source text, conflicting duplicate URLs, an instruction-bearing source, or an unretained qualifier blocks qualification. Global source cut conservatism remains unchanged. Source relevance and clause meaning remain AI assessments, visibly unverified. Quote containment proves provenance only. This follows Boundary Discipline and Fix Root Causes.

The public price boundary has one binding operation and one pure qualification operation. They hide quote matching, source coverage, and numerical checks. The provider adapter alone validates wire shape and maps citation URLs to retained source IDs. Callers supply a product target and accepted intent. They do not coordinate parser stages or import wire schemas. A separate display projection preserves the existing card layout. The source-review contract is a replacement, so new normal research has one price path.

## Synthesis decision

Pending the root's independent comparison. This candidate recommends a per-source review record as the base. No sibling candidate or picker rubric was read.

## Tradeoffs accepted

- We accept a larger structured Exa answer in exchange for retaining source scope and adverse observations explicitly. Bounded overflow makes qualification unresolved instead of silently dropping evidence.
- We accept source-based AI judgments in exchange for interpreting ordinary commerce language. Deterministic validation verifies provenance and money, not semantic entailment. A provider that confidently misreads an intact passage remains a product risk.
- We accept a small render adapter change in exchange for one authoritative new price model. The approved components, layout, theme, and conversation structure stay intact.
- We accept unresolved treatment of buyer-dependent offers and incomplete mandatory totals. Membership, vouchers, tax exclusions, and shipping conditions cannot become resolved from provider confidence alone.

## Alternatives considered

- Extend `assessPriceContext` with Markdown and more phrases. The interface appears small but exposes its grammar to every producer and test author. It cannot bound ordinary language, qualifier scope, or arbitrary variant names. It preserves the demonstrated failed premise.
- Trust `NativeProduct.price.assessment` and `conditionsResolved` directly. This hides too much behind an unexamined boolean. It cannot retain competing amounts or prove that the provider reviewed an adverse source.
- Add a separate local or remote interpretation step after Exa. This introduces another inference dependency and lifecycle. It does not supply missing source text or stronger factual proof and exceeds this defect's scope.

## Open questions and risks

- Can Exa reliably emit the bounded per-source review contract for ordinary complete source pages? The implementation owner must answer with local boundary tests and root's authorized live proof. No new allowance is implied.
- Can an independently authored case with a falsely positive semantic judgment bypass the safeguards? QA must report that result as an AI semantic failure. A token check must never be reported as semantic verification.
- Does a V5 snapshot fit existing workspace bounds with the retained sources and review passages? Test the actual serialized payload and retain the existing explicit failure or whole-turn eviction policy. Do not trim qualifiers to fit.

These are implementation and verification questions. They do not require a human design approval gate.

## Next implementation step

Land complete positive Markdown source cases and paired adverse cases as failing tests at the existing SDK projection boundary before replacing the normal price contract.
