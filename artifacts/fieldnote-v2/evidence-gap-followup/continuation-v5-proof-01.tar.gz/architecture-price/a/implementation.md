# Implementation and verification scope

## Native answer change

Keep `exa.answer`, its cancellation signal, deadline, accounting, and one-call admission unchanged. Keep `text: true`, the current Draft 7 JSON Schema target, and the server-owned intent prompt. Give the new private answer schema an explicit `answerVersion: 2`. It is distinct from the persisted response envelope and evidence versions.

Keep existing identity, request-match, requirement, attribute, choice, and limitation fields. Replace only native `price` with this packet shape.

```text
price = null | {
  amount: number | null,
  currency: ISO code | null,
  variant: string | null,
  moneySupport: { url, quote },
  attribution: NativeAssessment,
  priceBasis: { kind: single-item | range | bundle | installment | unknown,
                assessment: NativeAssessment },
  sourceReviews: [{
    url,
    reviewComplete: boolean,
    relation: applies | other-product-or-topic | unknown,
    assessment: NativeAssessment,
    moneyMentions: [{ quote, role, assessment: NativeAssessment }],
    conditions: [{ quote, text, interpretation, rationale }]
  }]
}
```

All model judgments remain source-based AI interpretations. URLs must be actual safe returned citation URLs. Every quote must bind uniquely. `moneySupport` must include the proposed monetary token. An identity-only quote cannot authorize scanning the page for a substitute amount. The server owns passage identifiers and offsets. It never turns an expanded context span into a model-reported quotation.

Remove native `conditionsResolved`. An included tax or unit detail can be a resolved condition only when its supported interpretation says it is already included in the scalar amount. Shopper eligibility, unknown quantity applicability, extra cost, or contradictory conditions block the applicable branch. The current intent has no typed merchant membership proof. Do not infer it. A product sold as a pair can be one purchase unit when the source and complete request match establish that fact. Do not divide bundle prices or sum extra charges to manufacture a scalar qualifying total in this change.

`sourceReviews` covers the complete retained source set by URL. Missing or duplicate reviews are unresolved, never an implied irrelevant source. Reviews cover price context and contrary evidence beyond the quoted positive phrase. All retained text remains available to the user. Positive and adverse findings have separate support. Existing support-count limits cannot silently truncate the adverse side.

Bound the native packet to the existing three candidates and ten retained URLs. Each candidate has at most ten source reviews, 24 total monetary-mention records across those reviews, and eight total conditions. A short source quote remains at most 4,000 characters. Do not repeat complete source text in the native answer. The persisted source record owns it. A source review that cannot fit must report `reviewComplete: false`; that field cannot grant confidence, and any false value blocks applicability. Server-side aggregate checks and the lexical inventory catch dropped records even if the model claims completeness. Hitting a cap retains the observation and sources with an explicit incomplete-review blocker.

These are bounded design limits, not measured Exa output limits. The SDK loopback test must confirm that the exact generated Draft 7 schema accepts a minimal positive and rejects malformed packets. It cannot prove the real model fills this wider schema reliably. Independent authorized normal-path acceptance must establish that before merging. If packet size causes frequent incomplete reviews, reopen this contract instead of increasing limits or adding another call without evidence.

The server inventories literal monetary mentions in retained sources. Its lexer recognizes explicit supported denominations, ambiguous currency symbols, amounts, and multi-amount expressions. This is number syntax, not a sentence grammar. Every detected mention needs a bound role in the review. A review with unexplained money is unresolved. A recognized reference amount or another product's amount stays visible but need not conflict with the selected price. A bare dollar token cannot be relabeled SGD based on a neighboring row, seller, domain, or region. Unsupported number syntax remains unresolved.

This inventory detects omitted amounts. It cannot prove that every condition without money was understood. Existing adverse veto cases remain an independent, non-authorizing check. Keep their negative assertions during migration. Do not claim that this finite safety corpus understands arbitrary commerce prose. A newly required semantic rule belongs in the model contract and evaluation, not automatically in another sentence regex.

## Qualification rule

The server may construct `state: applicable` only when all of the following hold.

1. The exact observed amount and explicit denomination bind to the model's actual money support. Integer minor units match the reported number without rounding or endpoint selection.
2. Identity and the price's attribution support the same selected variant. `priceBasis` supports a scalar price for the requested purchase unit.
3. All retained sources have complete price-context reviews. Every detected monetary mention is accounted for, and no relevant source is unresolved or contradictory.
4. Every retained condition is already included in the observed amount. Shopper eligibility, unpriced charges, conflicting conditions, and missing applicability remain blockers.
5. Retention is complete. A cut, a source-count overflow, conflicting text at one canonical URL, an unbound quote, or instruction-bearing evidence cannot gain authority through a native positive assessment.
6. No existing adverse veto fires. The server cannot let a model's favorable summary overrule these checks.

`assessProduct` then enforces exact identity, full request match, every current hard criterion, explicit requested currency, and both inclusive budget bounds. It does not use bare observations. The server retains its flexible-preference coverage order and current choice policy. A provider summary cannot override a computed blocker.

Incomplete retention may still keep a literal observed amount with prominent uncertainty if the amount's exact span survives. It cannot keep `usableMoney`. A prefix cannot claim its trailing qualification was absent. If the retained amount itself is split or unbindable, keep the source text and report no scalar observation.

## File ownership and module map

The application owner implements these files in its assigned isolated worktree. This list describes the eventual patch, not edits made by this candidate.

| File | Responsibility |
| --- | --- |
| `src/server/exa-research.ts` | Own the private native schema and prompt. Pass one native packet into the price boundary. Preserve transport and admission. |
| `src/server/price-evidence.ts` | Replace positive grammar and catalog fallback with one `bindPriceEvidence` boundary. Keep private lexical/binding helpers here. Keep non-authorizing adverse checks. |
| `src/domain/research-history-v5.ts` | Own immutable V5 price, source-review, and response schemas. Validate stored provenance and internal consistency without reconstructing semantic judgments. |
| `src/domain/research.ts` | Export V5 as current. Gate budget eligibility on applicable evidence. |
| `src/domain/price-view.ts` | Derive V5 price text and disclosure references for the renderer and held replies. Do not validate or reinterpret evidence here. |
| `src/domain/workspace-history-v4.ts` | Freeze the actual V4 workspace and conversation codec before advancing current storage. |
| `src/domain/workspace.ts`, `conversation.ts` | Add explicit V5 current types and V4 historical dispatch. Migrate active state only. |
| `src/domain/turn-reducer.ts` | Read V5 via the shared display adapter. Reassess only current V5 evidence against current intent. |
| `src/client/ResearchAnswer.tsx` | Feed V5 display data into existing shadcn and AI Elements cards and disclosure. Retain V2 through V4 render branches. |
| Existing API tests, history tests, SDK loopback helpers, and browser journeys | Replace current wire composition and assert the same user-observable safeguards. Add the paired cases in `cases.md`. |

Do not create a public collection of `parse`, `validate`, `qualify`, and `reconcile` stages. Those helpers are private knowledge of the price boundary. Imports outside the server price module use its one exported entry. A build or import rule should prevent importing a new internal submodule if implementation splits the file. Do not re-export native wire types through the domain.

## Historical freeze

Keep response envelope `version: 2`, active `intentVersion: 2`, and existing hard constraints. Publish new responses with `evidenceVersion: 5`. Advance the workspace storage schema from 4 to 5 because its accepted historical union changes.

Freeze actual V2, V3, and V4 snapshots, preference snapshots, request kinds, question kinds, and response kinds. Preserve `workspace-history-v2.ts`, `workspace-history-v3.ts`, `research-history-v3.ts`, `research-history-v4.ts`, and `evidence-binding-v4.ts` as historical dependencies. Add the frozen V4 workspace codec before changing current imports. Its schemas must not import mutable current intent or price schemas.

Migration reads versions 2, 3, and 4 with their matching frozen codecs. It copies historical messages and requests without changing their evidence, qualification, summary, source, or choice. It validates only active preferences through the current intent migration. Pending research becomes interrupted under the existing lifecycle rule. Historical prepared requests cannot regain paid actions. New writes use workspace schema 5. Round-trip actual composed V2, V3, and V4 records, not invented minimal examples.

Historical display can show the old recorded recommendation. New held replies must say that old evidence has not been assessed under the current contract. They must not call the V5 gate on an old product or construct missing V5 source reviews. Compare serialized historical records before and after migration. V4 catalog observations retain their original `kind`, money, support origins, reported conditions, and unknown attribution.

## Verifiable implementation units

1. Commit the full-source ordinary-Markdown failing case and its paired adverse cases before the fix. Drive `projectExaAnswer` and the actual HTTP research route with local synthetic SDK responses.
2. Freeze V4 storage and add current V5 schema and native contract together. Change the price boundary and every current caller in the same implementation wave. Delete unused positive grammar and catalog fallback from the current path. Keep historical validators.
3. Run focused API, domain, and history checks. Assert observed amounts, honest qualifications, full adverse text, choice, numeric bounds, and unchanged historical bytes. Do not assert private helper order.
4. Run the actual Exa SDK against an owned loopback transport with fake credentials. Inspect the Draft 7 request schema, full accepted intent, one request per research submission, cancellation, malformed answer behavior, and absence of fixture fallback. No production provider contact is allowed.
5. Run the browser journey with the project verification skill. Exercise concise comparison, evidence disclosure, free follow-up, changed budget, new objective retaining hard constraints, refresh, and an old historical conversation. Inspect desktop and mobile screenshots of the existing UI.
6. The root obtains exact-head independent QA and security reviews and actual configured CI results. Product QA must distinguish synthetic projection checks from genuine authorized request-to-recommendation usefulness.

Useful package checks are `npm test`, `npm run build`, `npm run test:e2e`, and `npm run verify:evidence:history`. The owner first runs the targeted files, then the normal required suite. All automated composition uses local substitutes with live Exa disabled. This design creates no allowance and reserves no request. Only the root can coordinate any separately authorized human-submitted live acceptance.

## Stop and reopen the design

Reopen the shape if ordinary complete pages require a growing sentence registry, if multiple callers must reproduce qualification rules, if the answer schema cannot reliably account for retained sources within one call, or if an adverse review is dropped to satisfy a storage limit. Keep the product defect open if independent product QA still finds relevance, price, constraint, or recommendation blockers. A passing build, local fixture, source count, and schema-valid answer do not establish usefulness.
