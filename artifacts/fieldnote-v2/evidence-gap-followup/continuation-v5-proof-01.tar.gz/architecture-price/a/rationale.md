# Source-reviewed price observations

## Problem

Fieldnote should retain useful source prices in its approved chat UI without inventing budget compliance. At `dc61d3bae93fd347495ecbb5973d7877513ec91d`, `bindPrice` asks a small English sentence parser to establish both monetary provenance and commercial meaning. Ordinary complete Markdown can fail that grammar. A scalar price, one assessment, and `conditionsResolved` also cannot explain which retained source qualifies a price or introduces a conflict. V2, V3, and V4 responses must retain their original meanings.

## Usage (caller's view)

The existing Exa operation calls `projectExaAnswer(raw, intent)` once. It receives a V5 snapshot whose product has one `priceEvidence` value. `assessProduct(product, intent)` can use money only from the `applicable` branch. `priceView(product.priceEvidence)` gives both the existing product card and held-detail replies the same amount label, qualifications, and evidence references. Historical renderers keep their existing schemas and labels. [The sketch](sketch.ts) writes these call sites before the types.

## Shape

Replace the native price object with one candidate-scoped evidence packet. It names a proposed literal amount, explicit denomination evidence, exact product and variant attribution, price basis, source-linked conditions, and one price-context review for every retained source. Exa interprets commercial meaning. The server binds quotations, checks literal scalar money, accounts for monetary mentions, retains complete source context, and derives applicability and budget eligibility. No provider Boolean grants eligibility. This separates commercial interpretation from money and provenance, per Model the Domain and Boundary Discipline.

The new domain union distinguishes absence, observation, and an applicable observed price. An unresolved observation can have unknown currency or variant. Only the applicable branch contains `usableMoney`. This is still an AI source assessment, never merchant verification. All relevant conditions and contrary observations remain attached to the observation, per Type System Discipline.

Replace the positive sentence grammar, the two-line catalog rescue path, and the requirement that every retained page parse as the same qualified price. Explicit unrelated-source judgments and accounted-for other-product money do not poison a complete candidate. Missing reviews, unresolved source relationships, omitted monetary mentions, cuts, duplicate-URL conflicts, and contradictory observations block applicability. Existing non-authorizing adverse checks remain vetoes during this change. They must not become a new positive grammar or a growing language parser. Per Fix Root Causes, a new prose-format failure must first be assigned to semantic interpretation, literal binding, or actual missing evidence.

Three callers use two meaningful boundaries. The provider adapter owns its private wire schema. The price-evidence module owns binding and qualification. The domain gate consumes the result. The display adapter serves the existing renderer and held replies. No caller coordinates private validation stages. This is the smallest contract change that can distinguish a retained amount from a claim that it applies, per Laziness Protocol and Minimize Reader Load.

## Synthesis decision

Candidate A is independent. The parent chooses the base and records any synthesis. This package does not assume another candidate's shape.

## Tradeoffs accepted

- We accept a modest structured-answer expansion in exchange for source-specific accountability and useful unresolved amounts.
- We accept unresolved results for cuts, ambiguous currency, non-scalar totals, missing source reviews, and unclear conditions. No automatic second call repairs them.
- We accept explicitly labeled AI judgments for attribution and commercial meaning. Literal containment and complete mention coverage cannot prove semantic entailment.
- We retain known adverse vetoes while the normal semantic contract changes. False positives are reported separately from genuinely unresolved evidence, and no veto authorizes a positive result.

## Alternatives considered

- Extend `assessPriceContext` with Markdown, sale-copy, and additional sentence patterns. The interface stays small, but callers inherit an undocumented language grammar. This does not solve the premise failure.
- Trust the current `price.assessment` and `conditionsResolved` after quote binding. This hides too much in one Boolean and cannot account for another retained source, an omitted amount, or an unresolved purchasing condition.
- Introduce another inference call or a merchant-offer system. Both expose new lifecycle, billing, or authority decisions to callers. Neither is needed for source observations, and neither is authorized.

## Open questions and risks

Can one bounded Answer response reliably fill the complete source-review packet on ordinary commerce pages without excessive schema failures? Can the real model distinguish non-price boilerplate from a condition applying to the selected variant? These are verification questions for independent product QA, not human appearance choices. Synthetic projection tests cannot answer them. Which complete source fixtures reveal a false positive in an existing adverse veto? Each must be reproduced and adjudicated without silently removing its paired negative.

## Next implementation step

Freeze actual V4 storage schemas and binding behavior, then commit a failing ordinary-Markdown projection and real-route case beside its conditional, currency, and cut negatives.
