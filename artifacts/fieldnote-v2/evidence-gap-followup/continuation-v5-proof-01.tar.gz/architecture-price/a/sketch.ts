// Design only. No application implementation is supplied.

// Caller 1, existing SDK adapter.
export function exampleResearchCall(raw: unknown, intent: ShoppingIntent): Projection {
	return projectExaAnswer(raw, intent);
}

// Caller 2, existing server-owned recommendation gate.
export function exampleRecommendation(product: ProductV5, intent: ShoppingIntent): ProductAssessment {
	return assessProduct(product, intent);
}

// Caller 3, existing card and held-detail reply.
export function examplePriceDisplay(product: ProductV5): PriceView {
	return priceView(product.priceEvidence);
}

type Brand<T, Name extends string> = T & { readonly __brand: Name };
type SourceId = Brand<string, "SourceId">;
type ProductId = Brand<string, "ProductId">;
type EvidenceId = Brand<string, "PriceEvidenceId">;
type Currency = Brand<string, "ExplicitCurrency">;
type MinorUnits = Brand<number, "MinorUnits">;
type Variant = Brand<string, "Variant">;
type NonEmpty<T> = readonly [T, ...T[]];

type ShoppingIntent = {
	readonly intentVersion: 2;
	readonly productDescription: string;
	readonly requirements: readonly { id: string; text: string; strength: "hard" | "flexible" }[];
	readonly budget: null | { minimum?: number; maximum?: number; currency: string };
};

type Source = {
	readonly id: SourceId;
	readonly url: string;
	readonly text: string;
	readonly originalLength: number;
	readonly textTruncated: boolean;
};

/** A literal interval, bound once against retained text. It proves provenance only. */
type Passage = {
	readonly sourceId: SourceId;
	readonly start: number;
	readonly end: number;
	readonly origin:
		| { kind: "provider"; reportedQuote: string; match: "literal" | "whitespace" }
		| { kind: "source-context" };
};

type SourceJudgment = {
	readonly basis: "source-based-ai";
	readonly status: "supported" | "unknown" | "contradicted" | "conflict";
	readonly scope: "exact-variant" | "product-family" | "unclear";
	readonly rationale: string;
	readonly support: readonly Passage[];
};

/** The numeric parser recognizes monetary tokens. It does not interpret sentences. */
type ObservedMoney =
	| { kind: "explicit"; amountMinor: MinorUnits; currency: Currency; literal: Passage }
	| { kind: "ambiguous"; literal: Passage; reportedAmount: number | null; reason: string };

type PriceCondition = {
	readonly text: string;
	readonly support: NonEmpty<Passage>;
	readonly interpretation: "included-in-amount" | "shopper-eligibility" | "extra-cost" | "unknown";
	readonly rationale: string;
};

type MoneyMention = {
	readonly literal: Passage;
	readonly role: "selected-amount" | "other-product" | "reference-amount" | "extra-cost" | "unresolved";
	readonly explanation: SourceJudgment;
};

/** Exactly one review per retained source. A source review cannot attest to discarded text. */
type PriceSourceReview = {
	readonly sourceId: SourceId;
	readonly reviewComplete: boolean;
	readonly relation: "applies" | "other-product-or-topic" | "unknown";
	readonly judgment: SourceJudgment;
	readonly moneyMentions: readonly MoneyMention[];
	readonly conditions: readonly PriceCondition[];
};

type PriceBlocker =
	| "missing-literal-money"
	| "ambiguous-currency"
	| "variant-unresolved"
	| "non-scalar-basis"
	| "conditions-unresolved"
	| "conflicting-observations"
	| "source-review-missing"
	| "source-review-incomplete"
	| "unaccounted-money"
	| "source-context-incomplete"
	| "adverse-context"
	| "source-instructions";

type PriceObservation = {
	readonly id: EvidenceId;
	readonly money: ObservedMoney;
	readonly attribution: SourceJudgment;
	readonly reportedVariant: string | null;
	readonly priceBasis: {
		readonly kind: "single-item" | "range" | "bundle" | "installment" | "unknown";
		readonly assessment: SourceJudgment;
	};
	readonly reviews: readonly PriceSourceReview[];
};

/** Only the price boundary constructs this branch after all checks pass. */
type ApplicablePrice = {
	readonly state: "applicable";
	readonly observation: PriceObservation;
	readonly usableMoney: {
		readonly amountMinor: MinorUnits;
		readonly currency: Currency;
		readonly variant: Variant;
	};
	readonly authority: "source-based-ai-observation";
	readonly merchantVerified: false;
};

type PriceEvidence =
	| { readonly state: "absent"; readonly reason: string }
	| { readonly state: "observed"; readonly observation: PriceObservation; readonly blockers: NonEmpty<PriceBlocker> }
	| ApplicablePrice;

type ProductV5 = {
	readonly id: ProductId;
	readonly name: string;
	readonly variant: Variant | null;
	readonly identity: SourceJudgment;
	readonly requestMatch: SourceJudgment;
	readonly requirements: readonly { requirementId: string; assessment: SourceJudgment }[];
	readonly priceEvidence: PriceEvidence;
	readonly stock: "unverified";
};

type SnapshotV5 = {
	readonly version: 2;
	readonly evidenceVersion: 5;
	readonly intent: ShoppingIntent;
	readonly products: readonly ProductV5[];
	readonly sources: readonly Source[];
	readonly choice: null | { productId: ProductId; rationale: string };
};

type Projection = { status: "ready"; research: SnapshotV5 } | { status: "unavailable"; reason: string };
type ProductAssessment = { eligible: boolean; blockers: readonly string[] };
type PriceView = {
	readonly label: string;
	readonly qualification: string;
	readonly adverseOrUnresolved: readonly string[];
	readonly evidence: readonly Passage[];
	readonly merchantVerified: false;
};

/** Existing public entry. Private native schema, SDK envelope, and reports stay in the server. */
export function projectExaAnswer(raw: unknown, intent: ShoppingIntent): Projection {
	// TODO Parse the new private answer revision and retain sources with actual cut provenance.
	// TODO Project each native price packet through the single price boundary below.
	// TODO Apply unchanged hard-requirement gates and numeric budget bounds before ordering and choice.
	throw new Error("not implemented");
}

/** One boundary owns native price parsing, source bindings, money, review coverage, and qualification. */
function bindPriceEvidence(
	packet: unknown,
	product: Pick<ProductV5, "id" | "name" | "variant" | "identity">,
	sources: readonly Source[],
	retention: { complete: boolean; reasons: readonly string[] },
): PriceEvidence {
	// TODO Parse the private native packet. Never repair a missing report from model defaults.
	// TODO Bind actual reported money and judgment quotes to their exact returned source URLs.
	// TODO Retain complete source text by reference. Never join spans or manufacture native quotes.
	// TODO Parse a scalar denomination and amount lexically into integer minor units.
	// TODO Preserve bare-dollar and non-scalar material as ambiguous observations.
	// TODO Require one price-context review per retained source and account for every detected monetary mention.
	// TODO Keep reference amounts, other-product amounts, conditions, conflicts, and contrary reports.
	// TODO Apply the existing adverse veto corpus as disqualifying checks. It never grants applicability.
	// TODO Reject positive qualification on incomplete retention, missing reviews, unresolved scope, or conditions.
	// TODO Return applicable only for exact supported attribution, single-item money, and no unresolved findings.
	throw new Error("not implemented");
}

/** The server derives eligibility. The provider cannot supply eligible, usableMoney, or conditionsResolved. */
export function assessProduct(product: ProductV5, intent: ShoppingIntent): ProductAssessment {
	// TODO Preserve exact identity, full request match, and all current hard-requirement checks.
	// TODO When budget exists, require applicable price evidence and exact requested currency.
	// TODO Convert accepted bounds to integer minor units, then enforce minimum and maximum inclusively.
	// TODO Never change accepted intent while assessing evidence.
	throw new Error("not implemented");
}

/** Shared by current cards and held replies. It formats evidence without changing its authority. */
export function priceView(price: PriceEvidence): PriceView {
	// TODO Put an observed amount first when present, with explicit unknown currency or applicability.
	// TODO Keep adverse and conditional text ahead of supporting detail. Keep full sources in disclosure.
	throw new Error("not implemented");
}
