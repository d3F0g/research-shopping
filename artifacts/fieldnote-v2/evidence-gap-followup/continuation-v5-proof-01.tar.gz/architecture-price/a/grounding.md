# Grounding and design scope

This candidate designs a source-price correction for Fieldnote's existing chat. It contains no application edits, provider calls, runtime changes, or live product proof. The read-only application commit is `dc61d3bae93fd347495ecbb5973d7877513ec91d`.

## Architecture phases

- Ground. Complete. Read the parent grounding, current source, and tests listed below.
- Sketch. Complete. The usage, types, signatures, and boundaries are in `sketch.ts`.
- Agree. The parent owns synthesis. No human appearance checkpoint applies.
- Implement. Skipped. This assignment authorizes design only.
- Scrap. The conditions in `implementation.md` require reopening the shape if it fails its evidence contract.

## Overview

The normal operation already obtains retrieval and structured interpretation in one Exa Answer call. `projectExaAnswer` binds source support and computes the server response. The server decides eligibility and choice. The client renders retained snapshots. Price usefulness fails within the evidence projection before rendering, so another UI redesign cannot fix this defect.

## Key concepts

Observed money, its applicability to an exact variant, a user's budget, and a merchant-authorized offer are different claims. The current architecture separates the last claim but partly combines the first two. `bindPrice` invokes a monetary-sentence parser after binding a model assessment. A successful literal quote does not establish semantic applicability. A failed English sentence pattern does not establish missing evidence.

## How the current path works

`src/server/exa-research.ts:97` retains at most ten safe source URLs and 24,000 characters per source. It records original length and cuts. `bindAssessment` at line 139 binds unique literal or whitespace-equivalent quotes and downgrades positive assessments on incomplete retention. `bindPrice` at line 206 expands short source context, invokes `assessPriceContext`, falls back to a catalog row, then asks every retained source to be absent or qualified. Source text with a cut or a detected instruction currently removes all price observations.

`src/server/price-evidence.ts:138` accepts a short set of exact subject and monetary sentence shapes. `catalogPriceObservation` at line 243 recognizes a plain two-line scalar row with overlapping native price support. Neither is a general source interpretation contract. Ordinary complete Markdown is consequently distinct from a genuine ambiguous currency or variant case.

`src/domain/research.ts:36` owns exact identity, request-match, hard-requirement, currency, and both bound checks. These gates survive. `src/domain/research-history-v4.ts` owns the actual current V4 storage codec and binds evidence through `evidence-binding-v4.ts`. `workspace.ts:14` accepts V2, V3, and V4 snapshots. `turn-reducer.ts:103` currently reassesses only V4 and treats earlier versions as historical. V5 must turn V4 into a frozen historical version too.

`src/client/ResearchAnswer.tsx:88` renders prices and catalog observations in the existing card. `turn-reducer.ts:146` and line 159 duplicate the corresponding held-response formatting. A shared V5 display function removes this duplication without changing layout, controls, or design tokens.

## Candidate screen and verification

The design-red-flags screen found no shared mutable state or public wire-type exports. One price boundary hides validation and policy. Its helper stages remain private. The display adapter has two real callers. The current positive grammar and catalog fallback are removed in the same caller migration, while frozen historical validators remain required dependencies. No hand-synchronized price-condition registry is introduced.

The source review schema is the main size risk. Its exact caps and incomplete-report behavior are specified in `implementation.md`. Single-call real-model feasibility is unverified. The package received a direct content check and the TypeScript sketch produced zero diagnostics under `strict: true` with the installed TypeScript compiler. All function bodies remain intentionally unimplemented. No runtime acceptance is claimed.

The architect runner explicitly requires pseudocode and invariant comments in the sketch. This package retains those design comments. The parent owns independent review. This candidate did not spawn another reviewer or alter the application.

## Constraints verified or inherited

- Current source and tests confirm fixed scalar grammar, bounded retention, explicit currency, two budget bounds, source-linked assessments, and historical codecs.
- The parent supplied the actual private replay conclusion. It reports three relevant products and no usable money. This candidate did not read private raw payloads, diagnostic locations, credentials, grants, or ledgers.
- The synthetic `Now $437` example is not a positive acceptance case. A native citation of that bare-dollar phrase does not become a qualifying SGD price because another row contains SGD.
- The root completed the required Exa setup command this turn. This candidate read `references/answer.md` from the exact printed directory `/var/folders/w2/wt271srd07ndwbnvm1_ty8t40000gn/T/skills-use-I40oL1/build-with-exa`. It supports the existing one-call Answer approach with full cited text, an output schema, and system guidance. No new endpoint, inferred request field, or extra model is proposed.

## Principle decisions

| Read principle | Material decision |
| --- | --- |
| Fix Root Causes | Replace positive sentence-grammar authorization in the projection boundary. Keep the approved UI. |
| Model the Domain | Represent a missing price, unresolved observation, and applicable AI-observed price as different states. |
| Boundary Discipline | Keep wire parsing and evidence validation together at the provider boundary. |
| Type System Discipline | Only the applicable branch contains usable money for a budget decision. |
| Laziness Protocol | Keep the existing endpoint, cancellation, accounting, intent schema, and ordering rules. |
| Minimize Reader Load | Give cards and held replies one price display function. |
| Encode Lessons in Structure | Freeze V2 through V4 codecs and require explicit evidence-version dispatch. |
| Test Behavior, Not Implementation | Assert observed money, qualifications, choice, and retained source text through the normal route. |
| Prove It Works | Separate synthetic route checks from independent live product usefulness. |
