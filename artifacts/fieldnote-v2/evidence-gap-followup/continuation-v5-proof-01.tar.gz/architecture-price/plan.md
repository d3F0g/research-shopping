Bug fix steps.
1. Reproduce it yourself on the matching surface through the applicable Codex browser, computer-use, terminal, or project verification skill.
2. Binary-search the cause.
3. Plan the fix.
4. Verify on the same surface.
5. Stage the commits so the failing repro lands before the fix in git history.
6. Run Opening a PR.

Architecture steps.
- Ground.
- Sketch.
- Agree. Proceed autonomously, no new human appearance gate.
- Implement.
- Scrap if evidence refutes shape.

Arena steps.
- Frame.
- Fan out.
- Cross-judge.
- Pick.
- Graft.
- Verify.

Throughput checkpoint: root investigates private capture and tracks exact paid/history state; two read-only design candidates work independently, then distinct-model judge. One isolated application owner implements chosen minimal normal contract and paired cases; root reproduces red and fixed true localbrowser/SDK journey; independent QA/security review exact commit, screenshot acceptance ifUIchanges, current CI. No paid automation. Preserve four human submissions for reviewed live acceptance.
