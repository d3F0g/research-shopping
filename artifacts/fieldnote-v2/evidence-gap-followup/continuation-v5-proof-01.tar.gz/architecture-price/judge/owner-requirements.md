# Implement the revised A price boundary

Preserve the approved Fieldnote UI. Make complete ordinary source prices useful while retaining adverse evidence and honest source-based AI labels. One application owner implements this contract in its assigned isolated worktree. The root owns tracking, synthesis, merge decisions, and any authorized live proof. Other agents may be active. Do not modify or revert their work.

## Use one price operation

Keep the existing `projectExaAnswer(raw, intent)` entry. The Exa adapter parses native answer revision 2 and maps safe citation URLs to retained source IDs. It calls one pure versioned price operation for each product.

```ts
const priceEvidence = bindPriceEvidence(report, {
	product: { id, name, variant, identity },
	sources: retainedSourceSet,
});
const product = assessProduct({ ...facts, priceEvidence }, intent);
const display = priceView(product.priceEvidence);
```

Use these ownership boundaries.

| Owner | Responsibility |
| --- | --- |
| `src/server/exa-research.ts` | Private native schema, prompt, exact URL mapping, source retention, one SDK operation, and response assembly. |
| `src/domain/price-evidence-v5.ts` | Authoritative price schemas and derived types, literal bindings, money inventory, finite source alarms, source-review consistency, and the applicable state. Keep helper stages private. |
| `src/domain/research-history-v5.ts` | V5 snapshot schema. Validate price state against the retained sources using the versioned price owner. Validate eligibility and choice consistency without new semantic interpretation. |
| `src/domain/research.ts` | Current V5 export, unchanged hard-fit gates, requested-currency comparison, both budget bounds, and current ordering policy. |
| `src/domain/price-view.ts` | Shared current price text and disclosure references. No validation or research dispatch. Historical render branches consume their frozen contracts. |
| `src/domain/workspace-history-v4.ts` | Frozen actual workspace-4 contract before current imports change. |
| Current workspace, conversation, turn reducer, and card callers | Explicit V2 through V5 dispatch and the existing UI composition. |

The filename is a bounded architectural choice, not a new implementation supplied by this review. The essential requirement is one versioned owner. Do not make the V5 validator import a mutable server module or make the price module import the complete research snapshot.

## Represent money and refusal separately

Derive production types from the authoritative schemas. The following signatures describe the required concepts. They are not application implementation.

```ts
type SourceRef = Readonly<{
	sourceId: SourceId;
	start: number;
	end: number;
}>;

type MoneyOccurrence = Readonly<{
	id: MoneyOccurrenceId;
	literal: SourceRef;
	value:
		| { kind: "explicit"; minorUnits: SafeMinorUnits; currency: ExplicitCurrency }
		| { kind: "ambiguous"; reason: MoneyBlocker };
	amountSpan: SourceRef;
	currencySpan: SourceRef | null;
}>;

type PriceAlarm = Readonly<{
	policy: "price-safety-v1";
	kind:
		| "buyer-restriction"
		| "incomplete-total"
		| "conditional-applicability"
		| "purchase-basis"
		| "variant-contradiction"
		| "competing-amount"
		| "source-instruction";
	support: SourceRef;
}>;

type ReviewedOccurrence = Readonly<{
	occurrenceId: MoneyOccurrenceId;
	role: "selected" | "other-product" | "reference" | "extra-cost" | "unresolved";
	assessment: SourceBasedAiAssessment;
}>;

type PriceEvidence =
	| { state: "absent"; reason: PriceBlocker; alarms: readonly PriceAlarm[] }
	| {
		state: "observed";
		observations: readonly MoneyOccurrence[];
		reviews: readonly BoundSourcePriceReview[];
		alarms: readonly PriceAlarm[];
		blockers: NonEmpty<PriceBlocker>;
	}
	| {
		state: "applicable";
		observations: readonly MoneyOccurrence[];
		reviews: readonly BoundSourcePriceReview[];
		selectedOccurrenceId: MoneyOccurrenceId;
		usableMoney: BoundExplicitMoney;
		variant: string;
		basis: "source-based-ai-observation";
		merchantVerified: false;
	};

declare function bindPriceEvidence(
	report: ParsedPriceReport,
	context: Readonly<{ product: ProductTarget; sources: RetainedSourceSet }>,
): PriceEvidence;
```

Native output supplies quoted observations and semantic judgments. It cannot supply money occurrence IDs, source offsets, alarms, applicable state, or usable money. The server derives those values. An alarm's source-context origin must stay distinct from an actual provider quotation.

Store text once in retained sources. Bind unique literal or whitespace-equivalent spans without punctuation repair or joining gaps. Bind the exact amount and explicit denomination to the selected occurrence inside its actual native money witness. A quote containing several unmatched candidate amounts remains ambiguous. Do not infer currency from a different row, a seller, a hostname, or the budget.

Convert accepted decimal money and both budget bounds to checked integer hundredths without rounding. Preserve the current positive, finite, at-most-two-decimal money contract and its maximum. Do not claim the current contract supports arbitrary ISO minor-unit precision. Preserve both bounds and compare the exact requested currency.

## Enforce finite source alarms independently

Separate the old negative safety behavior from the old positive price grammar. Add one private `price-safety-v1` scan over complete retained source text. Its only output is source-linked refusal evidence. Absence of an alarm is never proof of applicability.

Do not call `assessPriceContext` and treat `absent` or `qualified` as V5 authorization. Do not require all ordinary text to fit recognized sentences. Do not create a growing category, variant, or English commerce registry.

Preserve these known adverse families through explicit source alarms and deterministic money consistency.

| Required family | Existing or candidate examples that must block an optimistic report |
| --- | --- |
| Buyer restriction | Membership required. Only available with membership. The displayed price applies only to members. A membership voucher is needed. This amount is available only after joining the annual club. |
| Incomplete total | Not tax included. Without tax included. Tax is excluded from the displayed amount. Excludes GST. The price above excludes tax. Delivery charged separately at checkout. |
| Conditional applicability | Tax included unless a voucher is unavailable. The displayed price changes unless the buyer lives overseas. |
| Purchase basis | Minimum purchase of three units. For three units. A box of three watches for a one-watch request. Per-month installments. An adjacent monetary range rather than a scalar. |
| Variant contradiction | For AX2. For AX2 only. Price applies to AX2 only. AX2 variant only. A price row that explicitly names a different variant. |
| Competing amount | Two current amounts asserted for the same exact selected subject. The selected amount instead follows another explicit subject in the same known assertion. An omitted extra shipping amount. |

Implement bounded alarms for these recognized forms. Parameterize selected names, arbitrary variant strings, and money instead of hardcoding fixture identities or amounts. Use literal or lexical matching for money and exact-subject contradictions. Any parsing uncertainty in a recognized alarm remains a refusal. A recognized positive price assertion may help detect a contradiction. It must never be required to admit an otherwise supported ordinary source.

The alarms are a finite compatibility floor. They are not an interpreter and cannot authorize a price. New paraphrases do not automatically justify another regex. If implementation needs a second expanding semantic grammar, stop and reopen the design with the failing source pair.

Never clear an alarm because native output says `supported`, `included`, `other-product`, or `reviewComplete`. Preserve each alarm as source-context evidence ahead of positive detail. A source-wide alarm can conservatively block a candidate even if the model calls the source unrelated. Record that false-positive limitation honestly. A plain unrelated source amount without an alarm can remain usable through the source-review path. This retains safety without claiming the model can prove its own exemption.

Keep paired positive cases that contain `tax included` and `No membership or voucher is required`. A bare keyword alarm must not reject those cases. Keep arbitrary variant positive cases, ordinary Markdown, ordinary prose, complete sources over 4,000 characters, and three uniquely scoped products. These assertions prevent the finite refusal policy from turning back into a positive English grammar.

## Reject favorable reports for known adverse sources

Move existing semantic assertions to the actual current V5 wire schema. For each negative source, supply a second native packet with all positive statuses, empty conditions, and complete-review claims. Where applicable, mislabel a competing amount as a reference or other product. The source-derived refusal must survive those claims.

Assert these outcomes through `projectExaAnswer` and the actual local research route.

1. Choice is null and the product is ineligible for the accepted budget.
2. A surviving literal amount remains an observed, unverified amount with its blocker.
3. Every adverse passage remains accessible in the stored source and existing evidence detail.
4. Accepted requirements, currency, minimum, and maximum remain unchanged.
5. A supplied favorable summary cannot erase the computed blocker.

Do not convert these tests into truthful native reports and claim the model passed. Truthful and optimistic reports are different checks. Novel semantic misreads remain independently evaluated, but known negative assertions remain deterministic acceptance gates.

## Preserve source completeness and bounded fit

Use the existing one Exa Answer operation with `text: true`, the actual generated Draft 7 schema, and the current abort signal and deadline. No repair call or hidden retry is permitted. Give the native answer an explicit revision 2. Keep evidence V5, workspace 5, response envelope 2, and intent version 2 distinct.

Require one review for every retained safe URL. Record unknown, absent, invalid, and incomplete reports explicitly. A model claim that it reviewed the full source cannot replace server coverage checks. Keep each monetary occurrence and its role, including bare-dollar occurrences. A quantity number alone is not a monetary occurrence. Terms and quotations remain independently bound.

Keep A's initial bounds of three products, ten sources, twenty-four money records per product, and eight conditions per product. Enforce aggregate bounds in the adapter in addition to representable Draft 7 constraints. A truthful or detected overflow becomes unresolved or invalid. Do not raise caps without evidence or slice away adverse records. If native omission of a nonmoney condition cannot be detected outside the finite alarm corpus, label that remaining semantic limit honestly.

A cut, discarded source, conflicting canonical URL, unbound support, or unresolved relevant scope prevents the applicable state. An intact literal amount may survive as observed with prominent uncertainty. Preserve actual original length and cut metadata. A model's full quotation cannot repair discarded source text.

Validate actual serialized answers and workspaces against the existing 128,000-character answer limit and 256 KiB workspace limit. Include object and string answer forms, multibyte source text, and shared sources. Preserve whole-turn eviction or explicit failure. Do not trim evidence to fit.

## Freeze history and validate current persisted state

Copy the actual V4 workspace decoder before changing current exports. Use explicit historical V2, V3, and V4 imports in every renderable and stored union. Preserve historical intent, questions, requests, results, quotations, conditions, choice, and original source-context provenance. Migrate active preferences only. Retain the existing interruption rule for pending work and prevent historical paid actions.

Validate V5 persisted price state against its sources with the same versioned deterministic policy used for new projection. Reject a forged applicable tag, removed alarm, changed amount or currency, stale occurrence ID, altered span, missing review, hidden cut, or inconsistent choice. Recompute deterministic consistency only. Do not generate new AI assessments on load.

Keep frozen V4 binding semantics unchanged. V5 must not import a current helper that later changes historical interpretation. Round-trip actual composed V2, V3, and V4 records with deep equality of historical messages before and after migration and refresh.

## Complete the authorized verification

First add failing ordinary positive and optimistic-adverse V5 cases. Implement the contract and migrate all current callers in one wave. Remove the current positive grammar and catalog fallback after their current callers are gone. Keep genuine historical dependencies.

Run targeted boundary, domain, and history tests, then required package checks. Exercise the real Exa SDK with a local HTTP substitute and fake credentials. Inspect the actual transmitted Draft 7 schema, one dispatch, cancellation, error handling, and complete intent. These local checks do not prove provider-side schema support or semantic accuracy.

Use the repository verification skill for real browser journeys and desktop and mobile screenshots. Preserve the approved card layout, first-visit dark mode, theme persistence, ordinary messages, compact composer, disclosures, free follow-ups, cancellation, history isolation, and session isolation. Independent QA and security review the exact final candidate. Only the root coordinates any separately authorized live source-to-recommendation proof. No new allowance or human design checkpoint is introduced by this contract.
