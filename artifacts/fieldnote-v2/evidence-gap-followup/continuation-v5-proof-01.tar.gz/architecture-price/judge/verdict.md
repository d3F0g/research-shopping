# Price architecture cross-judge

Fieldnote needs useful source prices and recommendations in its approved chat UI. Candidate A is the better synthesis base. Neither frozen package is ready to hand to an implementer unchanged. Candidate B fails the known adverse-evidence gate. Candidate A needs the bounded admission contract in [Owner requirements](owner-requirements.md).

This is a design verdict. No application behavior, model accuracy, browser result, or merge readiness was verified.

## Scope and evidence

I read every requested file in both completed packages. I inspected the current price projection, price parser, eligibility function, V4 binding and storage schemas, workspace bounds, and the three named API suites. The checkout returned `dc61d3bae93fd347495ecbb5973d7877513ec91d` from `git rev-parse HEAD`.

The current source still exports evidence V4. V5 is the proposed new current contract. V4 must become explicitly historical when V5 becomes current. See [current exports](/Users/josiahwong/Documents/research-shopping-v2/src/domain/research.ts:1), [workspace schema](/Users/josiahwong/Documents/research-shopping-v2/src/domain/workspace.ts:14), and [renderable union](/Users/josiahwong/Documents/research-shopping-v2/src/domain/conversation.ts:6).

The parent supplied the private replay conclusion. I did not inspect private payloads, credentials, grants, ledgers, or memories. I made no provider or GitHub calls and changed no application or candidate files. The configured Astra judge ran, but this turn exposes no model-family introspection. I did not freshly verify the family check.

## Criterion scores

Scores assess the designs and their specified contracts. They do not count proposed tests as passing evidence.

| Rubric criterion | A | B | Evidence and judgment |
| --- | --- | --- | --- |
| Ordinary source price and variant attribution without a positive sentence grammar | 4 | 4 | Both replace the restrictive grammar with source-based interpretation, preserve unknown applicability, and allow varied Markdown. A's packet has one selected observation. B more clearly models competing observations. Neither supplies a working projector or real-model result. |
| Explicit currency, both bounds, adverse conditions, conflict, cuts, and provenance | 3 | 1 | A makes retained adverse vetoes mandatory in `implementation.md` lines 43 and 52. The current parser has no independent veto API that can just be retained. B explicitly permits an omitted nonmoney condition to escape local validation in `acceptance.md` lines 30 to 32. Both preserve numerical and cut requirements on paper. |
| AI interpretation, deterministic checks, and merchant authority remain distinct | 4 | 4 | Both label semantic judgments as AI interpretations and retain unverified merchant status. A's applicable union makes accidental use of unresolved money harder. B correctly describes token coverage as insufficient, but that honesty does not excuse the safety regression. |
| Frozen history and bounded one-call Exa compatibility | 3 | 3 | Both propose independent native revision 2, evidence V5, and workspace 5 with explicit V4 freezing. The existing SDK supports the requested fields. Neither supplies the actual revised Draft 7 schema or measures its serialized answer and workspace sizes. |
| Coherent ownership, API depth, migration, and unchanged UI | 3 | 4 | A's one projection boundary is small but leaves the server binder and V5 stored validator liable to duplicate policy. B names a pure domain owner and explains the import-cycle solution. B's observation records also preserve competing money more directly. Both keep the existing UI and require independent visual verification. |
| Total | 17 | 16 | A wins as the base after mandatory revisions. The total does not override disqualification. |

## Disqualifying issue in B

B's `acceptance.md` requires an optimistic report for each adverse source, then says a report omitting a nonmonetary condition can pass token coverage. Its qualification function accepts complete reviews with no remaining relevant terms. Consequently, a source with a known voucher or tax exclusion can qualify when the report marks the source reviewed and returns no term. Keeping the original paragraph in a disclosure does not repair the incorrect choice.

This violates the requirement that known contradictions cannot disappear from eligibility. The defect is in the admission contract, not merely a missing future model evaluation. B's statement that the event is an AI semantic failure is honest but insufficient. B is disqualified as submitted. Its model-limit discussion should survive in the synthesis, paired with an enforceable refusal path.

## Required repair in A

A requires existing adverse checks, but many current negatives are rejected by failure to match the positive grammar. `assessPriceContext` returns `unbound` for an unrecognized monetary clause and for mismatched assertions. Removing the grammar removes those refusals too. See [the current parser](/Users/josiahwong/Documents/research-shopping-v2/src/server/price-evidence.ts:138) and [existing adverse inputs](/Users/josiahwong/Documents/research-shopping-v2/tests/api/v2-price-boundary.test.ts:34).

There is no reusable complete set of independent price vetoes today. The separate assessment guard covers a smaller set of negative product phrases. It does not enforce all known voucher, tax, quantity, and variant assertions. See [assessment binding](/Users/josiahwong/Documents/research-shopping-v2/src/server/exa-research.ts:139).

The synthesis must define a versioned, finite source-alarm policy and retain its findings independently of native reports. Those alarms only block applicability. They never establish a price, currency, or fit. New ordinary prose does not have to match a known positive phrase. An AI label cannot clear an alarm. Every migrated known adverse case must reject a favorable supplied report through the actual V5 projector. The exact required families and stop condition are in the owner requirements.

The unresolved general limit remains explicit. No finite source scanner or structured schema proves arbitrary commercial semantics. Once deterministic alarms and coverage pass, exact attribution and scope remain labeled AI judgments. A newly observed harmful misinterpretation stays a product blocker. It must not be waived because it is outside the finite corpus.

## Two coherent grafts from B

1. Put the versioned price schema, pure source binding, deterministic admission rules, and stored-price validation under one domain owner. Keep Exa's wire schema private in the adapter. This prevents the server from accepting one price while history accepts a different forged state. Use A's absent, observed, and applicable union as the result.
2. Give every retained money occurrence its own identity, literal amount and denomination spans, and AI role. The selected observation references one occurrence. This preserves competing or superseded amounts without burying their values in rationales. Bound source text stays in the source record. This is B's useful observation model adapted to A's result shape.

Do not graft B's permission to classify omitted known restrictions as an acceptable semantic risk. Do not add another inference service, research call, merchant API, or positive sentence parser. Do not add a UI checkpoint.

## Actual Exa and storage feasibility

The canonical Answer reference supplied by the parent's setup run documents `text`, `outputSchema`, and `systemPrompt`. The installed SDK declares these fields and sends them through one `/answer` operation. The current application explicitly generates Draft 7. See [request construction](/Users/josiahwong/Documents/research-shopping-v2/src/server/exa-research.ts:489) and [SDK implementation](/Users/josiahwong/Documents/research-shopping-v2/node_modules/exa-js/dist/index.mjs:4066).

The proposed ordinary objects, arrays, enums, and nullable values are representable in that request. This establishes request-shape plausibility only. The provided documentation recommends small explicit schemas. It does not guarantee that Exa will enumerate all returned citation text, satisfy the larger per-source reviews, or stay within Fieldnote's bounds. Neither candidate supplies an executable revised schema, so stronger compatibility claims are unwarranted.

Two current limits matter. String answers over 128,000 characters are rejected at [answer parsing](/Users/josiahwong/Documents/research-shopping-v2/src/server/exa-research.ts:309). A workspace has 256 KiB with a 1 KiB reserve at [workspace bounding](/Users/josiahwong/Documents/research-shopping-v2/src/domain/workspace.ts:9). Ten sources can already retain 240,000 characters before JSON encoding or review metadata. Both proposals can exceed these limits through repeated 4,000-character quotations. A record-count cap alone does not prove fit.

Keep the existing limits and honest whole-response or whole-turn failure behavior. Store source text once and use offsets in the domain. Test exact serialization with three products, shared and distinct sources, multibyte text, long quotations, and every cap. Never trim an adverse record to preserve applicability. Native review completeness remains a claim, while source and record coverage are server checks.

The old V4 paragraph binder rejects a context over 4,000 characters. Do not change that frozen helper or accidentally retain it as V5's whole-source price rule. V5 can bind a short literal quote into a complete retained source by offsets. It must keep source completeness and any display-context cut explicit. See [V4 context binding](/Users/josiahwong/Documents/research-shopping-v2/src/domain/evidence-binding-v4.ts:35).

## Architectural red flags

A has a split-policy risk between its server-only binder and the independently validating history schema. B provides the better ownership correction. B's reported DTO is acceptable only as a parsed domain claim, not a re-export of Exa's transport object. The authoritative semantic enums and money types must have one owner.

Neither result should maintain `price` and `priceEvidence` as current competing paths. Retire the current catalog fallback in the same migration. Historical V4 remains a genuine read-only codec, not a producer available to the current projector. Full source records and offset references avoid manually synchronized copies of context text.

## Principles that changed the decision

| Principle read in this turn | Material choice |
| --- | --- |
| Model the Domain | Keep A's state union and add identified money occurrences and source alarms. A raw amount cannot double as applicable money. |
| Boundary Discipline | Put native parsing in the Exa adapter and deterministic source admission in one pure versioned domain owner. |
| Type System Discipline | Derive price types from the V5 schema and prohibit a native `applicable` or `usableMoney` field. Stored tags require recomputed consistency. |
| Laziness Protocol | Select A and two bounded grafts. Preserve the endpoint, UI, intent reducer, accounting, and one-call lifecycle. |
| Redesign From First Principles | Treat known adverse refusal as part of the replacement contract, rather than bolt the old positive parser back on after failures. |
| Prove It Works | Require actual V5 adversarial projection and route evidence. Do not treat throw-only sketches, long acceptance lists, or static compilation as behavior proof. |

## Handoff verdict

Use A only after incorporating the owner requirements into the synthesized design. Reject B as the base. If the owner cannot preserve the named adverse assertions without expanding a positive sentence grammar or cannot fit the packet within one call, stop and return that exact failed contract to the root. This is a concrete redesign condition, not permission to weaken the assertions.
