# Review evidence manifest

Application HEAD was verified as dc61d3bae93fd347495ecbb5973d7877513ec91d.
All listed candidate and grounding files were read end to end. SHA-256 values identify the files reviewed.

| Path | Lines | SHA-256 |
| --- | --- | --- |
| `grounding.md` | 17 | `d82741213abe9f236c4662c0421f9cae18c3823f28492b557de967f3cc0171e6` |
| `rubric.md` | 1 | `d6ac9884fa80f5680f59ee2cff460f525e08cbcb690b8a42a2301d9cba55d41c` |
| `a/rationale.md` | 44 | `f643a6b41a8cc1a519fa2c3bbbad3ae43c37f3cb0b7786b0b860b0a611e1cc7d` |
| `a/sketch.ts` | 204 | `1b82c66e1627136c7b98fc180dc79fb5d3b86a2b53a6a998c1d697fa476f9ee8` |
| `a/implementation.md` | 100 | `6c26eacf90629958f0d00d7173e6660f3bf7cc575eda0558a8c1ff8826846c51` |
| `a/cases.md` | 90 | `75a21b1384deadef19910ebe13d69b6f22ff34f183892ce1a25b127fbf70dc54` |
| `a/grounding.md` | 58 | `f1ab231c56e243ebe238c4ed2bce873f0342a12e3eb586150a51cee214b9929f` |
| `b/rationale.md` | 48 | `e5c05d386cb58df82c6daa5c3d934807f87d721b1f1b3079aadc6ba78ff41d34` |
| `b/sketch.ts` | 220 | `0c02f8f2895940d8cb995e771f5d5ab1d47dcfb542f22b8ffaffe257d75a0e0f` |
| `b/scope-and-evidence.md` | 59 | `c719cd30a2d52698083ac9ca764d023ddf1ef99fb670905c99ed98f81dcfcf65` |
| `b/acceptance.md` | 52 | `9bbbe8dd5bf54690f9ccaf35f968874d5a7db272f5f4b58aa1ee86612a557129` |
| `b/verification.md` | 13 | `ada109e0d522a7891258a74ba338e8b48e0f2a0dc6be4b9bc3f26b676330f81e` |

No provider call, GitHub mutation, private-file read, application edit, browser run, or application test was performed.
The comparison is a design review and source inspection. Proposed acceptance cases are not passing implementation evidence.
The model-family check was not exposed or freshly verified in this judge turn.
