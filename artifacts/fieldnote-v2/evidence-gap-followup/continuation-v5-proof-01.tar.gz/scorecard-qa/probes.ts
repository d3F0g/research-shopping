import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import { hash, materialPayloadHash } from "../../../evals/hash";
import { currentScenarioMaterial } from "../../../evals/v2/materials";
import { caseResult, validateReport } from "../../../evals/v2/report";
import { summarize } from "../../../evals/frozen-v4/report";
import { crossContractScorecard } from "../../../evals/v2/scorecard";

const directory = "artifacts/playwright-results/scorecard-qa";
const candidate = JSON.parse(await readFile(`${directory}/current60/report.json`, "utf8"));
const baseline = JSON.parse(await readFile("artifacts/product-evals/baseline-v1/report.json", "utf8"));
validateReport(candidate);
const scorecard = await crossContractScorecard(baseline, candidate);
const different = ["FN-CU-001", "FN-RT-002", "FN-PQ-001"];
assert.deepEqual(scorecard.differentHistoricalMaterial, different);
assert.equal(scorecard.unchangedInputs, 57);
assert.equal(scorecard.acceptance, "inconclusive");
assert.deepEqual(scorecard.candidate.summary, candidate.summary);
assert.deepEqual(scorecard.baseline.summary, baseline.summary);
const paired = scorecard.rows.filter(row => !different.includes(row.id));
assert.equal(paired.length, 57);
for (const row of scorecard.rows) {
  assert.equal(row.comparableNormativeInputs, !different.includes(row.id));
  assert.equal(row.material.equal, !different.includes(row.id));
  const current = candidate.cases.find((entry: any) => entry.id === row.id);
  assert.equal(current.materialHash, hash(currentScenarioMaterial(current.contract.provider, row.id)));
  assert.equal(hash(current.material), hash(currentScenarioMaterial(current.contract.provider, row.id)));
  assert.equal(current.material.sha256, materialPayloadHash(current.material));
  assert.equal(hash(current.observation.material), hash(current.material));
}
for (const entries of Object.values(scorecard.requirementTransitions)) {
  assert(entries.every(row => !different.includes(row.scenarioId)));
}
const jointlyAssessed = paired.flatMap(row => row.sharedNormativeRequirements).filter(row => ["pass", "fail"].includes(row.before) && ["pass", "fail"].includes(row.after));
assert.equal(scorecard.pairedAssessed.denominator, jointlyAssessed.length);
assert.equal(scorecard.pairedAssessed.beforePassed, jointlyAssessed.filter(row => row.before === "pass").length);
assert.equal(scorecard.pairedAssessed.afterPassed, jointlyAssessed.filter(row => row.after === "pass").length);
const mutations: Array<[string, (material: any) => void]> = [
  ["id", material => material.id += "-forged"],
  ["kind", material => material.kind = "forged"],
  ["label", material => material.label += " forged"],
  ["capturedAt", material => material.capturedAt = "2026-11-20T00:00:00.000Z"],
  ["provenance-only", material => material.provenance.push("Fixture independent forged provenance")],
  ["body-only", material => material.body = { ...material.body, requestId: "fixture-independent-forged" }],
  ["status", material => material.status = 201],
  ["extra-field", material => material.forgedMetadata = "Fixture independent forged metadata"],
];
const probes: any[] = [];
for (const id of [...different, "FN-CU-002"]) {
  for (const [name, mutate] of mutations) {
    const forged = structuredClone(candidate);
    const index = forged.cases.findIndex((row: any) => row.id === id);
    const row = forged.cases[index];
    mutate(row.material);
    row.material.sha256 = materialPayloadHash(row.material);
    row.observation.material = structuredClone(row.material);
    forged.cases[index] = caseResult(row.contract, row.material, row.observation);
    forged.summary = summarize(forged.cases);
    validateReport(forged);
    let rejection = "";
    try { await crossContractScorecard(baseline, forged); } catch (error) { rejection = String(error); }
    assert.match(rejection, new RegExp(`Changed V2 research material for ${id}`));
    probes.push({ id, mutation: name, genericValidatorAccepted: true, authorityRejected: true, rejection });
  }
}
assert(candidate.cases.every((row: any) => row.observation.cleanup && row.observation.network.externalRequests === 0 && row.observation.network.denied.length === 0));
const output = { candidateSummary: candidate.summary, differentHistoricalMaterial: different, unchangedInputs: 57, pairedAssessed: scorecard.pairedAssessed, transitionCounts: Object.fromEntries(Object.entries(scorecard.requirementTransitions).map(([key, rows]) => [key, rows.length])), authorizedMaterialChecks: 60, fullySelfConsistentMutationProbes: probes, acceptance: scorecard.acceptance };
await writeFile(`${directory}/probes.json`, JSON.stringify(output, null, 2));
console.log(JSON.stringify({ authorizedMaterialChecks: 60, rejectedSelfConsistentForgeries: probes.length, pairedAssessed: scorecard.pairedAssessed, acceptance: scorecard.acceptance }));
