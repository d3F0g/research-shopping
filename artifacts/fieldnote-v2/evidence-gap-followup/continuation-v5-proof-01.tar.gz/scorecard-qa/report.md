# Independent scorecard QA

The user needs useful shopping prices and an honest fixed-scenario evaluation. This review approves the narrow evaluator correction. It does not establish live shopping usefulness.

Reviewed base a45cac153f9bdafab9c9d7c2972f0889ef854799 and head 842c394c8477dd7d23a9a2dddf16f65dc9c00576 in detached /tmp/fieldnote-scorecard-qa. The only changed files are evals/v2/scorecard.ts and evals/v2/tests/integrity.test.ts. The reviewer authored neither change. Verdict PASS within this scope. No blocking finding.

## Reproduction and verification

The real pre-fix CLI at 280b43404e1a6974debc0a8909059bbb105b00ba exits 1 with Changed V2 research material for FN-CU-001 against this review's fresh sixty-case report. The exact same report succeeds through the real npm run eval:scorecard command at the reviewed head. See red-scorecard.log and scorecard.log.

The independent current60 run executes all 60 cases and 140 turns. It records 11 passed, 0 failed, 48 blocked, 1 unsupported, 0 critical failures and 0 infrastructure errors. Acceptance remains inconclusive. All observations record cleanup, zero denied destinations and zero external requests under the local fetch guard. The adapter uses actual exa-js against dynamically bound owned IPv4 loopback HTTP servers. No live Exa call or paid operation was made.

The scorecard lists exactly FN-CU-001, FN-RT-002 and FN-PQ-001 as different historical material. These are separately labeled current V5 synthetic fixtures. All 57 other rows are comparable. Every transition list and the paired-assessed denominator excludes those three changed rows. The paired denominator is 203, with 151 historical passes and 203 current passes. This remains descriptive across distinct application and evaluator contracts. It is not a causal improvement, NLU or usefulness score. Both report summaries are preserved exactly, and scorecard acceptance remains inconclusive.

The independent probes verify all 60 authorized entire material objects, payload hashes and matched observation metadata. Across all three changed scenarios and the unassigned FN-CU-002, eight mutations each change id, kind, label, capturedAt, provenance only, payload only, status or an extra field. Each mutation refreshes the payload hash, observation material, complete case result and summary. All 32 forged reports pass the generic report validator and fail the scorecard's canonical-material authentication at their exact scenario. See probes.ts, probes.json and probes.log.

npm run eval:test passes 40 tests with no failures, skips or cancellations. Its added integration test executes the actual sixty-case runner and scorecard CLI, checks complete runtime coverage, preserves both summaries, asserts exact changed-material membership and exclusion from all paired transitions, and demonstrates generic-validator-accepted forgeries cannot cross the scorecard boundary. The expected changed fixture identifiers are explicit. No expectation is relaxed or assertion replaced. npm run eval:typecheck passes. npm run eval:preservation verifies 389 unchanged committed assets. git diff --check passes.

## Scope, cleanup and limits

The two-line production correction switches the material authority from original scenarioMaterial to currentScenarioMaterial, the same existing composition owner used by the current runner. Hashing the entire expected object still authenticates label, provenance, status and payload. Existing sameMaterial comparison and paired exclusion logic are unchanged. No new registry, unsupported guard, version bypass, compatibility branch or hidden acceptance weakening was added.

The focused no-comments and workaround review found no added narrating comments, suppression directives, dead guards, workarounds or unrelated edits. Deletions 0, restorations 0, cleanup reruns 0, MUST KILL flags 0, architecture or encoding changes 0, open cleanup constraints 0. This reviewer performed the focused pass as assigned by root without another agent.

src, tests, scripts, .agents, .github, package configuration and present application config blobs match the base. source-binding.json records exact tree and blob identities. Both review checkouts have no tracked modifications. No application, test, evaluator, documentation or skill file was edited by this reviewer. All new proof is ignored under artifacts/playwright-results/scorecard-qa.

Dependencies were copied without .cache, .vite or .vite-temp. No dependency installation was performed. Every evaluator command ran under env -i with only PATH, HOME, LC_ALL=C, NODE_ENV=test and EXA_RESEARCH_ENABLED=false. No private environment, captures, diagnostics, persistent ledger, grants, preview host, GitHub mutation or paid call was used. commands.json records exact commands, exits and the single reviewer discovery failure. That rg probe named a nonexistent evals/v2/network.ts. The correct evals/network.ts was inspected afterward. It was a reviewer command error and no application result was discarded.

This is one independent deterministic sixty-case trial plus a separate suite run that repeats the sixty-case CLI regression. No statistical model comparison is claimed. Product counts are bounded by the frozen scenarios and current fixture suitability. Blocked and unsupported cases remain unassessed. Browser and live product acceptance were not rerun because application, UI, adapter, assertions, scripts, configuration and verification skill were byte-identical for this evaluator-only delta. This review establishes the scorecard CLI correction, not a new browser or live merchant result. CI, platform protections, final rebased source binding and merging remain root responsibilities.

## Principles that changed decisions

Prove It Works required fresh actual sixty-case CLI output and a pre-fix CLI reproduction instead of accepting the owner's summary.

Test Behavior, Not Implementation required independent self-consistent forged reports that pass generic validation before exercising the public scorecard boundary, plus changed-material exclusion from user-visible comparison results.

Explain the Number required preserving inconclusive acceptance and all blocked and unsupported cases. It also limited the 203 paired assessments to unchanged material and labeled the comparison descriptive rather than a shopping usefulness improvement.
