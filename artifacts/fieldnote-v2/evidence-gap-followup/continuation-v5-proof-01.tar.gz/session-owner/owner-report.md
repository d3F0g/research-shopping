# Session transport owner report

Preserve Fieldnote's approved UI and genuine guest history by cancelling obsolete bootstrap transport before it can replace the browser cookie.

Base is `dc61d3bae93fd347495ecbb5973d7877513ec91d`. Branch is `fix/issue-65-bootstrap-transport`. The failing regression commit is `fa335ea292d84ff0fb408d2f3e7e8fde00c1b974`. The fix commit is `2ae29416925765f0aa8089e82266570c73544fc3`.

## Change

Only `src/client/useFieldnote.ts` and `src/client/api.ts` changed in production. One private AbortController owns each account-to-session bootstrap. Replacement reload, accepted send, interruption and cleanup abort that owner. Both existing counters retain their meanings. Every await and catch retains publication checks, and finally clears only its own controller. The research snapshot uses its existing research signal. There is no queue, shared promise, server policy, cookie manipulation, retry, component, dependency or UI change.

The old browser cases assumed two uncancelled initial bootstraps. They now establish a real guest cookie, then use a test-only real-hook fixture for overlapping reload and authentication callbacks. The actual UI's account loading controls remain unchanged. Native tests separately exercise cookie effects without route fulfillment, cache changes or request-header overrides.

## Red and native proof

The red test ran before the production fix. The server did not observe cancellation after replacement reload.

```text
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 6000ms exceeded while waiting on the predicate
```

`red/native-headers-cancellation-preserves-cookie-ownership-and-complete-history.json` records release with `aborted: false` and two different issued cookie hashes. `baseline-root-native-proof.json` is an unchanged copy of root's earlier complete native cookie-switch/history-loss proof. That complete old-hook experiment is attributed to root, not rerun or reclassified by this owner.

The fixed committed run reports the following.

```text
5 passed (9.0s)
```

`native-summary.json`, `native-headers-history.json` and `native-body-history.json` retain the event and history evidence. Before-header cancellation records an actually dispatched request and one server abort. Releasing its created response does not install its cookie. The replacement identity retains hello and its assistant reply, then thanks and its assistant reply in exact order and with identical message IDs after browser reload. The draft survives before follow-up.

The body-held pair records accepted headers, the same installed cookie on replacement, one abort and body cancellation. Late body release cannot replace history. The actual StrictMode UI creates one initial guest identity and retains both turns. An independent browser context has a different identity and empty history. Two further native cases show that an ordinary free reply does not abort the active research refresh, while Stop and New chat cancel its held body and prevent late publication.

## Verification

Commands ran from this worktree using an allowlisted environment. Its common prefix was `env -i PATH=/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin EXA_RESEARCH_ENABLED=false`. Browser commands also set `PLAYWRIGHT_BROWSERS_PATH=/Users/josiahwong/Library/Caches/ms-playwright`. PostgreSQL commands set `LC_ALL=C`. Browser E2E used `PLAYWRIGHT_API_PORT=3398 PLAYWRIGHT_WEB_PORT=5498`.

| Command after the environment prefix | Result | Evidence |
| --- | --- | --- |
| `node node_modules/@playwright/test/cli.js test tests/e2e/session-ownership.spec.ts --grep 'native headers' --reporter=list` before fix | Failed for missing native abort | `red/` |
| `node node_modules/@playwright/test/cli.js test --reporter=list` | Existing 24 cases plus initial three native cases passed, 27 total | `e2e.log` |
| `node node_modules/@playwright/test/cli.js test tests/e2e/session-ownership.spec.ts --reporter=list` at fix commit | Five native cases passed | `native-committed.log` |
| `node node_modules/vitest/vitest.mjs run` at fix commit | 474 tests passed across 15 files, including 18 hook cases | `unit-api-final.log` |
| `npm run build` at fix commit | Typecheck and Vite build | `build-committed.log` |
| `node scripts/test-postgres.mjs` | 28 PostgreSQL tests passed | `postgres.log` |
| `node scripts/verify-personalization-browser.mjs` | Desktop and mobile account matrix passed | `accounts-browser-locale-c.log`, `generated/fieldnote-v2/accounts/` |
| `node tests/helpers/session-account-recovery.mjs` | Actual UI authentication with current account-read failure, explicit recovery, no guest upload, sign-out and exact guest history passed on desktop and mobile | `account-recovery.json` |
| `node scripts/verify-personalization-restart.mjs` | Restart persistence passed | `accounts-restart.log` |
| `node scripts/verify-personalization-crash.mjs` | Crash, duplicate replay, reservation and recovery passed | `accounts-crash.log` |
| `node --import tsx scripts/verify-evidence-history.ts` | Desktop/mobile historical response and restart checks passed | `evidence-history.log`, `generated/fieldnote-v4/history-browser/` |
| `node .agents/skills/verify-research-shopping/scripts/smoke.mjs` at fix commit | Three viewport journeys passed, cleanup true and empty source state before/after | `verification-skill/proof.json` |

The verification skill used `VERIFY_API_PORT=3398 VERIFY_WEB_PORT=5498 VERIFY_ARTIFACT_DIR=artifacts/issue-65-bootstrap-transport/verification-skill`.

The first PostgreSQL launch failed before app startup because the empty environment omitted a locale. Its log explicitly requested LC_ALL. Setting LC_ALL=C fixed the owned test runtime. The failed owned cluster was stopped and removed after its log was retained as `pg-locale-failure.log`.

The first skill run completed its viewport journeys but failed the source-stability assertion because I edited formatting and the test fixture during the run. That run remains under `verification-skill-source-changed/` and is not counted as passing. The frozen-head replacement run passes every gate.

The same-event reload/send unit case preserves existing unready state until explicit reload. No new readiness semantics were introduced. Generation-change cases, both account/session outcomes, current error recovery, same-counter replacement, stale finally ownership, rejected-send admission and unmount cancellation remain covered. A background research snapshot is separate evidence, not a substitute for bootstrap guards.

## Visual inspection and cleanup

I inspected desktop and mobile native two-turn history screenshots, the final skill's desktop empty state, all three initial recommendation views, short-mobile preference controls, mobile history bottom, and mobile account recovery. The minimal header, conversation layout, first answer, fixture labeling and bottom composer remain readable. The short viewport requires conversation scrolling to reach the complete card and its sources, which the skill exercises. No new clipping or document-level overflow was observed. This is author verification, not independent visual approval.

All owned browser/server processes completed. Ports 3398 and 5498 are free. Generated artifacts that touched pre-existing tracked paths were copied into this directory and those tracked paths restored. The working tree has no tracked changes. Only this evidence directory is untracked. No paid calls, private environment, ledger, grant, human preview or operator capture was accessed. GitHub and merge actions remain with root.

## Limits and integration

These results prove the C-based application with this transport fix. They do not prove the combined V5 price branch. Priceowner reports that its current native factory replaces `price.assessment` with `price.attribution` and adds moneySupport, priceBasis and sourceReviews. The existing browser-server fixture transformations must update those fields and their bound source URLs/quotations when root joins the branches. No incompatible V5 fixture changes were applied here.

Cookie evidence uses Chromium 159.0.8154.6 and default caching through actual Vite and Hono. Hook-local ownership does not arbitrate two simultaneously live tabs or independent hook roots sharing a cookie jar. No same-cookie multi-tab safety claim is made. Automated research uses explicit local substitutes and does not establish live retrieval, usefulness, current inventory or merchant verification. Root still owns independent Comment Sicko, QA, security, combined-head CI and merging.

## Principles that changed decisions

- Fix Root Causes selected transport cancellation because response headers, not React publication, change the guest identity.
- Model the Domain selected one bootstrap owner across both awaits while preserving separate submission and research generations.
- Laziness Protocol restricted production changes to the two existing files and reused existing signal plumbing.
- Test Behavior, Not Implementation replaced the obsolete duplicate-initial-read precondition while retaining exact history, draft, readiness, ownership, errors and provider counts.
- Prove It Works required native pre-header/body-held pairs, browser-owned readback, released gates, exact reload history and screenshot inspection. It also rejected the source-changing verification run as a pass.

All listed principle leaf skills were read in full. No memory-derived project claim informed this implementation.
