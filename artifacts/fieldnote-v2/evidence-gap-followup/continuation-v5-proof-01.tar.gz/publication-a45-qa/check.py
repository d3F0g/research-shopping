import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

ROOT = Path('/tmp/fieldnote-v5-publication-qa')
BUNDLE = ROOT / 'artifacts/fieldnote-v2/evidence-gap-followup'
HEAD = 'a45cac153f9bdafab9c9d7c2972f0889ef854799'
BASE = '347f3a17bd5881918f49edd361f4cd4527ae832c'
OUT = Path('/tmp/fieldnote-v5-publication-results.json')
results = {}

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def digest(data):
    return hashlib.sha256(data).hexdigest()

def check_tar(data, entries):
    expected = {e['path']: e for e in entries}
    assert len(expected) == len(entries), 'duplicate manifest path'
    contents = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        for member in archive.getmembers():
            p = PurePosixPath(member.name)
            assert member.isfile() and not p.is_absolute() and '..' not in p.parts
            assert member.name not in contents, 'duplicate tar path'
            assert member.name in expected, member.name
            entry = expected[member.name]
            b = archive.extractfile(member).read()
            assert member.size == len(b) == entry['bytes'], member.name
            assert digest(b) == entry['sha256'], member.name
            contents[member.name] = b
    assert set(contents) == set(expected), 'missing member'
    return contents

manifest = json.loads((BUNDLE / 'continuation-v5-proof-manifest.json').read_bytes())
contents = {}
archive_results = []
for entry in manifest['archives']:
    data = (BUNDLE / entry['path']).read_bytes()
    assert len(data) == entry['bytes'] and len(data) < 100_000_000
    assert digest(data) == entry['sha256']
    members = check_tar(data, entry['members'])
    assert not set(contents).intersection(members)
    contents.update(members)
    archive_results.append({'path': entry['path'], 'bytes': len(data), 'members': len(members), 'sha256': digest(data)})
assert len(contents) == 1179
results['v5Archives'] = archive_results

seals = {s['scope']: s['sha256'] for s in manifest['ownerSeals']}
sealed_specs = [
    ('price-owner', 'artifacts/issue-64-price-v5/owner-evidence-manifest.json', 'files', 390),
    ('independent-qa', 'manifest.json', 'files', 239),
    ('independent-security', 'sealed-manifest.json', 'members', 29),
]
results['ownerSeals'] = []
for prefix, name, key, count in sealed_specs:
    raw = contents[prefix + '/' + name]
    assert digest(raw) == seals[prefix]
    entries = json.loads(raw)[key]
    assert len(entries) == count
    for entry in entries:
        b = contents[prefix + '/' + entry['path']]
        assert len(b) == entry['bytes'] and digest(b) == entry['sha256'], entry['path']
    results['ownerSeals'].append({'scope': prefix, 'members': count, 'sha256': digest(raw)})

old = json.loads((BUNDLE / 'publication-review-receipts-manifest.json').read_bytes())
data = (BUNDLE / old['archive']).read_bytes()
assert len(data) == old['bytes'] and digest(data) == old['sha256']
old_contents = check_tar(data, old['members'])
assert len(old_contents) == 60 and len(old['retiredLoosePaths']) == 53
for name in old['retiredLoosePaths']:
    assert not (ROOT / name).exists()
    assert old_contents[name] == git('show', '7d503ce^:' + name), name
original = json.loads(old_contents['preserved/original-publication-review-receipts-manifest.json'])
original_tar = old_contents['preserved/original-publication-review-receipts.tar.gz']
assert digest(original_tar) == original['sha256']
original_contents = check_tar(original_tar, original['members'])
assert len(original_contents) == 5
for name, data in original_contents.items():
    assert old_contents[name] == data, name
for name in ['publication-review-receipts-manifest.json', 'publication-review-receipts.tar.gz']:
    assert old_contents['preserved/original-' + name] == git('show', '7d503ce^:artifacts/fieldnote-v2/evidence-gap-followup/' + name)
results['retiredArchive'] = {'members': len(old_contents), 'retiredPaths': 53, 'originalReports': len(original_contents), 'sha256': old['sha256'], 'allBytesEqualPriorGitObjects': True}

bindings = json.loads((BUNDLE / 'history-initial-readiness-manifest.json').read_bytes())['documentation']
for entry in bindings:
    assert digest((ROOT / entry['path']).read_bytes()) == entry['sha256'], entry['path']
results['documentationBindings'] = bindings

changed = git('diff', '--name-only', BASE, HEAD).decode().splitlines()
allowed = ['.codex/', 'docs/', 'artifacts/fieldnote-v2/evidence-gap-followup/']
assert all(any(p.startswith(prefix) for prefix in allowed) for p in changed), changed
results['diffFromReviewed'] = changed
tracked = git('ls-tree', '-r', '--name-only', HEAD).decode().splitlines()
source_paths = [p for p in tracked if p.startswith(('src/', 'server/', 'evals/', 'tests/', 'scripts/', '.agents/', '.github/')) or '/' not in p]
for p in source_paths:
    assert git('rev-parse', BASE + ':' + p) == git('rev-parse', HEAD + ':' + p), p
results['equalSourceGitObjects'] = len(source_paths)
delta = git('diff', '--name-only', '1a39ab12329fdd0ff727519bbc4b16ed085014e2', HEAD).decode().splitlines()
assert delta == ['.agents/skills/verify-research-shopping/scripts/smoke.mjs'], delta
results['integrationAToFinalB'] = delta

needles = set(old['retiredLoosePaths'])
needles.update('/'.join(p.split('/')[:3]) for p in old['retiredLoosePaths'])
hits = []
for p in source_paths:
    data = (ROOT / p).read_bytes()
    for needle in needles:
        if needle.encode() in data:
            hits.append({'path': p, 'reference': needle})
assert not hits, hits
results['retiredPathSourceReferences'] = hits
preservation = json.loads((ROOT / 'evals/preservation-v2.json').read_bytes())
assets = [a for a in preservation['assets'] if a['path'] != '.github/workflows/product-evals.yml']
assert len(assets) == 389
assert not set(a['path'] for a in assets).intersection(old['retiredLoosePaths'])
for asset in assets:
    assert git('rev-parse', HEAD + ':' + asset['path']).decode().strip() == asset['blob']
    assert git('hash-object', asset['path']).decode().strip() == asset['blob']
results['preservationAssets'] = {'unchangedCommittedAssets': len(assets), 'retiredPathIntersection': 0}
qa_binding = json.loads(contents['independent-qa/final-source-and-archive-binding.json'])
for p, oid in qa_binding['runtimeSourceEquality'].items():
    assert git('rev-parse', HEAD + ':' + p).decode().strip() == oid
results['reviewerRuntimeBindings'] = len(qa_binding['runtimeSourceEquality'])
root_proof = json.loads(contents['root-runtime/root-runtime-proof.json'])
for entry in root_proof['files']:
    relative = entry['path'].removeprefix('artifacts/issue-64-price-v5/')
    b = contents['root-runtime/' + relative]
    assert len(b) == entry['bytes'] and digest(b) == entry['sha256']
results['rootRuntimeFilesBound'] = len(root_proof['files'])
eval_paths = [
    'price-owner/artifacts/issue-64-price-v5/frozen-eval-final/report.json',
    'price-owner/artifacts/issue-64-price-v5/current-composed-eval/report.json',
    'price-owner/artifacts/issue-64-price-v5/current-composed-eval-projection-fixed/report.json',
    'root-runtime/root-current-eval/report.json',
    'independent-qa/eval-current/report.json',
]
results['retainedEvaluationReports'] = []
for name in eval_paths:
    report = json.loads(contents[name])
    assert len(report['cases']) == 60 and report['summary']['observedTurns'] == 140
    results['retainedEvaluationReports'].append({'path': name, **{k:report['summary'][k] for k in ['executed', 'passed', 'failed', 'blocked', 'unsupported', 'criticalFailures', 'infrastructureErrors', 'acceptance']}})
visuals = []
visuals += ['initial-checks/skill/' + p for p in ['desktop-01-dark-empty.png','desktop-02-light-empty.png','desktop-05-research-initial.png','desktop-06-evidence.png','mobile-03-ordinary.png','mobile-04-currency-question.png','mobile-05-research-initial.png','mobile-08-preferences.png','short-mobile-02-light-empty.png','short-mobile-05-research-initial.png','short-mobile-06-evidence.png','short-mobile-07-comparison.png','short-mobile-08-preferences.png','short-mobile-11-provider-error.png']]
visuals += ['usefulness-browser/' + p for p in ['1440-prices-dark.png','390-prices-dark.png','1440-buyer-restriction.png','390-buyer-restriction.png','1440-held-light.png','390-held-light.png']]
visuals += ['history-browser/' + p for p in ['1440-current-observation.png','390-current-observation.png','1440-literal-evidence.png','390-literal-evidence.png']]
visuals += ['maintained-e2e/e2e/held-replies/short-mobile-battery-concise.png','maintained-e2e/e2e/held-replies/short-mobile-battery-details.png','accounts/mobile-saved-research.png','accounts/mobile-stop-reset-conflict-recovered.png','extra-short-mobile-context-recovery.png']
assert len(visuals) == 29
for p in visuals:
    assert contents['independent-qa/' + p].startswith(b'\x89PNG\r\n\x1a\n'), p
results['qaVisualsRetainedAndHashVerified'] = len(visuals)
pr_base = git('merge-base', 'main', HEAD).decode().strip()
pr_count = len(git('diff', '--name-only', pr_base, HEAD).decode().splitlines())
assert pr_count < 3000
results['prDiff'] = {'base': pr_base, 'changedPaths': pr_count}
results['rootPrivacyScanReportedOnly'] = manifest['rootPrivacyScan']
results['status'] = git('status', '--porcelain').decode()
assert not results['status']
OUT.write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
