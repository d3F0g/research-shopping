# Independent V5 publication QA

Fieldnote users need useful prices and recommendations while preserving the approved chat UI and honest evidence. This review passes the metadata and archive scope at `a45cac153f9bdafab9c9d7c2972f0889ef854799`. It does not approve runtime behavior, live usefulness, or publication before the newly reported scorecard CLI blocker is fixed and independently reviewed.

The reviewed base is `347f3a17bd5881918f49edd361f4cd4527ae832c`. The detached owned worktree is `/tmp/fieldnote-v5-publication-qa`. The configured Luna QA role was unavailable according to the parent brief. This reviewer used the explicit parent-inheritance fallback. The reviewer authored no application, evaluator, maintained test, verification-skill, or repository documentation changes.

## Scope and checkpoint

The task has three verifiable units. First, compare exact Git objects to the independently reviewed source. Second, read every archive member and sealed manifest. Third, reconcile the public metadata with retained failures and acceptance limits. Each unit completed before the next verdict. Runtime was deliberately not repeated because application, evaluator, tests, scripts, skill, package, configuration, and workflow bytes are unchanged after the reviewed base.

The post-review diff contains exactly ten paths under `.codex/pstack-runs`, `docs`, and the evidence package. Final B differs from application-only integration A `1a39ab12329fdd0ff727519bbc4b16ed085014e2` in exactly `.agents/skills/verify-research-shopping/scripts/smoke.mjs`. This supports the separately scoped Issue 66 integration described in the brief. Root owns GitHub state and mutations.

## Reproducible checks

The rerunnable probe is `/tmp/fieldnote-v5-publication-check.py`. Its complete machine-readable result is `/tmp/fieldnote-v5-publication-results.json`. It reads repository Git objects and archive bytes. It never executes an archived program and never extracts archive paths onto the checkout.

The principal commands were as follows.

```text
git worktree add --detach /tmp/fieldnote-v5-publication-qa a45cac153f9bdafab9c9d7c2972f0889ef854799
git diff --stat 347f3a17bd5881918f49edd361f4cd4527ae832c a45cac153f9bdafab9c9d7c2972f0889ef854799
git diff --name-status 1a39ab12329fdd0ff727519bbc4b16ed085014e2 a45cac153f9bdafab9c9d7c2972f0889ef854799
python3 /tmp/fieldnote-v5-publication-check.py
```

The probe passed with exit code zero. Its first run exposed a probe assumption that the historical nested manifest had a top-level byte count. That historical manifest has member byte counts and an archive SHA, so the probe was corrected to its actual schema. No package file changed. One separate `rg` command stopped before searching because a shell wildcard matched nothing. Reading the named preservation verifier and inventory replaced that command.

All 1,179 V5 members match their manifest size and SHA256, with no missing, duplicate, or extra member. Every member is a regular file at a relative path without parent traversal. Part 1 has 1,136 members, 82,342,043 compressed bytes, and SHA256 `ef2901dbd30c651e3d67131fcaf93e40eb4de9bbf530d3884c6990ed3b42dd02`. Part 2 has 43 members, 18,819,122 compressed bytes, and SHA256 `052d38c3bee1a6391aa4f548b63a7bf8ea7a471993755648468f311692e8f3c0`. Each archive is below 100,000,000 bytes.

The price-owner seal is `85eeb85efd0c9ecbcabcf29ec2d8afb9e688cd4861251059f05870d1eb3b2740`. All 390 indexed owner files match. The independent-QA seal is `44aaaf836f50621070799581be2f451d0a0dae5bb6fe2a58f64856558020151a`. All 239 indexed files match. The independent-security seal is `474788cc18729b4dc9ff3152cc17a474f142dae5f763b49971dda5cb288fc800`. All 29 indexed files match. The archived owner report, QA report, and security report were read directly at their actual manifest paths.

The prior consolidation archive has all 60 indexed members. All 53 retired files equal their exact Git blobs before `7d503ce`. The original five publication reports, nested original tar, and nested original manifest are byte-identical to the earlier Git objects. Its current archive SHA256 is `0bd2419ed59492a99ce05c893e8f83895345643741bde08f316b2c61f59c62c1`.

The probe found no retired-path references in current application, evaluator, tests, scripts, skill, workflow, package, or configuration files. All 389 frozen preservation assets match both their committed blobs and worktree bytes. None intersects the 53 retired paths. Nine QA-recorded runtime Git object bindings resolve to the same objects at final B. Eight root-runtime files also match their separate proof inventory. All 29 QA-listed visual PNGs are retained and pass the same archive hashing checks. This publication review verified their retention and provenance. It does not replace the original independent visual inspection.

The two current documentation bindings match. `docs/fieldnote-evidence-followup.md` hashes to `825a131b64cc2a0522fe084d816119bf4f249160dfab649bb2c539d46d175c41`. The package `EVIDENCE.md` hashes to `c8918a87d3d8da27b76cd2ea6eb015eab022de7956601d2379aa7b35db1012a8`. The diff against pinned main `9d2a3c5e336a6652ec6b02e0c3deff6617fb7d11` contains 2,998 paths, below GitHub's 3,000-file view bound. The checkout remains clean.

## Failures and acceptance remain explicit

Each retained evaluator report contains all 60 cases and 140 observed turns. The original native-1 run retains 10 passed, 3 failed, 46 blocked, and 1 unsupported, with acceptance `fail`. The first composed V5 run retains the same case counts and its 14 critical failures. The corrected owner, root, and independent-QA reports each retain 11 passed, zero failed, 48 blocked, 1 unsupported, zero critical failures, and zero infrastructure errors. Each says acceptance is `inconclusive`. These results do not measure live product relevance or usefulness. Their metrics explicitly leave those dimensions unassessed.

The package retains the native session baseline script and failed proof, the failed hosted workflow and browser evidence, the first skill failure and corrected run, ordinary-format baseline and candidate SDK probes, root native browser evidence, and independent boundary, SDK, browser, and evaluator probes. Original relative output locators remain in the proofs. Documentation instructs readers to restore the matching prefix under a matching historical checkout before any reviewed rerun. The documentation does not claim archived programs are executable as-is.

The current and historical sections remain distinguishable. The docs preserve merchant-verification uncertainty, unknown inventory and delivery, model-compliance uncertainty, the limits of literal containment, and unverified live recommendation quality. They state that the exact prior history authorization was consumed. They do not claim erasure across refs, clones, or caches. The three old transcript-provenance references outside the moved material remain disclosed and unchanged.

The public privacy statement is bounded. The manifest reports a private root comparison of 5,447 objects against 113 captured values with zero matches. This reviewer did not receive those values and cannot independently replicate that comparison. The report is root evidence, not an independent privacy scan. No private environment, raw capture, private diagnostic, actual ledger, grant, human preview, or credential was accessed by this reviewer. No provider call, GitHub mutation, or deployment occurred.

## Verdict and external blocker

There is no reproduced blocking defect in this exact metadata and archive scope. Publication QA passes at a45cac1. Existing independent runtime QA and security verdicts remain scoped to 347f3a1 and are bound by unchanged Git objects. No new behavior acceptance is inferred from packaging.

During this review, root reported a newly reproduced scorecard CLI failure at 347f3a1 involving original native-1 `scenarioMaterial` versus the runner's explicit current native-2 composition. This was not part of the previously executed proof. It is an external current-CI blocker and keeps shared publication held. The pending evaluator-only fix, its integrity tests, full actual CLI proof, metadata, and repackaged failures need their own exact-candidate delta review. This report does not certify that future head or a future archive hash.

## Principles that changed decisions

Prove It Works required reading every archive byte and resolving exact Git objects rather than accepting packaging summaries. Build the Lever produced the rerunnable probe and JSON result. Sequence Work into Verifiable Units separated source equality, archive integrity, and publication truth before the verdict. Explain the Number kept the 60-case results tied to their actual case and turn inventories and unassessed usefulness dimensions. Technical Writing and Unslop kept measured checks separate from parent-reported privacy evidence and the later scorecard blocker.
