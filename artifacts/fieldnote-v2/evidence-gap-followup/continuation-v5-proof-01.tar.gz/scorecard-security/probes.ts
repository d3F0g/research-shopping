import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { readFile, writeFile } from "node:fs/promises";
import { loadDataset } from "../../../evals/dataset";
import { hash, materialPayloadHash } from "../../../evals/hash";
import { scenarioMaterial } from "../../../evals/inputs/materials";
import { currentScenarioMaterial } from "../../../evals/v2/materials";
import { caseResult, validateReport } from "../../../evals/v2/report";
import { summarize } from "../../../evals/frozen-v4/report";
import { crossContractScorecard } from "../../../evals/v2/scorecard";
import type { Material } from "../../../evals/frozen-v4/contracts";
import type { RunReport } from "../../../evals/v2/contracts";

type Probe = { id: string; name: string; mutate: (material: Material) => void };
type Result = { id: string; name: string; genericValidatorAccepted: true; rejected: string; forgedMaterialHash: string };
const directory = "artifacts/playwright-results/scorecard-security";
const head = "842c394c8477dd7d23a9a2dddf16f65dc9c00576";
const base = "a45cac153f9bdafab9c9d7c2972f0889ef854799";
const git = (...args: string[]) => execFileSync("git", args, { encoding: "utf8" }).trim();
assert.equal(git("rev-parse", "HEAD"), head);
assert.deepEqual(git("diff", "--name-only", base, head).split("\n"), ["evals/v2/scorecard.ts", "evals/v2/tests/integrity.test.ts"]);
assert.equal(git("rev-parse", "HEAD:src"), git("rev-parse", `${base}:src`));
const candidate: RunReport = JSON.parse(await readFile(`${directory}/current/report.json`, "utf8"));
const baseline = JSON.parse(await readFile("artifacts/product-evals/baseline-v1/report.json", "utf8"));
const dataset = await loadDataset();
validateReport(candidate);
validateReport(baseline);
assert.equal(dataset.scenarios.length, 60);
assert.equal(dataset.originalSha256, "c452827b9aa87bc0b47c3e9a4cc6427a42bbf0303539bc2c09a2093ed754cb8f");
assert.equal(candidate.application.commit, head);
assert.equal(candidate.application.dirty, false);
assert.equal(candidate.suite.dirty, false);
assert.equal(candidate.summary.executed, 60);
assert.equal(candidate.summary.observedTurns, 140);
assert.equal(candidate.summary.infrastructureErrors, 0);
assert.equal(candidate.configuration.exaCreditsConsumed, 0);
assert(candidate.cases.every((row) => row.observation?.cleanup && row.observation.network.denied.length === 0 && row.observation.network.externalRequests === 0));
const changed = ["FN-CU-001", "FN-RT-002", "FN-PQ-001"];
const comparisons = dataset.scenarios.map((contract) => {
  const current = currentScenarioMaterial(contract.provider, contract.id);
  const original = scenarioMaterial(contract.provider, contract.id);
  const row = candidate.cases.find((item) => item.id === contract.id)!;
  assert.equal(row.materialHash, hash(current), contract.id);
  assert.equal(hash(row.material), hash(current), contract.id);
  assert.equal(hash(current) === hash(original), !changed.includes(contract.id), contract.id);
  return { id: contract.id, current: hash(current), original: hash(original), same: hash(current) === hash(original) };
});
const scorecard = await crossContractScorecard(baseline, candidate);
assert.equal(scorecard.rows.length, 60);
assert.equal(scorecard.unchangedInputs, 57);
assert.deepEqual(scorecard.differentHistoricalMaterial, changed);
assert.equal(scorecard.acceptance, "inconclusive");
assert.deepEqual(scorecard.candidate.summary, candidate.summary);
assert.deepEqual(scorecard.baseline.summary, baseline.summary);
assert.equal(scorecard.schemaVersion, 1);
assert.equal(scorecard.bridge, "fieldnote-historical-v2-descriptive-1.0.0");
const paired = scorecard.rows.filter((row) => !changed.includes(row.id)).flatMap((row) => row.sharedNormativeRequirements).filter((item) => ["pass", "fail"].includes(item.before) && ["pass", "fail"].includes(item.after));
assert.equal(scorecard.pairedAssessed.denominator, paired.length);
assert.equal(scorecard.pairedAssessed.beforePassed, paired.filter((item) => item.before === "pass").length);
assert.equal(scorecard.pairedAssessed.afterPassed, paired.filter((item) => item.after === "pass").length);
assert(Object.values(scorecard.requirementTransitions).flat().every((item) => !changed.includes(item.scenarioId)));
const probes: Probe[] = dataset.scenarios.map(({ id }) => ({ id, name: "provenance-only", mutate: (material) => { material.provenance.push("Fixture-only independent forged provenance"); } }));
const variants: Array<Pick<Probe, "name" | "mutate">> = [
  { name: "payload-only", mutate: (material) => { material.body = { ...material.body as Record<string, never>, requestId: "fixture-only-independent-forgery" }; } },
  { name: "id-only", mutate: (material) => { material.id = "fixture-only-forged-identity"; } },
  { name: "label-only", mutate: (material) => { material.label = "Fixture-only independent forged label"; } },
  { name: "capture-metadata-only", mutate: (material) => { material.capturedAt = "2000-01-01T00:00:00.000Z"; } },
  { name: "kind-only", mutate: (material) => { material.kind = "recorded-exa-response"; } },
  { name: "status-only", mutate: (material) => { material.status = 299; } },
  { name: "delay-only", mutate: (material) => { material.delayMs = 17; } },
];
for (const id of [...changed, "FN-CU-002"]) for (const variant of variants) probes.push({ id, ...variant });
for (const id of changed) probes.push({ id, name: "historical-native1-substitution", mutate: (material) => {
  const contract = dataset.scenarios.find((row) => row.id === id)!;
  Object.assign(material, scenarioMaterial(contract.provider, contract.id));
} });
probes.push({ id: "FN-CU-002", name: "unassigned-native2-substitution", mutate: (material) => {
  Object.assign(material, currentScenarioMaterial("supported", "FN-CU-001"));
} });
const results: Result[] = [];
for (const probe of probes) {
  const forged = structuredClone(candidate);
  const index = forged.cases.findIndex((row) => row.id === probe.id);
  const row = forged.cases[index]!;
  assert(row.observation);
  probe.mutate(row.material);
  row.material.sha256 = materialPayloadHash(row.material);
  row.observation.material = structuredClone(row.material);
  forged.cases[index] = caseResult(row.contract, row.material, row.observation);
  forged.summary = summarize(forged.cases);
  validateReport(forged);
  let rejected = "";
  await assert.rejects(crossContractScorecard(baseline, forged), (error: Error) => {
    rejected = error.message;
    return rejected === `Changed V2 research material for ${probe.id}`;
  });
  results.push({ id: probe.id, name: probe.name, genericValidatorAccepted: true, rejected, forgedMaterialHash: forged.cases[index]!.materialHash });
  console.log(JSON.stringify(results.at(-1)));
}
const guardResults: Array<{ name: string; rejected: string }> = [];
for (const [name, mutate] of [
  ["stale-payload-sha", (report: RunReport) => { const row = report.cases[0]!; row.material.body = { fixtureOnlyForgery: true }; row.observation!.material = structuredClone(row.material); }],
  ["stale-row-material-hash", (report: RunReport) => { const row = report.cases[0]!; row.material.provenance.push("Fixture-only stale row hash"); row.observation!.material = structuredClone(row.material); }],
] as const) {
  const forged = structuredClone(candidate);
  mutate(forged);
  assert.throws(() => validateReport(forged), (error: Error) => {
    guardResults.push({ name, rejected: error.message });
    return true;
  });
}
const missing = structuredClone(candidate);
missing.cases.pop();
missing.summary = summarize(missing.cases);
validateReport(missing);
await assert.rejects(crossContractScorecard(baseline, missing), /complete unchanged scenario coverage/);
guardResults.push({ name: "missing-case-with-consistent-summary", rejected: "complete unchanged scenario coverage" });
const changedExpectations = structuredClone(candidate);
const contract = changedExpectations.datasetContracts[0]!;
contract.expectedBehavior.push("Fixture-only invented expectation");
changedExpectations.datasetHash = hash(changedExpectations.datasetContracts);
changedExpectations.implementationHashes.suite = hash({ grading: changedExpectations.implementationHashes.grading, adapter: changedExpectations.implementationHashes.adapter, datasetHash: changedExpectations.datasetHash });
const row = changedExpectations.cases[0]!;
changedExpectations.cases[0] = caseResult(contract, row.material, row.observation);
changedExpectations.summary = summarize(changedExpectations.cases);
validateReport(changedExpectations);
await assert.rejects(crossContractScorecard(baseline, changedExpectations), /unchanged sixty original scenario contracts/);
guardResults.push({ name: "self-consistent-changed-expectations", rejected: "unchanged sixty original scenario contracts" });
const evidence = { base, head, applicationTree: git("rev-parse", "HEAD:src"), reportDigest: hash(candidate), baselineDigest: hash(baseline), scorecardDigest: hash(scorecard), comparisons, summary: candidate.summary, pairedAssessed: scorecard.pairedAssessed, materialProbeCount: results.length, results, guardResults };
await writeFile(`${directory}/probe-results.json`, JSON.stringify(evidence, null, 2));
console.log(JSON.stringify({ verdict: "PASS", materialProbeCount: results.length, guardProbeCount: guardResults.length, pairedAssessed: scorecard.pairedAssessed }));
