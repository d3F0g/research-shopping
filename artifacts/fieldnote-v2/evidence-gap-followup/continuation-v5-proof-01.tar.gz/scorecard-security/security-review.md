# Independent scorecard security review

The user wants useful Fieldnote prices and an honest comparison with frozen scenarios while preserving the approved application UI. This review passes the bounded scorecard fix at `842c394c8477dd7d23a9a2dddf16f65dc9c00576`. No blocking defect was found in the two-file delta from `a45cac153f9bdafab9c9d7c2972f0889ef854799`.

This is a fresh independent review. The reviewer did not author the implementation. The assigned detached worktree is `/tmp/fieldnote-scorecard-security`. Tracked application, evaluator, test, skill, documentation, and historical artifact files were not edited. The worktree remains clean. Review outputs are ignored files under this directory.

`source.patch` contains the complete delta. It changes only `evals/v2/scorecard.ts` and `evals/v2/tests/integrity.test.ts`, with 58 insertions and 3 deletions. The production change replaces the material-generator import and call. The application source tree is `579b672ee1a8aef9f413f92a48f72954109cb7d8` at both base and head. The current material generator, runner, report validator, assertions, frozen inputs, historical contracts, package configuration, and verification skill are byte-identical across this delta.

The scorecard imports the finite current generator used by the runner. That generator separately composes labeled native2 fixtures for `FN-CU-001`, `FN-RT-002`, and `FN-PQ-001`. It uses the original generator for every other canonical scenario. The scorecard still compares both the row's material hash and the full material object against that trusted local result. It does not execute embedded source, repair arbitrary native1 inputs, or infer authorization from a self-consistent report hash.

The canonical sixty-scenario contract gate, complete case-coverage gate, action and expectation comparisons, and full-material gate remain intact. The scorecard schema remains `1`, and its bridge remains `fieldnote-historical-v2-descriptive-1.0.0`. Material differences still exclude rows from aggregate requirement transitions and the jointly assessed denominator.

Independent results are retained in the following files.

- `eval.log` and `current/report.json` record a fresh real runner invocation. All 60 scenarios executed with 140 observed turns. There were 11 passed, 0 failed, 48 blocked, and 1 unsupported scenarios. Critical failures and infrastructure errors were both zero. Deterministic acceptance remains `inconclusive`.
- `scorecard-cli.log` and `scorecard/scorecard.json` record a fresh CLI comparison against the tracked baseline. There are 57 unchanged material sets and exactly the three changed cases listed above. None appears in requirement transitions. The paired denominator is 203, independently recounted from unchanged cases with assessed results on both sides. The 151 historical passes and 203 candidate passes are descriptive across different evaluator and application contracts. They do not establish causal or live product improvement.
- `probe-results.json` records 92 self-consistent material forgeries. Every forged report passes `validateReport` and fails the scorecard's material gate. Provenance-only mutations cover every one of the 60 scenarios. Payload, identity, label, capture timestamp, kind, response status, and delay mutations cover all three current fixture cases and unassigned `FN-CU-002`. Native1 substitution fails for all three current cases. Copying an assigned native2 fixture into the unassigned case also fails.
- `probe-results.json` also records four separate boundary checks. The report validator rejects stale payload hashes and stale full-row material hashes. The scorecard rejects a removed case despite a consistent summary, and rejects changed frozen expectations despite a consistent contract and suite hash.
- `cli-probe-results.json` records two additional real CLI rejection tests, at `FN-CU-001` and `FN-CU-002`. Both forged reports pass the generic validator after material changes, altered embedded generator text, and recomputed bindings. The CLI exits with status 1 on the material gate. It does not execute the embedded text or create an output directory. The forged synthetic inputs and stderr are retained.
- `integrity-tests.log` records all 16 tests passing, including the new full-60 CLI regression and both assigned and unassigned material forgeries. The new tests verify real output and exclusion behavior. Their temporary output directory is owned by `mkdtemp` and removed through the test cleanup callback.
- `preservation.log` records 389 unchanged committed historical assets verified against the preservation manifest. `typecheck.log` is empty because evaluator typechecking passed. `git diff --check` passed.

The scoped diff adds no narrating comments, suppression directives, arbitrary compatibility path, or symptom guard. It preserves strict rejection and corrects the authoritative material source. The independent no-comments workflow remains coordinated separately by the root.

All runner, test, and probe processes used an empty inherited environment plus only `PATH`, `HOME`, `LC_ALL=C`, `NODE_ENV=test`, and `EXA_RESEARCH_ENABLED=false`. The integrity test's child processes use its narrower explicit environment. Dependencies were copied from the approved local checkout with cache directories excluded. The inspected runner uses its offline network guard, dynamically allocated owned IPv4 loopback origins, the actual SDK, and isolated in-memory quota. The fresh report records no denied destination, external request, or cleanup failure. No private environment, operator capture, diagnostic file, ledger, grant, database, preview process, GitHub mutation, or paid provider call was used.

Run the following commands from the assigned worktree. Prefix every Node command with `/usr/bin/env -i PATH=/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin HOME=/Users/josiahwong LC_ALL=C NODE_ENV=test EXA_RESEARCH_ENABLED=false`.

```sh
node --import tsx evals/v2/run.ts --out artifacts/playwright-results/scorecard-security/current
node --import tsx evals/v2/scorecard-cli.ts --baseline artifacts/product-evals/baseline-v1/report.json --candidate artifacts/playwright-results/scorecard-security/current/report.json --out artifacts/playwright-results/scorecard-security/scorecard
node --import tsx --test evals/v2/tests/integrity.test.ts
node evals/v2/verify-preservation.mjs
node node_modules/typescript/bin/tsc --noEmit -p evals/v2/tsconfig.json
node --import tsx artifacts/playwright-results/scorecard-security/probes.ts
node --import tsx artifacts/playwright-results/scorecard-security/cli-probes.ts
git diff --check a45cac153f9bdafab9c9d7c2972f0889ef854799 HEAD
git status --porcelain --untracked-files=all
```

The canonical report digest is `04a6f476a2d1f78eca3fab5bce438227b7334ad89037035deb46abe47adb4851`. The baseline digest is `4bd357f8ff4ee0e711a8f3eb686b0296de290895ee091acf113a8c68b433151f`. The scorecard digest is `d5bba91b57e40487c326741b34f3928148ee6dd8e4e8c815686387aa8af7dde3`. These use the repository's canonical JSON hash. The separate seal manifest uses raw file SHA-256.

Boundary Discipline directed the review toward admission of external report data, including internally consistent forgeries. Prove It Works required actual CLI output and an independently generated report. Explain the Number required tracing the denominator to unchanged, jointly assessed inputs and retaining the inconclusive result. Test Behavior, Not Implementation shaped probes around observable acceptance, rejection, and output creation. Model the Domain organized the mutation matrix by scenario and material field. Build the Lever produced the rerunnable probe scripts and their retained results.

This verdict applies only to the exact two-file delta at the reviewed source commit. It is not an application security approval, browser approval, publication approval, or final integration-commit approval. The unchanged browser journeys were intentionally not rerun. Synthetic results do not establish live discovery, real price usefulness, relevance, stock, merchant verification, or semantic quality. Execution provenance and this local seal are not cryptographic attestations. Existing generic report validation checks internal consistency; the scorecard adds canonical material admission. Later publication and source rebinding require their separately assigned readback.
