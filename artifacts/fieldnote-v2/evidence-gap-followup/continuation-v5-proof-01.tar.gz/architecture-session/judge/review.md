# Session ownership design review

Preserve Fieldnote's approved UI and genuine guest history. Select B as the implementation base, with the acceptance refinements below. This is conditional design approval. Neither candidate has proved cookie safety at runtime.

The reviewed source is `dc61d3bae93fd347495ecbb5973d7877513ec91d` in `/Users/josiahwong/Documents/research-shopping-v2`. I read all six candidate files, the grounding, the rubric, the current hook and API, AccountControl, App, main, the relevant server routes, and the current guest and account stale-read tests. I also inspected the supplied native proof. I made no application writes and ran no browser, provider, or paid operation. The parent model family was not exposed, so no family check was performed.

The root owns Frame, Fan out, Pick, Graft, and Verify. This report completes the assigned Cross-judge and architectural screen. Implementation and runtime acceptance remain pending.

## Scores

Scores assess the proposed designs against the supplied rubric. They are judgments, not measured runtime results.

| Criterion | A | B | Evidence and consequence |
| --- | ---: | ---: | --- |
| Native cookie identity safety | 4 | 3 | A prevents the duplicate dispatch within one retained hook. B cancels obsolete writers, but native pre-header abort behavior is unproved. Neither owns all concurrently live tabs or roots. |
| Smallest coherent ownership without global user state | 3 | 5 | A owns a pending promise but cannot invalidate it across lifetimes. B gives one hook an owned account-to-session request and uses the existing signal-aware API. Both avoid global state. |
| StrictMode, abort, errors, and account lifecycle | 3 | 4 | A covers current initial gating and explicit retry after settlement. A does not cancel on real unmount and joins an invalidated pending reload. B replaces or cancels that work, retains both counters, and guards stale catch and finally. Account request sequencing outside the hook still needs tests. |
| Preserved browser proof and tests | 4 | 4 | Both require real headers and authoritative history. Both need more exact preconditions for stale-read and account-transition cases. A's background research read alone does not exercise reload's submission guard. |
| Simplicity and bounded implementation | 5 | 4 | A changes one production file. B changes two production files and reuses existing controllers and fetch plumbing. B does not justify a scheduler, cache, or new transport module. |
| Total | 19 | 20 | B is the conditional base because its lifetime ownership is explicit. |

## Grounded findings

The native failure is established by the supplied proof, not by either sketch. Its `before-release` sample has `session-1`, revision 1, and `hello`. Its `after-release` sample has `session-2` and an empty revision 0 while the UI still displays `hello`. Follow-up and reload retain only `thanks`. The recorded response was not aborted. See `/tmp/fieldnote-dc61-ci-notes/root-independent-native/proof.json`.

The causal boundary is the browser cookie. `src/server/app.ts:182` creates a guest when a session, turn, cancel, or new-chat request has no recognized cookie. React publication guards cannot undo that response header. `src/client/useFieldnote.ts:48` currently issues an unowned account read and then a session read. `src/client/api.ts:7` already passes an optional signal to fetch and awaits the body. `getSession` is the missing forwarding point.

A's initial UI argument is supported, within its stated scope. `src/client/main.tsx:7` renders one App under StrictMode. `src/client/App.tsx:60` is the only production hook call. `src/client/AccountControl.tsx:38` exposes no sign-in form while account status is loading, and its actions use local busy state. The hook publishes usable guest status only after receiving the session body. I did not find a current ordinary UI path that starts sign-in during the first pending reload.

That does not make A a general lifecycle owner. Its effect cleanup retains the promise, so a genuinely abandoned hook can leave transport alive while a new instance starts another anonymous read. An `authenticated()` callback that interrupts a pending reload can join its obsolete promise, whose captured counters then prevent publication. These are architectural counterexamples, not claimed reproductions through the present one-root UI. A would need a documented lifetime restriction or new invalidation logic.

B handles replacement and abandonment more directly. One controller owns both awaits. Cleanup and interrupt abort it, and a later reload replaces it. The identity-checked finally prevents an old request from clearing the current controller. An accepted send can abort a reload without cancelling independent ongoing research. Keeping `generation` and `submission` separately preserves their existing meanings.

B is still hook-local. It cannot promise arbitration between simultaneously mounted independent hooks or two live tabs sharing a cookie jar. A second isolated browser context tests user isolation, not that same-cookie concurrency. Do not add a global cache or IP-based identity to cover an unproved broader contract. If same-cookie simultaneous first-load safety is required for Issue 65, neither sketch settles it and the root must treat that as an explicit additional gate.

AccountControl starts its authentication fetch before invoking `onAuthenticated` at lines 59 through 62. Its busy flag serializes its own controls, not the entire browser. B's interrupt occurs when that callback runs. Do not claim that it owns the preceding auth request or other tabs. Preserve this sequence unless a reproducible current-scope test requires a separate change.

## Base and grafts

Use B's exclusive controller and optional `getSession(signal)` as the whole production design. Do not also add A's pending promise. Two cancellation and admission mechanisms would create two owners of the same operation.

Take two acceptance details from A.

1. Keep explicit recovery and fresh reload after settlement. A failed current attempt must retain the draft and expose unavailable state. An explicit reload must issue a fresh read and recover. A settled successful attempt must not become a cache.
2. Keep the exact-history continuation. After releasing every obsolete response, assert the browser-owned session, send `thanks`, then reload. Assert both complete turns, their order and identities, and the newly typed draft before submission. Counting requests or checking that one text remains visible is insufficient.

Reject a general request queue, shared browser singleton, cookie manipulation, server session merging, fixed delays, and automatic retry. They do not belong in this fix. Preserve the UI and server cookie policy.

## Requirements for the isolated implementation owner

The data shape is one private `AbortController | null` ref in `useFieldnote`. Keep the public hook interface unchanged.

1. Own `src/client/useFieldnote.ts` and `src/client/api.ts`. Abort the previous reload before replacement. Pass its signal through both account and session fetches. Check that the owner is not aborted plus both captured counters after each await and in catch. Clear the ref only if it still names that controller.
2. Abort the owned reload on effect cleanup and interrupt. In send, abort it only after the existing send admission guard. Retain the existing prepare and research controllers. Pass the research controller's signal to its session refresh so response-body consumption ends on Stop or reset.
3. Preserve unavailable errors, drafts, free replies during research, the separate counters, and revision-aware conversation acceptance. Do not increment generation merely for an ordinary reply. Do not turn aborts into visible current failures.
4. Keep production changes to those two files unless a specific failed acceptance case requires a third. Use the existing test files and a small test-only native response gate. Do not introduce a network framework or new package. One owner should make both production and test changes in its isolated worktree. Root owns documentation and GitHub. Independent reviewers must inspect the final exact commit.

## Required verification and test corrections

Run the native identity cases first. Use actual Vite, Hono, StrictMode, default browser caching, and an isolated test server. The gates must control real response headers and bodies. Do not use Playwright route fulfillment to establish cookie behavior.

1. Preserve the supplied old-hook red reproduction, including late-first and late-second scheduling where applicable. On the fixed hook, prove the anonymous duplicate cannot survive to switch the active cookie. Record request cookies, transport aborts, response releases, and browser-owned session readbacks. Release all gates before declaring success. Assert the exact two-turn conversation after follow-up and reload.
2. Exercise an actually dispatched cookie-issuing read aborted before its headers, not only StrictMode's account read aborted before `/api/session` starts. A later release must not change the browser identity. Pair it with accepted headers and a held body. After abort, the replacement must send the installed identity, and the old body must not publish. If either case fails, reject B's cookie-safety claim and return to design. A rejected JavaScript promise alone proves neither case.
3. Adapt `tests/e2e/v2-chat.spec.ts:475` and `scripts/verify-personalization-browser.mjs:46`. Both currently wait for a held first request while a second bootstrap establishes readiness. That precondition changes under either candidate. Do not wait for a response that transport abort has removed. Preserve exact conversation, draft, readiness, error, account ownership, and provider-count assertions. Use established cookies for content races and native gates for cookie races.
4. Keep stale success and failure distinct from current failures at both account and session awaits. A test where the request aborts before reading an account body cannot alone prove the later session guard. Supplement browser cases with narrowly controlled hook tests when needed. A same-turn reload followed by send is not automatically a valid readiness test. The current reload sets ready false, and send does not restore it. First state the accepted-operation precondition and expected readiness. Do not add unrelated readiness behavior merely to satisfy that artificial schedule.
5. Preserve separate generation and submission scenarios. A post-research background session snapshot is a valid free-reply race, but it uses generation and revision acceptance rather than reload's submission guard. It cannot replace every stale bootstrap assertion. Keep the old-hook regression evidence and explain which new cases prove transport cancellation versus stale publication. B's signal check may make a particular counter check redundant within reload, so do not demand that removing each individual check must break the fixed hook. The old-hook failure and preserved observable assertions are the regression contract.
6. Verify actual guest-to-account and sign-out journeys on desktop and mobile. No guest messages may enter the saved workspace. Pending obsolete reads must not replace the new owner, draft, or error state. Sign-in actions are unavailable during initial loading, so do not pretend a forced initial sign-in is an ordinary UI path. Use a direct hook lifecycle case for ownership transitions that the real UI cannot currently initiate.
7. Retain Stop, New chat, current-error recovery, actual local SDK cancellation, free replies during research, contextual constraints, independent browser isolation, and approved UI screenshot checks. Use only injected local responses. Report any same-cookie cross-tab limitation explicitly.

The owner should run the targeted cases, typecheck, and the applicable existing package checks. Root then obtains independent QA and security verdicts on the exact candidate. This report does not replace those gates.

## Principles that changed the decisions

- Fix Root Causes selected transport ownership over another React publication guard because the recorded identity switch occurs in response headers.
- Model the Domain selected one owned bootstrap controller and retained the two existing counters rather than merging three distinct lifetimes.
- Laziness Protocol limited production ownership to the hook and existing API helper. It rejected a scheduler and a hybrid of both candidates.
- Redesign From First Principles required the same controller to cover headers, body consumption, cleanup, and account replacement as one operation.
- Prove It Works made native pre-header and post-header cases conditions of acceptance. The sketch typecheck and source review do not establish cookie behavior.
- Test Behavior, Not Implementation preserved authoritative history, drafts, ownership, and explicit recovery while allowing obsolete two-request test preconditions to change.

All named principle leaf skills were read in full during this review. The memory registry search produced no task-specific evidence and did not inform the recommendation.
