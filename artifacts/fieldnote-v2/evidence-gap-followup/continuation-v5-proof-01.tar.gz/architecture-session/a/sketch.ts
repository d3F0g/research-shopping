// Usage stays unchanged at all three existing callers.
declare const fieldnote: {
	reload(): Promise<void>;
	authenticated(): Promise<void>;
	signOut(): Promise<void>;
};
void fieldnote.reload(); // The mount effect can call this twice.
void fieldnote.authenticated(); // Existing interrupt, cancel, then reload.
void fieldnote.signOut(); // Existing Stop, sign-out, New chat, then reload.

type ReloadFlight = Promise<void>;
type Ref<T> = { current: T };
declare function useRef<T>(initial: T): Ref<T>;

// This is a hook-local extraction, not a new exported hook or transport module.
function useFieldnoteSketch() {
	const reloadFlight = useRef<ReloadFlight | null>(null);
	const generation = useRef(0);
	const submission = useRef(0);

	function reload(): Promise<void> {
		if (reloadFlight.current) return reloadFlight.current;

		const request = (async () => {
			const ownGeneration = generation.current;
			const ownSubmission = submission.current;
			// TODO Keep the existing reload body, including setReady(false).
			// GET account. Check both captured counters before proceeding.
			// Signed-in uses its workspace. Guest GETs its session once.
			// Check both counters again before publishing any result.
			// Retain existing unavailable and catch behavior, with both guards.
			// Preserve the draft. Only a current success sets ready=true.
			void ownGeneration;
			void ownSubmission;
			throw new Error("not implemented");
		})().finally(() => {
			reloadFlight.current = null;
		});

		reloadFlight.current = request;
		return request;
	}

	// TODO Keep the existing effect. Cleanup still aborts preparing.current.
	// Cleanup and interrupt never clear reloadFlight or start another reload.
	// Keep generation and submission counters and their current meanings.
	// Keep authenticated, signOut, stop, reset, send, and getSession unchanged.
	return { reload };
}

void useFieldnoteSketch;
