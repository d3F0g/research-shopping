# One reload owns guest initialization

## Problem

Preserve the approved Fieldnote UI and genuine guest history. The supplied native reproduction proves that two anonymous session reads can set different guest cookies. React publication guards cannot undo those HTTP headers. At `dc61d3bae93fd347495ecbb5973d7877513ec91d`, `useFieldnote.ts` starts a fresh reload for each StrictMode effect execution. The cookie middleware in `src/server/app.ts` creates a session for each request without a recognized cookie.

## Usage

Keep all callers unchanged. The mount effect calls `reload()`. Account recovery awaits `reload()`. `authenticated()` and `signOut()` retain their existing sequences. Concurrent calls to `reload()` return the pending promise. A call after settlement starts a fresh read, including after failure. See `sketch.ts` for those call sites before the type sketch.

## Shape

Add one hook-local `Promise<void> | null` ref. Move the existing reload body inside the promise assigned to that ref. Return the pending promise before setting readiness or issuing HTTP requests. Clear the ref only in that promise's `finally`. This is pending work, never a cached account or conversation. Keep the current generation and submission checks at each existing publication boundary.

The single mounted hook owns the initial account-to-session transaction. StrictMode replays its effect with the same ref, so both effect executions use one transaction. No second anonymous session response exists to replace the cookie after the composer becomes ready. The first successful cookie is installed before fetch completes and before the hook enables sending. Subsequent ordinary turns therefore use that cookie. The first actor that could create the invalid state has changed, per **Fix Root Causes**.

The browser cookie is genuinely shared by requests within this app. The single pending transaction expresses exclusive ownership, per **Separate Before Serializing Shared State**. The ref has only idle and pending states, per **Model the Domain**. Keeping the existing `reload()` interface and leaving `api.ts`, server cookies, and research untouched follows **Laziness Protocol**.

## Lifecycle and account ownership

- StrictMode cleanup retains the pending reload. Keep its existing prepare cancellation. Aborting or clearing the reload in cleanup would admit another anonymous request and need a separate browser cancellation proof.
- Current errors still publish the existing unavailable state and retain the draft. `finally` releases the slot. Explicit recovery starts one fresh transaction. A failure never triggers an automatic retry. Sharing pending work rather than retaining its result follows **Make Operations Idempotent**.
- Generation and submission guards still reject stale success and failure. Do not replace submission with generation. Ordinary replies remain available during research.
- Auth transitions retain their current implementation. `AccountControl.tsx` exposes sign-in only after guest initialization, sign-out only after signed-in initialization, and Reload account only from unavailable. Each reachable transition therefore starts after its prior reload has settled. After authentication, `interrupt()` invalidates earlier work before cancel and the fresh reload. Sign-out performs Stop, sign-out, New chat, and then the fresh reload. No old initial read survives readiness.
- New chat and Stop retain their existing behavior. Do not clear the pending ref in either path. Their UI controls are unavailable before initialization completes. Research transport cancellation stays unchanged.

## Exact files

Change `src/client/useFieldnote.ts` only for production behavior. Update `tests/e2e/v2-chat.spec.ts` and `tests/helpers/browser-server.ts` for a native response-header gate and paired identity tests. Update `scripts/verify-personalization-browser.mjs` for equivalent account-transition preconditions. Add `tests/unit/useFieldnote.test.tsx` only for the pending-read lifecycle and publication guard cases that need direct hook control. Preserve the existing desktop and mobile screenshots and account-verifier assertions.

## Synthesis decision

Root owns the comparison. This independent candidate recommends hook-local admission. No other candidate or selection rubric was read.

## Tradeoffs and alternatives

- Accept waiting for the first read in exchange for one owner of guest initialization. A hung read already blocks initialization. This change adds no timeout policy.
- Accept the existing one-mounted-hook boundary. This is not browser-wide arbitration across tabs or separately mounted application roots. Each test context must retain independent cookies.
- Transport abort on StrictMode cleanup exposes cancellation and response-header timing to the caller. It needs proof for both pre-header and post-header cancellation, so it loses to preventing the duplicate dispatch.
- A module-level `getSession()` cache changes all guest reads, including post-research freshness. It hides more behavior than this defect requires and complicates auth-lifetime reasoning.
- Another response publication guard cannot change a browser cookie. Server identity deduplication by IP or another shared untrusted key would merge unrelated guests.

## Risks and next implementation step

Can a reachable current caller initiate authentication while a reload is pending? The inspected AccountControl branches prevent that. The owner must preserve this fact in account tests. If a future caller permits this overlap, it must explicitly invalidate and drain or replace the read before its fresh account reload. Do not silently join an obsolete transaction.

Implement the pending ref around the existing reload body, then prove the native cookie invariant and the current-error recovery pair before adapting stale-content tests.
