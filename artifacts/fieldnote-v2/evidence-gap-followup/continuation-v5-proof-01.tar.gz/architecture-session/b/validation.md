# Sketch validation

The 93-line sketch typechecks against the existing domain types with the command below. It ran from `/Users/josiahwong/Documents/research-shopping-v2` and exited 0.

```sh
./node_modules/.bin/tsc --noEmit --strict --skipLibCheck --target ES2022 --module ESNext --moduleResolution bundler --lib ES2022,DOM /tmp/fieldnote-session-architecture/b/sketch.ts
```

An initial invocation omitted `--strict` and failed in imported domain schemas because their inferred optionality depends on strict null checks. The corrected command above passed. Neither command wrote files.

No runtime reproduction was run. Native cancellation and cookie ownership remain acceptance gates. The supplied grounding and local source establish the failure mechanism and integration points, not proof of this candidate's runtime behavior.

The architectural screen found no new modules, public transport types, caches, queues, or duplicate state owners. One hook owns one replaceable transport attempt. The domain and wire contracts remain unchanged.
