# Abort the obsolete bootstrap before it can own a cookie

## Problem

Preserve Fieldnote's approved chat UI and genuine guest history. The supplied native reproduction shows that two anonymous session responses can mint different identities. Ignoring an old response in React does not prevent its Set-Cookie header from changing the browser's next request. Source `dc61d3bae93fd347495ecbb5973d7877513ec91d` has no owner for the account-to-session bootstrap transport.

## Usage

Mount and explicit account recovery still call `reload()`. Every call cancels its predecessor and owns both reads with one AbortController. Effect cleanup cancels that read. Authentication, sign-out, Stop, and New chat already pass through `interrupt()`, which also cancels it. An accepted send cancels a bootstrap before changing the submission counter. The research refresh passes its existing research signal to `getSession`.

The caller gets the same Promise<void> and the same conversation state. No component, layout, account callback, or server API changes.

## Shape and grounding

The data shape is one hook-local `AbortController | null`. `src/client/useFieldnote.ts:48` currently captures generation and submission but starts unowned fetches. `src/client/api.ts:7` already forwards AbortSignal into fetch and consumes its body. Only `getSession` omits that capability. `src/server/app.ts:181` legitimately creates a guest identity when the incoming cookie is absent or unknown. That remains server-owned.

StrictMode runs setup, cleanup, and setup before the initial account request completes. Cleanup aborts that first fetch. Its continuation checks signal ownership before it may start `/api/session`. Therefore the abandoned effect cannot issue the anonymous session read shown in the original reproduction. Replacement reloads also abort an already dispatched session fetch before another read starts. If headers arrived before the abort, the browser has already accepted that cookie before the replacement fetch starts. If headers have not arrived, native cancellation must prevent their later cookie effect. The latter is an explicit browser acceptance gate below.

Keep generation and submission comparisons unchanged in meaning. They reject snapshots superseded by research, conversation changes, and ordinary messages. Add signal ownership because replaced reads can have equal counters. Check ownership after both awaits and in catch. A current read failure remains an unavailable account with the existing recoverable error and typed draft. An aborted or stale failure changes nothing. Clear the ref only when it still identifies this owner, so an old finally cannot erase a newer request.

`Fix Root Causes` changes the fix from another state guard to cancellation of the transport that can set the cookie. `Model the Domain` gives each bootstrap exactly one controller for its whole lifetime. `Separate Before Serializing Shared State` identifies the browser's guest cookie as the shared write target, then removes obsolete writers. `Laziness Protocol` keeps ownership in the hook and uses the existing signal-aware API instead of adding a transport scheduler.

## Synthesis decision

Candidate B is submitted independently. Root chooses the base after comparing packages. This candidate deliberately favors exclusive cancellable ownership over sharing or queuing read results.

## Tradeoffs accepted and alternatives

- We accept that StrictMode may start and cancel an extra account read in exchange for keeping fresh reload semantics and no cache lifetime.
- We accept browser cancellation as a required transport contract. A native late-header test must prove that contract on the supported runtime before this design is accepted.
- A shared in-flight bootstrap can avoid duplicate transport. It requires explicit invalidation across authentication and independent consumers. This candidate instead gives each reload a fresh owned attempt.
- A getSession-only queue hides ordering but leaves cookie-issuing mutations outside its ownership. Expanding the queue to all requests would threaten free replies during research and Stop. This candidate adds no such queue.

## Exact implementation files

Modify `src/client/useFieldnote.ts` for the controller, lifecycle cleanup, interrupt, accepted-send cancellation, and research-refresh signal. Modify `src/client/api.ts` to add the optional `getSession` signal. Add paired native HTTP cases to `tests/e2e/v2-chat.spec.ts`, with a small server-side header gate in `tests/helpers/browser-server.ts` if needed. Add auth transition cases to `scripts/verify-personalization-browser.mjs`. No server application, styling, account schema, provider, billing, or credential edits.

## Paired acceptance

1. Run the actual Vite/Hono/StrictMode UI with a fresh isolated browser and default caching. Gate a server response before headers, without Playwright route.fetch. The old hook must reproduce the supplied cookie switch. With ownership, the abandoned read must be aborted or never reach the cookie endpoint. Record server request cookies and aborts plus the browser cookie. Send `hello`, type a fresh draft, release every late gate, and compare the exact authoritative message list before and after. Send `thanks` and reload. Both user messages and their assistant replies must remain. A second independent browser must receive a different guest identity.
2. Pair that with headers accepted before cancellation while the body is held. Replacement reads must use the installed identity. The abandoned body must never publish. This prevents crediting a test that only cancels requests before dispatch.
3. Preserve stale success and stale failure coverage for both account and session. Seed a real existing cookie for stale-content tests, then hold an obsolete read. Supersede it, submit an ordinary reply, and release success or failure. Assert the exact messages, draft, readiness, and absence of stale errors. Keep an old-hook red counterexample. Pair each stale failure with a current failure that disables send, retains the draft, and succeeds after one explicit recovery. Never require two uncancelled initial reads as the precondition.
4. Pair pending guest reads with sign-in, sign-out, Stop, New chat, and unmount. Release old headers and bodies after each transition. Assert account ownership, intended history, current draft, and no late error. Preserve no guest-history upload. Existing research cancellation, free replies during research, contextual constraints, desktop/mobile screenshots, and zero paid calls remain gates.

## Risks and next step

Can the supported Chromium transport still apply a header after a pre-header abort? Root's native paired test must settle this. Reject this candidate if it can. This package is design only and does not claim runtime proof.

Implement the two-file ownership change first, then run the native cookie and exact-history pairs before broader verification.
