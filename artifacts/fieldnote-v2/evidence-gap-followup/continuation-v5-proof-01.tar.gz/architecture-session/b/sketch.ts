// Usage in useFieldnote. Existing domain types and state setters are unchanged.
// Mount and explicit recovery both call reload().
// StrictMode cleanup aborts the owned read before its replacement starts.
// authenticated() and signOut() retain their existing interrupt() paths.

import type { AccountState } from "/Users/josiahwong/Documents/research-shopping-v2/src/domain/workspace";
import type { ConversationState } from "/Users/josiahwong/Documents/research-shopping-v2/src/domain/conversation";

declare function api<T>(path: string, body?: unknown, signal?: AbortSignal): Promise<T>;
declare function useRef<T>(initial: T): { current: T };
declare function useEffect(effect: () => (() => void), deps: unknown[]): void;
declare const generation: { current: number };
declare const submission: { current: number };
declare const preparing: { current: AbortController | null };
declare const active: { current: AbortController | null };
declare function setReady(value: boolean): void;
declare function setState(value: ConversationState): void;
declare function updateAccount(value: AccountState): void;
declare function setError(value: string): void;

// api.ts keeps its existing fetch and response.json implementation.
// Passing one signal owns headers and body consumption together.
function getSession(signal?: AbortSignal) {
	return api<{ state: ConversationState }>("/api/session", undefined, signal);
}

// These declarations stand inside useFieldnote, never at module scope.
const bootstrap = useRef<AbortController | null>(null);

async function reload(): Promise<void> {
	bootstrap.current?.abort();
	const owner = new AbortController();
	bootstrap.current = owner;
	const ownGeneration = generation.current;
	const ownSubmission = submission.current;
	const current = () =>
		!owner.signal.aborted &&
		ownGeneration === generation.current &&
		ownSubmission === submission.current;
	setReady(false);
	try {
		const next = await api<AccountState>("/api/account", undefined, owner.signal);
		if (!current()) return;
		if (next.status === "unavailable") {
			updateAccount(next);
			setError("Account persistence is unavailable. Reload your account before continuing.");
			return;
		}
		const nextState = next.status === "signed-in"
			? next.workspace.state
			: (await getSession(owner.signal)).state;
		if (!current()) return;
		updateAccount(next);
		setState(nextState);
		setError("");
		setReady(true);
	} catch {
		if (!current()) return;
		updateAccount({ status: "unavailable" });
		setError("The server is unavailable. Your draft is retained. Reload your account when it returns.");
	} finally {
		if (bootstrap.current === owner) bootstrap.current = null;
	}
}

useEffect(() => {
	void reload();
	return () => {
		bootstrap.current?.abort();
		preparing.current?.abort();
	};
}, []);

// Existing interrupt() retains all other statements.
function interrupt(): void {
	generation.current++;
	submission.current++;
	bootstrap.current?.abort();
	preparing.current?.abort();
	active.current?.abort();
	// Existing controller clearing and activity/resetting setters follow.
}

// Existing send() invalidates a read only after its current admission guard.
function acceptedSendPrefix(): void {
	bootstrap.current?.abort();
	// Existing prepare cancellation and submission increment follow.
}

// Existing research refresh uses its already owned transport signal.
async function researchRefresh(controller: AbortController) {
	return getSession(controller.signal);
}
