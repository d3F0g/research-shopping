# Issue 67 scorecard repair

The goal is useful source-backed shopping with an honest unchanged-scenario evaluation. This change repairs evaluator admission of the current authorized synthetic materials. It makes no product-usefulness claim.

The base is a45cac153f9bdafab9c9d7c2972f0889ef854799. The failing regression commit is 280b43404e1a6974debc0a8909059bbb105b00ba. The fixed candidate is 842c394c8477dd7d23a9a2dddf16f65dc9c00576 on fix/issue-64-current-scorecard.

Only evals/v2/scorecard.ts and evals/v2/tests/integrity.test.ts changed. The production fix replaces one import and one call with currentScenarioMaterial. The runner already uses that generator. The scorecard still authenticates the complete material object and hash, validates the full report, and excludes different historical materials from every paired transition and assessed denominator. No registry, version, schema, assertion or historical decoder changed.

## Reproduction and regression

At the unchanged base, the actual npm eval:scorecard command rejected the retained root current report with Changed V2 research material for FN-CU-001. red-cli.stdout and red-cli.stderr preserve that exit-1 failure.

The committed regression executes all sixty current scenarios through the actual runner CLI, guarded loopback Hono and SDK composition. It checks 140 observed turns, no infrastructure errors, no external requests and cleanup. It then executes the scorecard CLI and checks exact changed-material IDs, exclusion from transitions and assessed denominators, and unchanged report summaries and acceptance. Self-consistent payload and provenance forgeries for FN-CU-001 and unassigned FN-CU-002 pass generic report validation but must fail scorecard material authentication.

red-test.stdout and red-test.stderr retain the failing regression run. Its admission subtest fails before the fix. Its unassigned-material forgery subtest also fails because the old scorecard rejects FN-CU-001 before reaching the intended forged row. The same regression passes after the two-line source fix.

## Verification

All test commands ran with an empty environment plus PATH=/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin, EXA_RESEARCH_ENABLED=false, NODE_ENV=test and LC_ALL=C. Dependencies were copied from the owned root proof worktree, excluding .cache, .vite, .vite-temp and .tmp. No environment file, credential, persistent ledger, grant or private capture was read or copied. All research used local test composition with dynamic SDK import behind the offline network guard.

- npm run eval:test passed 40 tests, including the three new scorecard subtests and their parent test.
- npm run eval:typecheck passed.
- npm run eval:preservation verified all 389 preserved assets.
- npm run eval -- --out artifacts/playwright-results/scorecard-owner/current60 --gate critical --issue-drafts exited 0. All 60 cases and 140 turns executed. Results were 11 pass, 0 fail, 48 blocked and 1 unsupported. Critical failures and infrastructure errors were both zero. Acceptance remains inconclusive.
- npm run eval:scorecard with the frozen baseline and current60/report.json exited 0. The same command also accepted the root retained current report. Both reports list 57 unchanged material sets and exactly FN-CU-001, FN-RT-002 and FN-PQ-001 as different historical material. Those cases are outside all paired transitions. The 203 jointly assessed unchanged normative requirements remain descriptive across different application contracts.
- npm run eval:browser -- --out artifacts/playwright-results/scorecard-owner/strict-browser --mode strict exited 0. It reports 29 passing checks, 15 generated screenshots, cleanup true, no page errors and no denied requests. This run is automated browser evidence. Independent visual review remains the root reviewer's responsibility.
- git diff --check passed. preserved-paths.diff is empty. Application src tree 579b672ee1a8aef9f413f92a48f72954109cb7d8 is identical at e169be934f74fb61507b5c7b62c4aeaefc2106a8, the assigned base and the fixed candidate.

## Decisions and limits

Fix Root Causes changed the source of scorecard authentication to the same authorized composition the current runner executes. Laziness Protocol rejected a duplicate material-version registry. Model the Domain retained the existing contract, material and historical-equality structure. Boundary Discipline retained strict report and canonical-material checks. Test Behavior, Not Implementation led to the actual runner and scorecard CLI regression plus self-consistent forgery cases. Prove It Works required retained red evidence and exact-candidate CLI checks. Explain the Number kept changed materials outside paired counts and kept inconclusive synthetic results separate from shopping usefulness.

No application code, original public action, expectation, frozen material, frozen assertion or grader changed. No paid call, preview mutation, GitHub mutation, push or merge occurred. The proof does not establish live discovery, real product relevance, current prices, inventory, merchant authorization or semantic usefulness. Independent QA and security approval remain with the root.
