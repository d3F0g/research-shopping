# Issue 64 V5 application evidence

Fieldnote users need useful source-based prices and recommendations while keeping the approved chat UI and hard constraints. The implementation replaces the current price contract and preserves historical evidence. Application source is stable at `e169be934f74fb61507b5c7b62c4aeaefc2106a8`. The evaluator correction is `270e7d494d1e52d5fbd9ac6415d0775fd08bb2ae`; its `src` tree is identical. This is author implementation and offline verification, not live product acceptance. No paid provider call, private capture, private environment, ledger, grant, GitHub mutation or deployment was used.

## Commit lineage

- Base: `dc61d3bae93fd347495ecbb5973d7877513ec91d`.
- Original old-wire red: `8ae72618e0db97415354a7e4cf67a1085ea31f84`. Markdown/prose source prices and the actual research route failed before the new wire existed. The separate new-schema failures were not counted as reproductions of the old parser defect. See `red.log`, `original-red-repro.ts.txt`, and `old-wire-material.ts`.
- Initial V5 implementation: `073bbcdebcec5453ae32d4f2f3dae878234b7967`.
- Session dependency mapping: `fa335ea` → `ac61d28`; `2ae2941` → `1505c1e`; `aeb6f1` → `744685c`. Cherry-picks were clean. `src/client/useFieldnote.ts` and `src/client/api.ts` remain byte-identical to `2ae29416925765f0aa8089e82266570c73544fc3`.
- Combined integration: `8ae151460143b515a9ee2ab61ca2bd30361b36ed`.
- Shared non-authorizing subject alarms and explicit current evaluation composition: `e169be934f74fb61507b5c7b62c4aeaefc2106a8`.
- Evaluator monetary provenance mapping: `270e7d494d1e52d5fbd9ac6415d0775fd08bb2ae`.

## Result and boundaries

Native answer revision is 2, evidence semantics 5 and workspace storage 5. Intent and response-envelope revisions remain 2. One versioned domain owner recomputes monetary occurrences, source binding, review coverage, independent alarms, applicability, exact integer budget bounds, hard-fit eligibility and choice consistency during both projection and storage validation. Native assessments cannot supply usableMoney or applicability.

Each retained source stores its text and money inventory once. Native quote/role groups reference uniquely bound contiguous quotations; the server derives their occurrence IDs and requires exact once-only coverage per product. A selected witness identifies one scalar amount and its explicit currency. Bare dollars remain unresolved. Reviews must cite their own source, including nonmonetary sources. Attribution, purchase basis, conditions, support quotations and derived adverse context retain distinct provenance.

The old positive English-price grammar and current catalog fallback were removed. Known buyer restrictions, taxes, shipping extras, purchase quantities, installments, ranges, conditional prices, explicit variant scope and competing selected-product prices remain independent refusal alarms even with optimistic native statuses, empty conditions and favorable reference roles. Ordinary prose, Markdown, arbitrary selected variants and complete long sources qualify without a category or positive-phrase registry.

Unknown adjacent headings, table labels and ordinary prose subjects are not contradictions merely because they differ from a product name. One shared bounded rule treats an unmatched letter-and-digit identifier as uncertain attribution, and explicit model/variant markers as a refusal condition. Monetary spans are masked before identifier detection. This does not infer a model family. It can conservatively flag a catalogue or certification-like identifier, and it cannot establish semantic entailment. Generic one-unit syntax has no product-noun list and does not exempt `one AX2`.

Literal containment proves provenance, not product truth, semantic relevance or merchant authority. The source-based AI interpretation remains labeled. Stock, delivery and merchant price remain unverified. Unseen semantic misclassification still requires real provider and human review.

Actual V2, V3 and V4 request, question, preference and response contracts are frozen explicitly. Only active preferences migrate. Stored messages, quotations and historical requests remain unchanged; stale prepared operations are interrupted. Historical research cannot regain current recommendation eligibility through free follow-ups.

The approved official shadcn/AI Elements layout, header, centered chat, bottom composer and theme persistence remain. Cards and free held replies share the price view. Repeated quoted passages in held replies are referenced after their first complete quotation rather than duplicated until the expanded reply falls back to its brief form.

## Bounded representability

`actual-serialized-sizes.json` records the actual projector and workspace result for an invented eight-source fixture with monetary counts `[6,3,2,88,39,3,34,6]` (181 total):

- 75,202 serialized answer characters.
- 163,041 serialized snapshot UTF-8 bytes.
- 163,517 serialized workspace UTF-8 bytes.
- Three products, each with 11 native groups and complete coverage of all 181 source occurrences.

The suite also exercises exactly 10 sources, 24 aggregate groups and 8 aggregate conditions, equivalent object/string answers, multibyte source text and UTF-16 offsets, and oversized object/string answers and multibyte workspaces. The 128,000-character answer and 256 KiB workspace limits remain. Oversized complete evidence is refused without trimming adverse text. These fixtures prove bounded representability, not actual model compliance.

## Verification

All commands ran inside this worktree with `EXA_RESEARCH_ENABLED=false`. Browser/account/evaluation commands used an allowlisted child environment with fake fixture keys and owned loopback services. Playwright and the project skill use API 3390/web 5490; account/PostgreSQL helpers allocate their own ports and temporary clusters. The PostgreSQL harness sets a fixed `LC_ALL=C`; the first restricted-environment startup failure and its cause were retained, and its known failed cluster was confirmed stopped before removal.

| Command | Result / evidence |
| --- | --- |
| `EXA_RESEARCH_ENABLED=false npx vitest run` | 582 passed, 19 files; `unit-api-final-subject.log` |
| `npm run typecheck` | Passed |
| `npm run eval:typecheck` | Passed |
| `npm run build` | Passed at e169 app source; `build-candidate-final.log`. Existing 500 kB chunk-size advisory remains. |
| `PLAYWRIGHT_API_PORT=3390 PLAYWRIGHT_WEB_PORT=5490 npm run test:e2e` | 31 passed at e169; `e2e-candidate-final.log` |
| `npm run eval:test` | 36 passed at 270e7d4; `eval-test-projection-fixed.log` |
| `npm run test:postgres` | 28 passed; final candidate rerun recorded in `postgres-candidate.log` |
| `npm run verify:accounts:browser` | Passed at 270e7d4. Desktop/mobile signup, persistence, isolation, deletion, stale bootstrap/Stop ownership, draft retention and actual SDK body cancellation; `accounts-browser-candidate.log`, `accounts/` |
| `npm run verify:accounts:restart` | API/PostgreSQL restart preserves typed currency draft, both bounds and messages; `accounts-restart-final.log` |
| `npm run verify:accounts:crash` | Process crash, duplicate replay, conservative fixture reservation and recovery passed; `accounts-crash-final.log` |
| `npm run verify:evidence:history` | Passed at 270e7d4 with cleanup true. Desktop/mobile V2/V3/V4 → V5 message equality, stale prepared-action interruption, account isolation and PostgreSQL/API restart; `history-browser-candidate.log`, `history-browser/` |
| `npm run eval:browser -- --out artifacts/issue-64-price-v5/eval-browser-final --mode strict` | Passed, 15 screenshots; `eval-browser-final/proof.json` |
| `npm run verify:registry` | 18 official component files unchanged |
| `npm run eval:preservation` | 389 committed preservation assets unchanged |
| Project verification skill | Original run preserved in `verification-skill/`; stale first-quotation selector failed because condition quotations precede identity quotations. The scoped correction is owned by the verification owner under separate Issue 66. Root integrated its patch at 347f3a17bd5881918f49edd361f4cd4527ae832c. No skill change was cherry-picked into this application branch; that independent skill result belongs to root and its owner. |

Meaningful negative coverage includes optimistic native buyer/total/variant/competing-price reports, wrong/partial/overlapping/uncounted groups, wrong-source review support, lost source context and actual cuts, forged stored inventories, spans, amounts, currencies, alarms, applicability and choice. Real SDK tests preserve exact request fields, Draft7 schema, one-call bounds, malformed/error boundaries and actual header/body cancellation. No hidden repair operation was added.

The desktop/mobile current-price browser journey shows three invented watch variants with SGD 437/457/487, a computed eligible choice, an independent annual-club restriction appended to a retained source, and free held comparison/detail/best follow-ups with zero additional SDK calls. The optimistic restricted counterpart retains the source amount and blocker, with no compliant choice.

## Evaluation outcomes retained honestly

Three distinct runs are preserved:

1. `frozen-eval-final/`: all original native1 materials unchanged; 60 executed, 10 pass, 3 fail, 46 blocked, 1 unsupported, zero infrastructure/critical failures. The three positive native1 responses are rejected under current native2.
2. `current-composed-eval/`: separate explicit V5 synthetic materials only for FN-CU-001, FN-RT-002 and FN-PQ-001; 14 critical legacy-projection failures across those three cases exposed missing bound price support offsets and the missing monetary quotation. This failed report is preserved.
3. `current-composed-eval-projection-fixed/`: 60 executed, 11 pass, zero fail, 48 blocked, 1 unsupported, zero infrastructure/critical failures; acceptance **INCONCLUSIVE**. All 27 assessed price/citation checks pass; research usefulness, semantic relevance and user experience remain unassessed.

The compatibility projection now preserves attribution and monetary witness quotations separately with actual native wording, origin field and bound offsets. Amount/currency come only from applicable usableMoney, never the first observation or a range endpoint. Offset, amount, currency and borrowed-quotation mutations still fail the unchanged frozen checks. Whitespace gaps are explicit, and a forged projected response cannot hide behind that compatibility gap. Original corpus, normative assertions, baseline artifacts and native1 material remain unchanged. The separately authored V5 composition is test-only; normal Exa handling never repairs old wire data.

## Visual inspection and limits

Inspected author screenshots include `usefulness-browser/1440-prices-dark.png`, `usefulness-browser/390-prices-dark.png`, `usefulness-browser/390-buyer-restriction.png`, `history-browser/390-literal-evidence.png`, and desktop/mobile saved-account research in `accounts/`. The initial useful answer and first product price remain visible, long comparisons scroll within the conversation, evidence is readable, and the composer remains accessible. Failed image previews do not become product-image claims. Independent visual QA and security review remain root-owned gates.

No fixture, green build, valid schema, source count or offline replay establishes live shopping usefulness. Actual Exa compliance with the grouped contract and live relevance/price/recommendation quality still need future authorized human proof. This work did not consume or inspect a live allowance.

## Principles that changed decisions

- **Model the Domain:** separate absent/observed/applicable price states and a single versioned validator replace nullable prices plus duplicated parser rules.
- **Boundary Discipline:** native semantic claims stay source-based AI; literal binding, exact money, own-source review and stored-state checks run at the application boundary.
- **Fix Root Causes:** ordinary source formats now use a new structured contract rather than repairing old bare-dollar quotations or adding positive-price/category dictionaries.
- **Sequence Work into Verifiable Units:** the actual old-wire red preceded implementation; session commits were integrated only after an owned clean checkpoint; evaluator defects retained their failed reports before correction.
- **Test Behavior, Not Implementation:** actual Hono/SDK/browser/PG paths, optimistic adverse pairs and stored-forgery mutations test outcomes beyond schema acceptance.
- **Prove It Works:** exact-source command results and inspected desktop/mobile captures are separate from independent review and live acceptance.

## Sealed owner evidence handoff

Final application/evaluator head remains `270e7d494d1e52d5fbd9ac6415d0775fd08bb2ae`. Final account browser, history browser and PostgreSQL reruns exited zero at that head. The app `src` tree matches e169be9 exactly. The two client transport files match 2ae2941 exactly. There are no tracked modifications. API 3390 and web 5490 have no listening process after verification.

The local `owner-evidence-manifest.json` records every file, size and SHA-256 in these sealed directories, including ignored logs. Its own bytes are excluded to avoid a recursive hash. Root owns archive creation and public packaging. No broad artifact commit was made.

- `artifacts/issue-64-price-v5/` contains this report, implementation/red evidence, all three evaluation outcomes, measured sizes, API/build/E2E/account/history logs, browser proofs and the original failed skill run.
- `artifacts/issue-65-bootstrap-transport/` contains native session ownership proof and desktop/mobile captures produced by the combined E2E run.
- `artifacts/fieldnote-v4/e2e/` contains current combined E2E captures under the existing test output path, including held replies at desktop, mobile and short mobile sizes. The directory name is historical and does not label their current evidence version.

The failed reports remain available for comparison. No private capture, credential file, live provider response or billing record was copied into these directories. All research proof was explicitly composed synthetic data.
