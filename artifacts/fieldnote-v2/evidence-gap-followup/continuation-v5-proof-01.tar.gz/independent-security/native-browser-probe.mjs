import assert from 'node:assert/strict';
import { chromium, expect } from '@playwright/test';
import { writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
const base = 'http://127.0.0.1:5898';
const out = 'artifacts/playwright-results/security';
const browser = await chromium.launch({ headless: true });
const rows = [];
const sessionCookie = async (context) => (await context.cookies()).find((c) => c.name === 'fieldnote-session')?.value ?? null;
async function proof(phase) {
  const context = await browser.newContext();
  await context.route('**/*', (route) => route.request().url().startsWith(base) ? route.continue() : route.abort());
  const page = await context.newPage();
  const control = async (data) => (await (data ? page.request.post(`${base}/api/test-session-control`, { data }) : page.request.get(`${base}/api/test-session-control`))).json();
  const state = async () => page.evaluate(async () => (await fetch('/api/session?session-proof=independent')).json());
  const view = async () => JSON.parse(await page.getByTestId('state').innerText());
  try {
    await control({ action: 'reset' });
    await control({ action: 'arm', phase });
    await page.goto(`${base}/tests/helpers/session-lifecycle.html`);
    await expect.poll(async () => (await control()).gate?.entered).toBe(true);
    const id = (await control()).events.find((e) => e.event === 'held').id;
    if (phase === 'body') await expect.poll(() => sessionCookie(context)).not.toBeNull();
    const initialCookie = await sessionCookie(context);
    if (phase === 'headers') assert.equal(initialCookie, null);
    await page.getByLabel('Fixture draft', { exact: true }).fill(`Fixture typed before ${phase} abort`);
    await page.getByRole('button', { name: 'Fixture reload', exact: true }).click();
    await expect.poll(async () => (await control()).events.some((e) => e.id === id && e.event === 'aborted')).toBe(true);
    await expect(page.getByRole('button', { name: 'Fixture send', exact: true })).toBeEnabled();
    const owner = await sessionCookie(context);
    assert(owner);
    if (phase === 'body') assert.equal(owner, initialCookie);
    await expect(page.getByLabel('Fixture draft', { exact: true })).toHaveValue(`Fixture typed before ${phase} abort`);
    const send = async (message) => { await page.getByLabel('Fixture draft', { exact: true }).fill(message); await page.getByRole('button', { name: 'Fixture send', exact: true }).click(); };
    await send('hello');
    await expect.poll(async () => (await view()).state.messages.length).toBe(2);
    const before = (await state()).state;
    await page.getByLabel('Fixture draft', { exact: true }).fill('Fixture draft preserved across late release');
    await control({ action: 'release' });
    await expect.poll(async () => (await control()).events.some((e) => e.id === id && e.event === 'released')).toBe(true);
    assert.equal(await sessionCookie(context), owner);
    assert.deepEqual((await state()).state, before);
    assert.deepEqual((await view()).state, before);
    await expect(page.getByLabel('Fixture draft', { exact: true })).toHaveValue('Fixture draft preserved across late release');
    assert.equal((await view()).error, '');
    await send('thanks');
    await expect.poll(async () => (await view()).state.messages.length).toBe(4);
    const final = (await state()).state;
    assert.deepEqual(final.messages.map((m) => m.text), ['hello', 'Hi. What are you looking to buy?', 'thanks', "You're welcome. Tell me what you would like to change."]);
    await page.reload();
    await expect.poll(async () => (await view()).state.messages).toEqual(final.messages);
    assert.equal(await sessionCookie(context), owner);
    rows.push({ name: `native ${phase} cancellation`, pass: true, before, final, installedIdentityPreserved: phase === 'body' ? owner === initialCookie : null, lateCookieIgnored: true, events: (await control()).events });
  } catch (error) { await writeFile(`${out}/native-${phase}-failure.json`, JSON.stringify({ view: await view(), server: await state(), events: await control() }, null, 2)); throw error; } finally { await control({ action: 'release' }); await context.close(); }
}
try {
  for (const phase of ['headers', 'body']) await proof(phase);
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  await context.route('**/*', (route) => route.request().url().startsWith(base) ? route.continue() : route.abort());
  const page = await context.newPage();
  try {
    await page.goto(base);
    const send = page.getByRole('button', { name: 'Send message', exact: true });
    const input = page.getByRole('textbox', { name: 'Message', exact: true });
    await expect(send).toBeDisabled();
    await expect(page.getByRole('button', { name: 'New chat', exact: true })).toBeEnabled();
    await input.fill('a price v5 fixture quartz wristwatch between SGD400 and500');
    await send.click();
    await expect(page.getByText('Fixture Meridian Watch Q17 steel', { exact: true }).first()).toBeVisible();
    const read = async () => page.evaluate(async () => (await fetch('/api/session?session-proof=independent')).json());
    await expect.poll(async () => (await read()).state.messages.some((m) => m.research)).toBe(true);
    const before = (await read()).state;
    const snapshot = before.messages.find((m) => m.research).research;
    assert.equal(snapshot.evidenceVersion, 5);
    const stats = await page.request.get(`${base}/api/test-stats`).then((r) => r.json());
    await input.fill('Show me more details.'); await send.click();
    await expect.poll(async () => (await read()).state.messages.length).toBe(before.messages.length + 2);
    const final = (await read()).state;
    assert.deepEqual(final.messages.slice(0, before.messages.length), before.messages);
    assert.equal((await page.request.get(`${base}/api/test-stats`).then((r) => r.json())).calls, stats.calls);
    for (const link of await page.locator('a[target="_blank"]').all()) { const href = await link.getAttribute('href'); assert(href.startsWith('https://')); assert.match(await link.getAttribute('rel'), /noopener/); assert.match(await link.getAttribute('rel'), /noreferrer/); }
    await page.screenshot({ path: `${out}/research-desktop.png` });
    await page.setViewportSize({ width: 390, height: 844 });
    await page.screenshot({ path: `${out}/research-mobile.png` });
    const isolated = await browser.newContext();
    try { const other = await isolated.newPage(); await other.goto(base); await expect(other.getByRole('button', { name: 'New chat', exact: true })).toBeEnabled(); const otherState = await other.evaluate(async () => (await fetch('/api/session?session-proof=independent')).json()); assert.deepEqual(otherState.state.messages, []); assert.notEqual(await sessionCookie(isolated), await sessionCookie(context)); }
    finally { await isolated.close(); }
    rows.push({ name: 'actual UI free held reply and isolation', pass: true, evidenceVersion: snapshot.evidenceVersion, sourceLinksSafe: true, providerCallsBefore: stats.calls, providerCallsAfter: (await page.request.get(`${base}/api/test-stats`).then((r) => r.json())).calls, messages: final.messages.map((m) => ({ id: m.id, role: m.role, text: m.text })), independentContextEmpty: true });
  } finally { await context.close(); }
} catch (error) { rows.push({ name: 'browser failure', pass: false, error: String(error) }); process.exitCode = 1; }
finally { await writeFile(`${out}/native-browser-results.json`, JSON.stringify({ base: 'dc61d3bae93fd347495ecbb5973d7877513ec91d', head: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), browser: browser.version(), synthetic: true, liveCalls: 0, rows }, null, 2)); await browser.close(); }
console.log(JSON.stringify(rows.map(({ name, pass, error }) => ({ name, pass, error })), null, 2));
