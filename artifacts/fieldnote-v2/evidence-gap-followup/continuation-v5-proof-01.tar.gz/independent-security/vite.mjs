import { createServer } from 'vite';
const server = await createServer({ envFile: false, server: { host: '127.0.0.1', port: 5898, strictPort: true } });
await server.listen();
