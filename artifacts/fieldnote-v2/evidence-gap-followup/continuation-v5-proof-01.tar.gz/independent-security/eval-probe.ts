import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { currentScenarioMaterial } from '../../../evals/v2/materials';
import { offlineNetwork } from '../../../evals/network';
import { grade } from '../../../evals/v2/assertions';
import { materialPayloadHash } from '../../../evals/hash';
import type { Scenario } from '../../../evals/frozen-v4/contracts';
const scenario: Scenario = { id: 'fixture-security-current-projection', revision: 1, category: 'evidence-honesty', title: 'Fixture independent V5 projection forgery', provider: 'supported', actions: [{ kind: 'message', text: 'Find a powerbank under SGD40' }], expectedBehavior: ['Keep literal money and native attribution distinct'], milestones: [], review: { status: 'author-drafted', reference: 'Independent synthetic security probe' } };
const rows = [];
for (const whitespace of [false, true]) {
  const material = currentScenarioMaterial('supported', 'FN-CU-001');
  if (whitespace) { (material.body as any).answer.products[0].price.moneySupport.quote = 'SGD\t 35.00'; material.sha256 = materialPayloadHash(material); }
  const guard = offlineNetwork();
  try {
    const { observe } = await import('../../../evals/v2/adapter');
    const observed = await observe(scenario, material, guard);
    const raw = observed.rawTurns[0]!.response;
    assert(raw?.kind === 'research');
    const rawPrice = raw.research.products[0]!.priceEvidence;
    assert.equal(rawPrice.state, 'applicable');
    const normalized = (observed.turns[0]!.response as any).research.products[0].price;
    assert.equal(normalized.assessment.support.length, 2);
    assert.equal(normalized.assessment.support[1].origin.field, 'price.moneySupport');
    assert.equal(normalized.assessment.support[1].quote, rawPrice.report!.moneySupport.quote);
    const normalGrade = grade(scenario, observed);
    assert.equal(normalGrade.find((row) => row.id === 'quote-containment:fixture-current-0')!.status, whitespace ? 'blocked' : 'pass');
    assert.equal(normalGrade.find((row) => row.id === 'native-complete-provenance:fixture-current-0')!.status, 'pass');
    for (const mutation of ['offset', 'currency', 'amount', 'replace-money-with-attribution', 'remove-witness']) {
      const forged = structuredClone(observed);
      const price = (forged.turns[0]!.response as any).research.products[0].price;
      if (mutation === 'offset') price.assessment.support[1].start++;
      if (mutation === 'currency') price.currency = 'USD';
      if (mutation === 'amount') price.amount = 1;
      if (mutation === 'replace-money-with-attribution') price.assessment.support[1] = structuredClone(price.assessment.support[0]);
      if (mutation === 'remove-witness') price.assessment.support.pop();
      const checks = grade(scenario, forged);
      assert(checks.some((row) => row.status === 'fail' && row.critical), `${mutation} must remain a critical failure`);
      rows.push({ whitespace, mutation, criticalFailures: checks.filter((row) => row.status === 'fail' && row.critical).map((row) => row.id) });
    }
    assert.equal(observed.network.externalRequests, 0);
  } finally { guard.close(); }
}
writeFileSync('artifacts/playwright-results/security/eval-probe-results.json', JSON.stringify({ head: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), synthetic: true, cases: rows }, null, 2));
console.log(JSON.stringify({ cases: rows.length, passed: rows.length, liveCalls: 0 }));
