import hashlib, io, json, pathlib, subprocess, tarfile
root = pathlib.Path('artifacts/fieldnote-v2/evidence-gap-followup')
manifest = json.loads((root / 'publication-review-receipts-manifest.json').read_text())
data = (root / manifest['archive']).read_bytes()
assert len(data) == manifest['bytes']
assert hashlib.sha256(data).hexdigest() == manifest['sha256']
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    members = {member.name: member for member in archive.getmembers()}
    assert len(members) == 60
    assert all(member.isfile() and not pathlib.PurePosixPath(member.name).is_absolute() and '..' not in pathlib.PurePosixPath(member.name).parts for member in members.values())
    indexed = {item['path']: item for item in manifest['members']}
    assert set(members) == set(indexed)
    for name, member in members.items():
        payload = archive.extractfile(member).read()
        assert len(payload) == indexed[name]['bytes']
        assert hashlib.sha256(payload).hexdigest() == indexed[name]['sha256']
    retired = manifest['retiredLoosePaths']
    assert len(retired) == 53
    for name in retired:
        original = subprocess.check_output(['git', 'show', '7d503ce^:' + name])
        assert archive.extractfile(members[name]).read() == original
        assert not pathlib.Path(name).exists()
    old_tar = subprocess.check_output(['git', 'show', '7d503ce^:' + str(root / 'publication-review-receipts.tar.gz')])
    old_manifest = subprocess.check_output(['git', 'show', '7d503ce^:' + str(root / 'publication-review-receipts-manifest.json')])
    assert archive.extractfile(members['preserved/original-publication-review-receipts.tar.gz']).read() == old_tar
    assert archive.extractfile(members['preserved/original-publication-review-receipts-manifest.json']).read() == old_manifest
    with tarfile.open(fileobj=io.BytesIO(old_tar), mode='r:gz') as original:
        originals = original.getmembers()
        assert len(originals) == 5
        for member in originals:
            assert archive.extractfile(members[member.name]).read() == original.extractfile(member).read()
result = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'members': 60, 'retiredFilesByteIdentical': 53, 'originalReportsByteIdentical': 5, 'nestedArchiveAndManifestExact': True, 'safeRegularRelativeMembers': True, 'sha256': manifest['sha256']}
pathlib.Path('artifacts/playwright-results/security/archive-results.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
