import collections
import hashlib
import io
import json
import pathlib
import re
import stat
import subprocess
import tarfile
import zipfile

ROOT = pathlib.Path('/tmp/fieldnote-v5-publication-security')
OUT = pathlib.Path('/tmp/fieldnote-v5-publication-security-report')
BASE = '347f3a17bd5881918f49edd361f4cd4527ae832c'
HEAD = 'a45cac153f9bdafab9c9d7c2972f0889ef854799'
PRE_RETIRE = '7d503ce^'
DIR = ROOT / 'artifacts/fieldnote-v2/evidence-gap-followup'
report = {'base': BASE, 'head': HEAD, 'failures': [], 'archives': [], 'credentialCandidates': [], 'sensitivePathCandidates': [], 'networkHosts': {}, 'objects': 0, 'recursiveBytes': 0, 'maxObjectBytes': 0, 'maxDepth': 0, 'fileKinds': collections.Counter()}
hosts = collections.Counter()
records = {}

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def fail(kind, path):
    report['failures'].append({'kind': kind, 'path': path})

def safe_path(name):
    p = pathlib.PurePosixPath(name)
    return bool(name) and not p.is_absolute() and '..' not in p.parts and '\\' not in name and not re.match(r'^[A-Za-z]:', name) and '\x00' not in name

patterns = {
    'private_key': re.compile(rb'-----BEGIN (?:RSA |OPENSSH |EC |DSA )?PRIVATE KEY-----'),
    'aws_key': re.compile(rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),
    'github_token': re.compile(rb'\b(?:gh[pousr]_[A-Za-z0-9_]{30,}|github_pat_[A-Za-z0-9_]{40,})\b'),
    'openai_key': re.compile(rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{30,}\b'),
    'slack_token': re.compile(rb'\bxox[baprs]-[A-Za-z0-9-]{20,}\b'),
    'jwt': re.compile(rb'\beyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{10,}\b'),
    'authorization': re.compile(rb'(?i)(?:bearer|basic)\s+[A-Za-z0-9_+/=-]{16,}'),
    'key_assignment': re.compile(rb'''(?i)(?:api[_-]?key|exa_api_key|openai_api_key|access[_-]?token|client[_-]?secret)["']?\s*[:=]\s*["']([^"'\r\n]{8,})["']'''),
}
synthetic = re.compile(rb'(?i)(fake|fixture|synthetic|test|dummy|example|placeholder|not[-_ ]?real|local[-_]|redacted|process\.env|apiKey|api_key|options\.|config\.|settings\.|env\.)')

def scan(name, data, depth=0):
    report['objects'] += 1
    report['recursiveBytes'] += len(data)
    report['maxObjectBytes'] = max(report['maxObjectBytes'], len(data))
    report['maxDepth'] = max(report['maxDepth'], depth)
    if len(data) > 512_000_000 or report['recursiveBytes'] > 3_000_000_000 or depth > 5:
        raise RuntimeError('Archive inspection capacity exceeded')
    report['fileKinds'][pathlib.PurePosixPath(name).suffix or '<none>'] += 1
    if re.search(r'(?i)(?:^|/)(?:\.env(?:\.|$)|[^/]*(?:private[-_]capture|operator[-_]db|grant\.json|ledger\.json)|[^/]*\.(?:sqlite|sqlite3|db|pem|key))$', name):
        report['sensitivePathCandidates'].append(name)
    for kind, rx in patterns.items():
        for m in rx.finditer(data):
            value = m.group(1) if kind == 'key_assignment' else m.group()
            report['credentialCandidates'].append({'path': name, 'kind': kind, 'offset': m.start(), 'valueSha256': sha(value), 'length': len(value), 'syntheticMarkerInValue': bool(synthetic.search(value))})
    for m in re.finditer(rb'https?://([^/\s"<>\\]+)', data):
        h=m.group(1).decode('utf-8','replace')
        if len(h)<180:
            hosts[h]+=1
    if data.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            seen=set()
            for ent in z.infolist():
                item=name+'!'+ent.filename
                if not safe_path(ent.filename): fail('unsafe-zip-path',item)
                if ent.filename in seen: fail('duplicate-zip-path',item)
                seen.add(ent.filename)
                mode = ent.external_attr >> 16
                if stat.S_ISLNK(mode): fail('zip-symlink',item)
                if ent.flag_bits & 1: fail('encrypted-zip',item)
                if ent.file_size > 512_000_000: raise RuntimeError('Oversize zip member')
                if not ent.is_dir(): scan(item,z.read(ent),depth+1)
    elif data.startswith(b'\x1f\x8b'):
        try:
            t=tarfile.open(fileobj=io.BytesIO(data),mode='r:gz')
        except tarfile.ReadError:
            fail('unread-gzip',name)
            return
        with t:
            seen=set()
            for ent in t:
                item=name+'!'+ent.name
                if not safe_path(ent.name): fail('unsafe-tar-path',item)
                if ent.name in seen: fail('duplicate-tar-path',item)
                seen.add(ent.name)
                if not ent.isfile() and not ent.isdir(): fail('nonregular-tar-entry',item)
                if ent.mode & 0o6000: fail('setid-tar-entry',item)
                if ent.size > 512_000_000: raise RuntimeError('Oversize tar member')
                if ent.isfile(): scan(item,t.extractfile(ent).read(),depth+1)

changed = git('diff','--name-only',BASE,HEAD).decode().splitlines()
allowed = ('.codex/pstack-runs/', 'docs/', 'artifacts/')
runtime_changes=[p for p in changed if not p.startswith(allowed)]
report['metadataDiffPaths']=changed
report['runtimeChangedPaths']=runtime_changes
if runtime_changes: fail('runtime-source-changed',','.join(runtime_changes))
report['aToBPaths']=git('diff','--name-only','1a39ab12329fdd0ff727519bbc4b16ed085014e2',HEAD).decode().splitlines()
if report['aToBPaths'] != ['.agents/skills/verify-research-shopping/scripts/smoke.mjs']: fail('unexpected-a-to-b-delta','git')
report['runtimeTrees']={}
for p in ['src','tests','evals','scripts','.agents','.github','package.json','package-lock.json','vite.config.ts','playwright.config.ts','tsconfig.json']:
    a=git('ls-tree',BASE,'--',p).decode().strip()
    b=git('ls-tree',HEAD,'--',p).decode().strip()
    report['runtimeTrees'][p]={'base':a,'head':b,'equal':a==b}
    if a != b: fail('runtime-tree-mismatch',p)

for manifest_name in ['continuation-v5-proof-manifest.json','publication-review-receipts-manifest.json']:
    raw=(DIR/manifest_name).read_bytes()
    doc=json.loads(raw)
    ars=doc.get('archives') or [{'path':doc['archive'],'bytes':doc['bytes'],'sha256':doc['sha256'],'members':doc['members']}]
    for ar in ars:
        p=DIR/ar['path']
        blob=p.read_bytes()
        summary={'path':ar['path'],'bytes':len(blob),'sha256':sha(blob),'members':0,'uncompressedBytes':0}
        if len(blob)!=ar['bytes'] or sha(blob)!=ar['sha256']: fail('archive-integrity',ar['path'])
        if len(blob)>=100_000_000:fail('archive-exceeds-100MB',ar['path'])
        expected={m['path']:m for m in ar['members']}
        if len(expected)!=len(ar['members']): fail('manifest-duplicate',manifest_name)
        with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as t:
            actual=set()
            for ent in t:
                if not ent.isfile(): fail('top-nonregular-entry',ent.name); continue
                data=t.extractfile(ent).read()
                records[ent.name]=data
                actual.add(ent.name)
                summary['members']+=1
                summary['uncompressedBytes']+=len(data)
                m=expected.get(ent.name)
                if m is None or len(data)!=m['bytes'] or sha(data)!=m['sha256']:fail('member-integrity',ent.name)
            if actual!=set(expected):fail('manifest-set-mismatch',ar['path'])
        report['archives'].append(summary)
        scan(ar['path'],blob)

old_doc_raw=git('show',PRE_RETIRE+':artifacts/fieldnote-v2/evidence-gap-followup/publication-review-receipts-manifest.json')
old_doc=json.loads(old_doc_raw)
old_archive=git('show',PRE_RETIRE+':artifacts/fieldnote-v2/evidence-gap-followup/publication-review-receipts.tar.gz')
retired=git('diff','--diff-filter=D','--name-only',PRE_RETIRE,'7d503ce').decode().splitlines()
report['retiredPaths']=retired
for p in retired:
    original=git('show',PRE_RETIRE+':'+p)
    if records.get(p)!=original:fail('retired-file-not-preserved',p)
report['originalReportsPreserved']=0
for m in old_doc['members']:
    data=records.get(m['path'])
    if data is None or sha(data)!=m['sha256'] or len(data)!=m['bytes']:fail('original-report-not-preserved',m['path'])
    else: report['originalReportsPreserved']+=1
report['originalArchiveCopies']=[p for p,b in records.items() if b==old_archive]
report['originalManifestCopies']=[p for p,b in records.items() if b==old_doc_raw]
if not report['originalArchiveCopies']:fail('original-archive-not-preserved','preserved')
if not report['originalManifestCopies']:fail('original-manifest-not-preserved','preserved')
v5=json.loads((DIR/'continuation-v5-proof-manifest.json').read_text())
report['ownerSealMatches']=[]
for seal in v5['ownerSeals']:
    paths=[p for p,b in records.items() if sha(b)==seal['sha256']]
    report['ownerSealMatches'].append({'scope':seal['scope'],'sha256':seal['sha256'],'paths':paths})
    if not paths:fail('owner-seal-not-present',seal['scope'])
hist=json.loads((DIR/'history-initial-readiness-manifest.json').read_text())
oldhist=json.loads(git('show',PRE_RETIRE+':artifacts/fieldnote-v2/evidence-gap-followup/history-initial-readiness-manifest.json'))
report['priorHistoryManifestUnchangedExceptDocumentation']={k:v for k,v in hist.items() if k!='documentation'}=={k:v for k,v in oldhist.items() if k!='documentation'}
if not report['priorHistoryManifestUnchangedExceptDocumentation']:fail('prior-history-manifest-mutated','history-initial-readiness-manifest.json')
for m in hist['documentation']:
    if sha((ROOT/m['path']).read_bytes())!=m['sha256']:fail('documentation-hash-mismatch',m['path'])
for p in changed:
    if not p.endswith('.tar.gz'):scan(p,(ROOT/p).read_bytes())
for p in ['.codex/pstack-runs/fieldnote-v2/state.json','artifacts/fieldnote-v2/evidence-gap-followup/publication-review-receipts-manifest.json']:
    if p not in changed:scan(p,(ROOT/p).read_bytes())
report['networkHosts']=[{'host':h if not re.search(r'@|(?:token|key|secret|credential)=',h,re.I) else '<redacted:'+sha(h.encode())+'>','count':n} for h,n in hosts.most_common()]
report['credentialSummary']=dict(collections.Counter((x['kind']+':'+str(x['syntheticMarkerInValue'])) for x in report['credentialCandidates']))
report['status']=git('status','--porcelain').decode()
(OUT/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['base','head','failures','archives','objects','recursiveBytes','maxObjectBytes','maxDepth','runtimeChangedPaths','aToBPaths','ownerSealMatches','originalReportsPreserved','originalArchiveCopies','originalManifestCopies','priorHistoryManifestUnchangedExceptDocumentation','credentialSummary','sensitivePathCandidates','status']},indent=2))
