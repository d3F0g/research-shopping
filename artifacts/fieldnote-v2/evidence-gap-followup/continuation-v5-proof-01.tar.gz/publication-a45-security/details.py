import collections
import hashlib
import io
import json
import pathlib
import re
import subprocess
import tarfile
import urllib.parse
import zipfile

ROOT=pathlib.Path('/tmp/fieldnote-v5-publication-security')
OUT=pathlib.Path('/tmp/fieldnote-v5-publication-security-report')
DIR=ROOT/'artifacts/fieldnote-v2/evidence-gap-followup'
HEAD='a45cac153f9bdafab9c9d7c2972f0889ef854799'
result={'head':HEAD,'failures':[],'sealedInventories':[],'network':{'events':0,'requestHosts':{},'sensitiveHeaderNames':{},'cookieScopes':[],'responseStatuses':{}},'proofs':{},'logOutcomes':{},'unchangedProvenanceReferences':[]}
members={}
for archive in ['continuation-v5-proof-01.tar.gz','continuation-v5-proof-02.tar.gz','publication-review-receipts.tar.gz']:
    with tarfile.open(DIR/archive) as t:
        for m in t:
            if m.isfile():
                if m.name in members:result['failures'].append('Cross-archive duplicate '+m.name)
                members[m.name]=t.extractfile(m).read()
result['uniqueTopMembers']=len(members)
for prefix,manifest,key in [('price-owner','artifacts/issue-64-price-v5/owner-evidence-manifest.json','files'),('independent-qa','manifest.json','files'),('independent-security','sealed-manifest.json','members')]:
    d=json.loads(members[prefix+'/'+manifest]);n=0
    for m in d[key]:
        path=prefix+'/'+m['path'];b=members.get(path)
        if b is None or len(b)!=m['bytes'] or hashlib.sha256(b).hexdigest()!=m['sha256']:
            result['failures'].append('Sealed inventory mismatch '+path)
        n+=1
    result['sealedInventories'].append({'prefix':prefix,'entriesChecked':n})
hosts=collections.Counter();headers=collections.Counter();statuses=collections.Counter();cookies=[]
for path,blob in members.items():
    if not path.endswith('.zip'):continue
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        for n in z.namelist():
            if not n.endswith('.network'):continue
            for line in z.read(n).splitlines():
                event=json.loads(line)
                result['network']['events']+=1
                snap=event.get('snapshot',{})
                req=snap.get('request',{});res=snap.get('response',{})
                url=req.get('url','');u=urllib.parse.urlsplit(url)
                hosts[u.netloc]+=1
                if u.username or u.password:result['failures'].append('URL credential in '+path+'!'+n)
                if u.hostname not in ('127.0.0.1','localhost','fixture.example.com','example.com','manufacturer.com'):
                    result['failures'].append('Unexpected trace destination in '+path+'!'+n+' host '+str(u.hostname))
                if u.port in (3190,5290):result['failures'].append('Preview traffic in '+path+'!'+n)
                statuses[str(res.get('status'))]+=1
                for side,entity in [('request',req),('response',res)]:
                    for h in entity.get('headers',[]):
                        name=h.get('name','').lower()
                        if name in ('authorization','proxy-authorization','x-api-key','api-key','cookie','set-cookie'):
                            headers[side+':'+name]+=1
                            if name not in ('cookie','set-cookie'):result['failures'].append('Credential header in '+path+'!'+n)
                    for c in entity.get('cookies',[]):
                        item={'name':c.get('name'),'domain':c.get('domain'),'secure':c.get('secure'),'sameSite':c.get('sameSite')}
                        if item not in cookies:cookies.append(item)
result['network']['requestHosts']=dict(hosts)
result['network']['sensitiveHeaderNames']=dict(headers)
result['network']['responseStatuses']=dict(statuses)
result['network']['cookieScopes']=cookies

for path,b in members.items():
    if path.endswith('/report.json') and any(x in path for x in ('frozen-eval-final','current-composed-eval','eval-current','root-runtime/eval')):
        d=json.loads(b)
        result['proofs'][path]={k:v for k,v in d.items() if k in ('summary','acceptance','metrics','totals','counts','verdict')}
        if not result['proofs'][path]:result['proofs'][path]={'keys':list(d)}
for path in ['skill-owner/red/proof.json','skill-owner/green/proof.json','root-runtime/root-runtime-proof.json','root-native-baseline/proof.json','independent-security/native-browser-results.json','independent-security/eval-probe-results.json','independent-security/boundary-results.json']:
    d=json.loads(members[path])
    result['proofs'][path]={k:v for k,v in d.items() if isinstance(v,(int,float,bool)) or k in ('status','result','verdict','cleanup','error','head','sourceHead','sourceCommit','commit')}
    result['proofs'][path]['keys']=list(d)
for path in ['hosted-failed-baseline/failed-workflow.log','independent-qa/initial-checks/unit.log','independent-qa/initial-checks/e2e.log','independent-qa/postgres.log','independent-qa/eval-test.log','price-owner/artifacts/issue-64-price-v5/unit-api-final-subject.log','price-owner/artifacts/issue-64-price-v5/e2e-candidate-final.log','price-owner/artifacts/issue-64-price-v5/eval-test-projection-fixed.log','price-owner/artifacts/issue-64-price-v5/postgres-candidate.log']:
    text=members[path].decode('utf-8','replace')
    result['logOutcomes'][path]=[line for line in text.splitlines() if re.search(r'(Test Files|Tests\s+\d|# (?:tests|pass|fail)|\d+ (?:passed|failed)|Process completed with exit code)',line)][-12:]

def git(*a):return subprocess.check_output(['git','-C',str(ROOT),*a])
for p in git('ls-tree','-r','--name-only',HEAD,'--','.audit').decode().splitlines():
    b=git('show',HEAD+':'+p)
    matches=list(re.finditer(rb'(?:/Users/[^\s`"<>]+/\.codex/sessions/[^\s`"<>]+|rollout-[^\s`"<>]+\.jsonl)',b))
    if matches:
        result['unchangedProvenanceReferences'].append({'path':p,'references':len(matches),'equalToPreArchive':b==git('show','7d503ce^:'+p)})
search=subprocess.run(['git','-C',str(ROOT),'grep','-l','-E',r'\.audit/fieldnote-v2/(qa-interim|qa-reviews|security-interim|security-reviews)',HEAD,'--','src','tests','scripts','.agents','evals','.github','package.json','package-lock.json','*config*'],capture_output=True)
result['retiredImportSearch']={'exitCode':search.returncode,'matchingPaths':search.stdout.decode().splitlines(),'stderr':search.stderr.decode()}
if search.returncode!=1:result['failures'].append('Retired import search did not return zero matches')
result['status']=git('status','--porcelain').decode()
(OUT/'details.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
