# Bootstrap diagnostics at 34dbb00

Preserve the approved Fieldnote UI and diagnose the blank mobile history-verification failure. Commit `34dbb00ae95e82239123f7e71552b7f74c679bbe` adds diagnostics only. The original failure's cause remains unresolved in Issue #56. The passing run below does not establish a fix.

## Candidate and scope

The parent is `f3c1cf413b21b88b8707815f627d7b1a7442a0aa`. Only `scripts/account-test-runtime.mjs` and `scripts/verify-evidence-history.ts` changed. Application files, assertions, account-response waits, HTTPS route policy, and the mobile 5500 ms CDP rule remain unchanged.

The verifier now retains bounded navigation and same-origin resource metadata, raw CDP request identifiers and statuses, applied latency-rule identifiers, browser errors, document structure counts, and owned API/Vite output. It records successful and failed initial loads and reloads. It does not record request bodies, response bodies, cookies, authorization headers, environment values, or private capture files.

## Observed Linux result

[PR CI run 44550970924](https://github.com/d3F0g/research-shopping/actions/runs/44550970924) completed successfully, including the maintained history journey, browser suite, and artifact upload. The inspected artifact is `research-shopping-browser-evidence`, artifact ID `14543067674`.

The run targets head `34dbb00ae95e82239123f7e71552b7f74c679bbe`. Its proof records GitHub's synthetic merge `248a1acae3af695218aa416ffe8b3c49d97e6135`. GitHub's Git commit API reports parents `9d2a3c5e336a6652ec6b02e0c3deff6617fb7d11` and `34dbb00ae95e82239123f7e71552b7f74c679bbe`. Both the synthetic merge and candidate have tree `7fa6cade26001fa4e2edba44a8e8e53b9eca9b72`.

The proof reports `status: passed` and `cleanup: true`. Its dirty paths are four account-browser screenshots rewritten by the earlier CI step. No application source modification is listed.

| Navigation | Retained events | Dropped events or request IDs | HTTP statuses | Root children | Resource, console, or page errors |
| --- | ---: | ---: | --- | ---: | --- |
| Desktop initial | 341 | 0 | 200 only | 1 | None |
| Desktop reload | 341 | 0 | 200 only | 1 | None |
| Mobile initial | 344 | 0 | 200 only | 1 | None |
| Mobile reload | 343 | 0 | 200 only | 1 | None |

The document and `/src/client/main.tsx` returned 200 in all four phases. The entry module had content type `text/javascript` and content length 2605. Each mobile phase recorded the configured throttle rule applied to the two `/api/account` GETs. No other request received an applied-rule event. The Vite optimized dependency version stayed the same across these observations. Owned Vite and API stderr was empty.

I inspected the four hosted history screenshots. They show the dark chat layout, fixture labeling, observed unverified price, unresolved variant and request fit, readable literal evidence, and the bottom composer at desktop and mobile sizes. This author inspection is not independent visual acceptance.

## Red evidence and limits

The original uninstrumented f3 PR run `44547693260` failed the initial mobile account wait after 30 seconds. Its diagnostic JSON contains only `page-loaded` and an empty body-text prefix. Its screenshot is white. That evidence does not identify the document status, module statuses, or browser console state.

A controlled local probe fulfilled only the mobile entry-module request with an empty 504 response in a throwaway verifier copy. It reproduced the old observation exactly, including the white screenshot and account-wait timeout. The new diagnostics captured document 200, entry-module 504, console resource error, raw CDP failure, a script resource error, and zero root children. The maintained verifier and committed route policy were not changed by this probe.

That probe proves diagnostic sensitivity to one plausible failure mechanism. It does not prove that the original CI failure involved a 504, Vite optimization, or CDP interception. The successful instrumented Linux run supplies no causal evidence for a behavioral fix. Issue #56 stays open.

## Proposed next experiment

Use at most three additional attempts of the existing PR verify job from run `44550970924`. Root owns each rerun. This is a predeclared stochastic reproduction experiment with the validated diagnostics, not an attempt to obtain a green acceptance status. The current successful result stays recorded and Issue #56 stays open.

Before each next attempt, download and preserve every completed attempt's full artifact and log in a distinct directory. Verify that the tested source remains synthetic merge `248a1acae3af695218aa416ffe8b3c49d97e6135`, or the identical candidate tree `7fa6cade26001fa4e2edba44a8e8e53b9eca9b72`. An unexpected source or workflow change invalidates the comparison and stops the experiment.

Each attempt retains the complete existing job prelude, both viewports, database/API restarts, route policy, latency, assertions, and timeouts. Use only the CI-owned fixture database and local SDK substitute. Stop on the first failure. Inspect its document/module/CDP/process trace before running another attempt or proposing a fix. If all three pass, report non-reproduction and stop. Three is a bound on the experiment, not a statistical confidence claim.

The hypotheses have distinct observations.

- A failed document or module load should expose a non-200 status, failed request, resource error, unexpected content type, or document structure before any account request. A Vite 504 remains one possible member of this class.
- An interception or CDP-emulation problem may produce inconsistent raw CDP and Playwright request events, an unexpected applied-rule path, or a transport failure despite successful document delivery.
- A client execution failure should expose a page or console error after successful resource delivery, together with a missing or incomplete root.

The current collector records these observations without changing application behavior. If a captured failure falls outside them, its direct evidence should define the next narrower experiment.
This experiment earns its cost because the original failure occurred before the old diagnostics could observe its cause, while the new collector has now been validated against a matching blank-page symptom. It keeps the system under test unchanged. A protocol matrix should follow only if an actual failure trace implicates interception or throttle matching. No new runtime fix or cache-clearing workaround is justified by the evidence currently held.

Root must agree before adding or dispatching this experiment. I have not modified a workflow, pushed a branch, retried CI, or changed application behavior.

## Evidence handoff

The inspected hosted files are under `fieldnote-v4/history-browser/` in the run artifact. Their names end in `initial-bootstrap.json`, `reload-bootstrap.json`, or `.png`. A local structured analysis is available beside the downloaded artifact in the root handoff. The local controlled probe includes `diagnostic-sensitivity-proof.json`, `listener-cleanup.json`, and the throwaway verifier source.

Owned local runtime cleanup completed. The controlled probe's Vite listener was independently confirmed closed. No paid Exa call, private environment file, existing database, real ledger, grant, deployment, or credential change was involved.

Attack the Premise rejected the account-delay explanation as sufficient for an empty document with no account request. Fix Root Causes kept the change diagnostic-only. Build the Lever produced rerunnable observations. Prove It Works required the real failure artifact, controlled red, hosted traces, and screenshots. Laziness Protocol kept the change in the two existing test files.
