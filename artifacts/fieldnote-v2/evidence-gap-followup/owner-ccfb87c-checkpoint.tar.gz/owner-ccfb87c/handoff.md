# Fieldnote evidence fix round 2

Goal: preserve the approved UI while rejecting invented request fit, ambiguous catalog prices, and forged historical grading.

Current owned branch is fix/fieldnote-v3-literal-evidence in /Users/josiahwong/Documents/research-shopping-v3-literal-evidence. Current head 7ad7ecf contains intentional red tests and is NOT a merge candidate. Tracked tree is clean. Only artifacts/fieldnote-v3/ is untracked. No private environment, credentials, ledger/grant, private capture, or existing database was accessed. No external provider or billable call occurred.

## Commits

- 798fc2b reproduced suffix/bare amount fit, ambiguous headings and forged historical grading.
- b3d55d8 reproduced valid JSON-string answer rejection in the independent provenance evaluator.
- d9252ad fixed those initial cases and authenticated the finite historical report inventory.
- 09e05aa added the unique whitespace-heading positive and no-positive-casefold control.
- ba2f556 bound raw heading UTF16 spans and admitted four authorized public archive reports.
- 0fad246 added actual browser regression journeys and moved current e2e output away from historical tracked captures.
- ccfb87c added only the two corresponding CI artifact upload paths. Permissions and checks are unchanged.
- 8f81e16 reproduced punctuation/range monetary-only escapes and qualified partial target headings.
- 7ad7ecf added the independent reviewer cases for monetary prose and leading variant modifiers.

## Current blockers

At 7ad7ecf the focused 100-case literal/catalog suite has 31 failures and 69 passes. The production code is still the ccfb87c candidate. No further production fix has been applied after the last two red commits.

Pure monetary evidence such as `35 SGD.`, `(35 SGD)`, `SGD 35–40`, `35 Singapore dollars`, `Price: SGD35`, `SGD35 per unit`, `SGD35 including tax`, and `35to40SGD` can still produce supported request fit, including a chosen product when budget is null.

Partial selected names followed by qualifiers, and variant headings such as `New Silver colorway` and `Limited Silver52mm`, can still be treated as opaque foreign rows. Raw source is retained, but the attribution decision is wrong.

The failed premises are explicit. An anchored amount regex is not the class of monetary-only evidence. An unmatched heading word is not proof of a foreign identity. The second premise remains unresolved by a merely different-leading-token heuristic. Root requested a fresh structural review before further peer-row implementation.

## Completed changes that remain useful

The historical reader now authenticates canonical entire parsed payloads against code-owned digests. It no longer accepts untrusted check arrays merely because verdict/summary/hash fields agree. It executes no embedded source and does not regrade old reports. The self-contained digest implementation is frozen beside the reader.

The closed inventory contains 13 loose historical schema5 report paths from base33fadc7, with pinned Git blob IDs and full-payload digests. It also contains four member payloads from exactly two authorized public archives, with archive SHA256 and member paths. Those archives were untracked in root, so no Git provenance was invented. All 17 inventory records were read successfully; unknown or changed old payloads are rejected. This is bounded archive admission, not universal historical report compatibility. All older schema2/3/4 readers remain unchanged.

Current evaluator provenance accepts object or JSON-string answers with the application's 128000-character string limit. Malformed, null, array, missing-product, and oversized string controls reject. Native quoted wording is still compared with actual material, separately from literal/source consistency.

The accepted eager catalog fallback cleanup is complete. `namedCatalogObservation` runs only after sentence/context attribution cannot produce an observation. No UI component or CSS changed.

## Verification of superseded ccfb87c code

330 unit tests, 27 eval tests, 28 owned PostgreSQL tests, 10 actual browser tests, both typechecks, build, actionlint and all 18 official component registry comparisons passed before the new red cases. Historical and current response source trees are unchanged between 0fad246 and ccfb87c; the latter changes only two CI artifact upload paths.

The owned mixed-history browser proof at 0fad246 passed desktop/mobile PostgreSQL+API restart, old-message equality, stale prepared-op rejection and account isolation with cleanup true. Full e2e passed all ten journeys and wrote current captures only under artifacts/fieldnote-v3. The exact ccfb87c verification-skill proof passed desktop/mobile/short-mobile and cleanup true.

The exact ccfb87c critical full60 report executed all 60 cases with 11 pass, 0 fail, 48 blocked, 1 unsupported, 0 infrastructure failures and 0 critical failures. Acceptance remains inconclusive. The fuller red synthetic probes demonstrate why that report does not establish correctness or live usefulness.

Preservation verified all 389 frozen committed assets unchanged. Two prior public archives were only read, never modified. All owned process sessions have completed; runtime helpers report cleanup true. No existing/shared process was stopped.

## Evidence

- Red logs /tmp/fieldnote-v3-round2-red-app.log, /tmp/fieldnote-v3-round2-red-eval.log, /tmp/fieldnote-v3-round2-red-string.log, /tmp/fieldnote-v3-round2-red-heading.log, /tmp/fieldnote-v3-round2-class-red.log, /tmp/fieldnote-v3-round2-expanded-class-red.log.
- Candidate logs /tmp/fieldnote-v3-round2-final-app.log, /tmp/fieldnote-v3-round2-eval.log, /tmp/fieldnote-v3-round2-postgres.log, /tmp/fieldnote-v3-round2-e2e.log, /tmp/fieldnote-v3-round2-build.log, /tmp/fieldnote-v3-round2-history.log, /tmp/fieldnote-v3-round2-critical-full60.log, /tmp/fieldnote-v3-round2-smoke.log.
- Current captures artifacts/fieldnote-v3/round2-browser, artifacts/fieldnote-v3/e2e, artifacts/fieldnote-v3/history-browser, artifacts/fieldnote-v3/round2-smoke.
- Critical report artifacts/fieldnote-v3/round2-critical-full60/report.json.
- Authorized public archive temporary extracts /tmp/fieldnote-v3-public-archive-reports (public reports only).

I inspected desktop shared-peer, mobile money-only, mobile ambiguous-target, and mobile full literal-evidence screenshots. They show correct uncertainty for the covered cases and accessible composer geometry. They do not cover the subsequently discovered red cases.

Independent focused cleanup at ba2f556 plus then-working browser tests found no comments/suppressions or MUST KILL findings. It accepted lazy catalog fallback and the independent evaluator/archive boundary. It was cleanup only, not QA/security approval.

## Principles

Model the Domain moved historical trust to a finite authenticated archive boundary. Fix Root Causes corrected raw heading offset binding rather than changing display eligibility. Type System Discipline preserved versioned readers and current evaluator dispatch. Minimize Reader Load removed the eager fallback. Attack the Premise halted further peer-word patching after the broader red cases refuted the assumed foreign-identity rule.
