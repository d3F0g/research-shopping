# Fieldnote V2 evidence-gap security preflight

The goal is to repair retrieval and evidence defects while preserving the approved UI, source proof, spending controls, and privacy.

Scope is read-only preflight of the app owner's worktree at `/Users/josiahwong/Documents/research-shopping-v2-evidence-gaps`. Base is `e81b890dbf421d2ad65c551c5e404ca5e656d5f5`. The first inspected head was `f6ef20401d3251de1c68b37d1aedf2f6f649f2d3` with diagnostics uncommitted. Root subsequently identified provisional diagnostic commit `a71ddbd`. This is not a final exact-head verdict.

The reviewer did not author application changes. No application, dependency, or test file was edited. No real provider, private environment, credential, ledger, grant, database, user history, deployment, GitHub mutation, or unrelated session was accessed. This review uses the parent's permissions and is not an independently sandboxed process.

## Provisional blocking finding

The first inspected `createExaDiagnosticWriter` accepted any absolute directory with current ownership, mode 0700, and matching realpath. It did not exclude repository, artifact, or history destinations. The development composition passed the configured path directly. A newly created private directory under a repository would pass these checks and receive raw shopping text, accepted intent, and whitelisted provider payloads. This violates the assigned outside-repository capture boundary.

The static reproduction is to supply an existing owned nonsymlink mode0700 repository subdirectory to `createExaDiagnosticWriter` and call its returned writer with a small valid record. The source contains no repository exclusion before exclusive creation. No reproduction directory was created during this preflight because the only authorized write path was this report. Root acknowledged this finding and requested a fail-closed outside-Git-checkout check from the app owner. Runtime verification remains pending.

## Boundary observations

- The development entry point gates external research on `NODE_ENV=development`. Diagnostics are absent unless a directory is configured.
- The draft sink selects only answer, citations, requestId, and costDollars from the provider envelope. It omits headers and SDK errors. It bounds traversal depth, node count, and serialized bytes, and emits an explicit incomplete marker on omission.
- Directory admission refuses unknown names, unsafe modes, symlinks, hardlinks, and cap exhaustion. A nonblocking exclusive lock covers count and byte admission and writing. Cleanup compares inode, device, ownership, and a lock token before unlinking.
- The capture callback is awaited through a 500ms promise race before the operation returns. Final testing must establish bounded settlement with throwing and never-resolving callbacks, and conservative cancellation behavior. The race cannot preempt synchronous JavaScript. The trusted writer's bounded traversal is therefore part of the assumption.
- Safe URL binding now applies the same source policy and URL canonicalization to citation URLs and native support URLs. Full href comparison retains path, query, and fragment distinctions. Canonical duplicate text conflicts remain unresolved.
- Existing price guards require exact variant, explicit currency, complete conditions, native quotation provenance, and both requested numeric bounds. The pending heading-layout change must retain membership, alternate variant, range, bare-dollar, fee, adverse-context, and source-cut controls.
- The Hono application explicitly validates Host, Origin, media type, encoding, body size, JSON, and turn schema. The entry point binds the API to 127.0.0.1. Sessions use separate random identifiers and prepared-operation maps. These are source observations, not completed runtime checks.

## Final review required

Root must assign an isolated review worktree and exact candidate hash. Run local SDK and Hono requests for HTTP rejection, session isolation, provider errors, cancellation, capture omission/failure/deadline, unchanged cost settlement and retry count, safe URLs, fixture labels, source instructions, and heading-price positive/adverse cases. Inspect actual loopback listeners and captured normal logs for sentinel shopping text and fake credentials. Exercise sink quotas across writer instances, lock contention, unsafe destinations, symlinks, unknown entries, and replacement-lock preservation with reviewer-owned local files only.

Read commands included `cat AGENTS.md`, `cat docs/security-model.md`, `cat .audit/fieldnote-v2/evidence-gap/architecture.md`, `git status --short`, `git rev-parse HEAD`, `git diff e81b890 --stat`, `git diff e81b890 -- src/server/exa-research.ts src/server/index.ts`, and reads of diagnostic, price, executor, Hono, session, safe URL, and relevant test modules. No tests have been run during this preflight.

Boundary Discipline kept the review on provider, filesystem, HTTP, and session trust boundaries. Prove It Works requires actual local transport and filesystem evidence before a final pass. Live retrieval usefulness and provider billing correctness remain outside this review.
