# Independent security review of evidence version 3

The goal is to preserve the approved UI while repairing false evidence gaps without inventing applicability, request fit, or historical proof.

Verdict is ISSUES for head `579ec5311932248b19fb382d7a767caff809137d` against base `33fadc7e3cfde2207528adb32b650287e758d343`. Three reproducible blockers remain. A fourth evaluation input-shape gap fails closed. Root has assigned repairs.

The reviewer did not author application changes. The review ran in `/Users/josiahwong/Documents/research-shopping-v2-evidence-security`. Only assigned audit/artifact paths and owned local test resources were written. No application, package, dependency, or repository test file was edited. No private environment, key, ledger, grant, provider capture, existing database, user history, real provider, paid call, GitHub mutation, or deployment was accessed. Credentials in probes are explicit fixture strings. Reviewers share host permissions and do not have an independent permission sandbox.

## Blocking findings

### Money-only suffix currency or bare number can authorize a recommendation

`bindRequestMatch` in `src/server/exa-research.ts` recognizes a money-only literal only when currency precedes the number. The price adapter also accepts currency after the amount.

An actual projected fixture with a source sentence `Model A costs 35 SGD for one unit, tax included.` and a request-match quotation of `35 SGD` returns supported request fit, eligible=true, and a model-a choice. A quotation of `35` has the same result. The prefix-currency control `SGD 35` correctly returns unknown fit, eligible=false, and null choice. Identity and hard-criterion support were held constant.

A source amount cannot establish the complete shopping objective. Rejecting only one currency order makes this boundary depend on formatting.

### Peer exclusion hides target price ambiguity

`namedCatalogObservation` in `src/server/price-evidence.ts` excludes another catalog row from monetary context when its heading does not contain the exact product-name string and its money line matches the opaque-peer grammar.

Appending this row to the selected catalog source retains its SGD868 observation even though the second title differs only by whitespace.

```text
Fixture Meridian Sunglasses -  Silver

SGD 999
```

The existing selected title is `Fixture Meridian Sunglasses - Silver`. Appending that exact title with SGD999 correctly withholds price. A doubled space makes the conflicting target row disappear into peer exclusion. A bare `Silver` heading with SGD999 and a lowercase spelling of the full target name also receive peer treatment. The raw source remains stored, but its adverse money no longer affects attribution.

An independently named `Fixture Other Silver Sunglasses` row is the paired valid peer control and can remain opaque. Sharing a color is compatible with independence, but a bare variant or potentially equivalent target title does not establish independence.

### Frozen report reader accepts forged successful checks

`validateHistoricalFieldnoteReport` in `evals/history-fieldnote-v2/report.ts` validates check vocabulary, evidence references, verdict consistency, and summary consistency. It does not bind recorded checks to authentic historical assertions or trusted recorded results.

The committed historical `artifacts/fieldnote-v2/conversation-polish/full60/report.json` originally records 11 passed, 48 blocked, 1 unsupported, and acceptance=inconclusive. Copy it in memory, replace every case's checks with an empty array, set each verdict to pass, and recompute summary with the existing frozen `summarize`. `validateReport` accepts the forged report as 60 passed with acceptance=pass. Rewriting every blocked or unsupported check to pass and recomputing summary also succeeds. Appending an invented critical check succeeds.

These reproductions do not change scenario data, source material, transport, implementation hashes, or embedded implementation text. No embedded code was executed. Historical presentation must not confer validated success on a report whose checks were changed.

## Additional fail-closed gap

`validCurrentProvenance` treats `material.answer` as an object. The actual provider projector also accepts a JSON-serialized answer string. A serialized copy of the same valid fixture produces a ready evidence-3 snapshot, but the current evaluation provenance check returns false. A valid transport shape is therefore reported as a provenance failure. Root has included a bounded string parse and malformed-string control in the repair scope.

## Reproduction artifacts

The following scripts are under `.audit/fieldnote-v2/evidence-gap-security/v3/`.

- `preflight-probes.ts` compares prefix/suffix/bare money and legitimate/ambiguous peer rows. It now asserts the expected rejection behavior and is red at this head.
- `report-integrity-probes.ts` loads only the committed public historical report, mutates in-memory checks, and asserts rejection. It is red at this head.
- `binding-probes.ts` exercises UTF-16 positions, declared whitespace, duplicate matches, offsets, cut metadata, native wording/origin preservation, and serialized-answer handling.
- `history-runtime.ts` runs actual Hono, SDK, and owned PostgreSQL migration/restart checks without a real ledger.
- `pg-tests.mjs` runs the repository PostgreSQL suite on an owned temporary cluster.
- `runtime-probes.ts` and `render-probe.ts` adapt the previously reviewed local security harness to this evidence version.

JSON outputs and logs are under `artifacts/fieldnote-v2/evidence-gap-security/v3/`. The original unasserted discovery outputs are retained as `preflight-probes.json` and `report-integrity-probes.json`.

```sh
env -i PATH="$PATH" EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v3/preflight-probes.ts
env -i PATH="$PATH" EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v3/report-integrity-probes.ts
env -i PATH="$PATH" EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v3/binding-probes.ts
env -i PATH="$PATH" LC_ALL=C EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v3/history-runtime.ts
env -i PATH="$PATH" LC_ALL=C EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node .audit/fieldnote-v2/evidence-gap-security/v3/pg-tests.mjs
```

## Passing evidence

The application suite passed 299 tests with zero failures. One checkout-root-writing diagnostic test was skipped to respect ownership and replaced by a scoped equivalent. The evaluation suite passed 24 tests. The owned PostgreSQL suite passed 28 tests. Passing existing tests did not detect the blockers above.

The independent history runtime preserved all four actual V2 messages. Migration changed the wrapper to schema 3, incremented revision/epoch, cleared preparation, and interrupted both prepared and running receipts. An old prepared ID dispatched nothing. An ordinary reply about historical results was free. One explicit current request produced a V3 snapshot beside the unchanged V2 snapshot with one admission, one SDK request, and one settlement. Another account could neither read history nor use the prepared ID. Actual PostgreSQL and API restart preserved the exact workspace. Normal logs excluded fixture content, email, and credential sentinels.

The independent binding probes preserved raw UTF-16 offsets through eight declared whitespace forms. Undeclared separators and duplicate equivalent spans failed. The current evaluation correctly rejected forged offsets, context, cut metadata, provider wording, and provider-origin replacements. This includes replacing a whitespace-different provider quote with the raw literal quote, which must not manufacture native quotation provenance.

Thirteen independent HTTP, session, diagnostic, failure, settlement, cancellation, URL, and source-instruction probe groups passed. They reused actual local SDK and Hono transports. Private capture caps, destination exclusion, omission markers, replacement-lock ownership, single dispatch, known/unknown settlement, and privacy remained intact. The React render probe escaped fixture script/event-handler strings and retained noopener/noreferrer and unknown stock/delivery labels.

The CI change adds the mixed-history browser/restart check to the existing verification job. It uses the same fixed fixture PostgreSQL service and the GitHub-provided service-container ID. Permissions remain `contents: read`. There is no new credential, elevated token permission, deployment, or external provider composition. Docker restart is an existing helper behavior with a validated container-ID argument. Hosted CI execution itself is root's separate gate.

The first cleared-environment PostgreSQL attempt failed because Homebrew PostgreSQL requires a valid locale on this host. An isolated retry exposed the explicit LC_ALL diagnostic. Runs with `LC_ALL=C` passed. Successful owned runtimes and the isolated diagnostic retry were stopped and removed. The original helper failed before returning its cleanup handle and did not expose its temporary path, so that failed initialization directory was not blindly deleted.

## Limits

The full60 product evaluation remains inconclusive. This review does not establish live retrieval usefulness, merchant authorization, stock, delivery, actual billing, or the uncaptured original schema failure. It does not read or replay private captures.

Whitespace containment proves provenance, not semantic entailment. Known payload checks do not establish resistance to every semantic prompt injection. The observer remains trusted application code, and its promise deadline cannot preempt synchronous JavaScript. Same-user filesystem/process tampering is not a separately sandboxed boundary. Browser layout acceptance remains with independent QA.

Boundary Discipline focused checks on the provider, filesystem, HTTP, history, and report boundaries. Prove It Works required actual transport and database restart evidence rather than relying on the author's summary.
