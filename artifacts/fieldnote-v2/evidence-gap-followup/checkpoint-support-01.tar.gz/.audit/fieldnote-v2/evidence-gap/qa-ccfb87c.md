# ISSUES

Goal. Preserve the approved chat UI and repair false evidence gaps without manufacturing relevance, price attribution, applicability or recommendation eligibility.

Exact reviewed head `ccfb87cdcbbebb4ca4b376fd6747cbbf9372b9cf`. Round base `579ec5311932248b19fb382d7a767caff809137d`; original scope base `33fadc7e3cfde2207528adb32b650287e758d343`. Reviewer authored no application, package, test, evaluation, workflow or skill changes. Only owned audit/artifact files are written. Tracked diff remains empty. No GitHub or merge mutation was made.

## Remaining blockers

### Money-only syntax still authorizes complete fit

The original `35 SGD` and bare `35` controls now correctly produce unknown fit and no choice. The broader class is not repaired. Independent unchanged native-assessment projections with no budget produce supported requestMatch and a compliant choice for each of these money-only reports:

- `35 SGD.`
- `(35 SGD)`
- `SGD 35–40`
- `Price: SGD 35`
- `SGD 35 per unit`
- `SGD 35 including tax`
- `35 to 40 SGD`

The provider support contains only the quoted monetary text, not an objective-fit passage. The complete fixture source and result for every case are in `ccfb87c/consolidated-counterexamples.json`.

Actual Hono, Exa SDK, owned loopback HTTP and Chromium reproduce `(35 SGD)` for `I want a USB-C powerbank.`. The native requestMatch support is only `(35 SGD)`. The page displays `Source-supported option` even though no qualifying observed price is retained. The independent assertion requiring ineligibility fails. Reproduce with `node .audit/fieldnote-v2/evidence-gap-qa/checks.mjs money-wrapper`. Initial screenshot and proof are in `ccfb87c/money-wrapper/`; cleanup is true.

This remains a recommendation blocker. A syntax wrapper cannot turn a price-only report into evidence of complete objective fit. Root and the application owner have the consolidated counterexamples.

### Partial target names with descriptors still disappear as peers

The original exact target, whitespace-equivalent full target and bare Silver rows with SGD999 are now correctly retained as ambiguous context and withhold the selected SGD868 observation. The broader class still fails. Adding any of these headers followed by SGD999 causes the row to be discarded as an independent peer and retains SGD868:

- `Meridian Sunglasses - Silver (standard)`
- `Silver - Standard`
- `Silver 52mm`
- `Meridian Sunglasses Silver, size 52`

The selected name is `Fixture Meridian Sunglasses - Silver`. Additional descriptor words do not establish that the competing price belongs to an unrelated product. Root explicitly confirmed this is a blocking continuation of the same peer-ambiguity class.

`ccfb87c/consolidated-counterexamples.json` preserves the raw inputs and projected outputs. The original unchanged target probes are green in `ccfb87c/peer-target-probe.json`. Actual SDK/Hono/browser reproduction is `checks.mjs partial-qualified`; the initial card incorrectly displays SGD868 while the retained source also contains the partial target's SGD999. Its expected null-price assertion fails. Evidence is under `ccfb87c/partial-qualified/`, cleanup true.

## Resolved original defect and passing focused controls

The historical report integrity defect is resolved for the admitted inventory. The original frozen report validates. Deleting all checks or rewriting all statuses and recomputing verdicts/summary now rejects. `historical-reader-probe.ts` was rerun unchanged and its proof is `ccfb87c/historical-reader-probe.json`.

The archive inventory was independently read from its actual provenance, not trusted as a list. All13 loose report payloads were read from exact base33 Git objects and checked against recorded Git blobs and canonical SHA256 digests. Both root-owned public archive files were checked against their recorded whole-file SHA256, and all4 specified members were read without extracting files. Their canonical digests match and their payloads validate. All17 inventory entries pass. No private archive or capture was accessed. No embedded historical source was executed and no historical semantics were regraded.

Object and JSON-string Answer encodings independently retain the same observed868/null-choice result and validate current native provenance. Replacing provider-reported wording with its whitespace-equivalent raw literal correctly fails native provenance. Malformed, null, array, empty-object and over128000-character JSON-string forms reject. Results are in `ccfb87c/archive-and-encoding.json`. The first helper attempt had a32MiB child-output cap below one public historical report's actual size; its bounded local read was corrected to128MiB. This was a review helper limit, not an application finding.

Six independent heading controls also pass. Double ASCII whitespace, NBSP and leading/trailing tab headings bind their unique literal raw span with correct UTF16 offsets after an astral prefix. Changed case, changed punctuation and zero-width insertion do not bind. Proof is `ccfb87c/heading-boundaries.json`. These positives do not resolve the two remaining ambiguity classes.

## Exact-head checks

Run from `/Users/josiahwong/Documents/research-shopping-v2-evidence-qa`. The owned `checks.mjs` wrapper uses an environment allowlist, NODE_ENV=test, EXA_RESEARCH_ENABLED=false and Vite envFile:false. Every actual SDK operation uses an explicitly owned loopback provider and visibly labeled fixture data.

| Check | Independent result |
| --- | --- |
| Original money-suffix SDK/Hono/browser probe | 2/2 desktop/mobile passed. |
| Original target ambiguity probes | All3 correctly withhold price. |
| Original report mutation probes | Original admitted; both forged variants rejected. |
| Money wrapper actual SDK/Hono/browser | Fails expected no choice, reproducing blocker. |
| Qualified partial-target actual SDK/Hono/browser | Fails expected null observed price, reproducing blocker. |
| unit | 330 tests passed in12 files. |
| eval-test | 27 tests passed. |
| e2e | All10 maintained browser tests passed, including new desktop/mobile boundary journeys. Their cases do not cover the remaining wrappers or descriptor-bearing partial targets. |
| typecheck and eval-typecheck | Both passed. |
| actionlint | Current CI workflow passed. Only new V3 artifact upload paths changed in this round. |
| Full60 current evaluation | 11 passed,0 failed,48 blocked,1 unsupported,0 critical failures,0 infrastructure errors,140 turns. Acceptance remains inconclusive. Strict all-gate exits1. |
| Archive/native encoding proof | All17 historical entries and both current native encodings pass their integrity controls. |

All evidence is under `artifacts/fieldnote-v2/evidence-gap-qa/ccfb87c/`, apart from maintained browser captures in the assigned `maintained-e2e-cwd/artifacts/fieldnote-v3/` directory. Both failing own runtime probes clean up their owned processes and listeners. Expected product assertions were not relaxed.

## Explicit reuse and UI inspection

The current head has identical blobs to579 for domain/history migration modules, workspace-store, account runtime, mixed-history verifier, PostgreSQL tests and fixtures, client rendering and dependency configuration. The independently executed579 28-test owned PostgreSQL proof and actual desktop/mobile V2/V3 history-plus-database/API restart proof are reused for that unchanged scope. No existing database was used in either round. Current actual browser and boundary tests cover the changed normalization and request-match path.

Inspected current desktop failed-wrapper and partial-target initial screenshots, current mobile distinct-peer observation screenshot and current new boundary journey outputs. The useful known868 amount, explicit unresolved conditions/full fit, centered conversation and accessible composer remain readable in the intended positive case. The wrapper case demonstrates the semantic failure through a visible recommendation badge. Desktop and mobile layout, first dark theme, history, contextual edits and disclosures retain the approved composition. No new human design gate is required.

## Seven product principles and acceptance limits

1. Objectives and material clarification retain genuine message history and both bounds in the maintained current browser suite.
2. Hard constraints remain explicit. The money-wrapper blocker nonetheless invents complete fit from price-only support.
3. Literal/source/provider provenance works in the focused positives. The descriptor-bearing partial-target blocker still erases material price ambiguity. Frozen report integrity is now conservative.
4. Known source observations appear first in the intended catalog UI. The failing money-only case incorrectly leads with a confident recommendation.
5. Comparisons and literal detail remain behind accessible disclosure in the preserved UI.
6. Current browser journeys and unchanged, blob-bound mixed-history proofs cover session adaptation, budget changes, frozen history, isolation and restart behavior.
7. Synthetic SDK call counts remain bounded to one per explicit request. Ordinary messages and held evidence do not call the provider. The paid-action disclosure remains visible. No progress is simulated.

No private environment, key, ledger, grant, private capture, existing database or billable provider was accessed. No deployment or sensitive operation was performed.

The two remaining application defects are explicit relevance/price/recommendation BLOCKERS, not notes. Separately, varied live product usefulness, exact real-variant relevance, current prices, stock, delivery and merchant authorization remain unestablished by these offline fixtures. The full60 corpus's blocked/unsupported coverage is not a passing product-usefulness verdict. The original uncaptured invalid-schema response remains unproven. Root owns final CI, GitHub and merge decisions after defects and policy gates pass.

Prove It Works shaped the use of actual SDK/Hono/browser screenshots and raw public archive provenance. Passing package checks did not override the remaining runtime failures. This round stops with the consolidated handoff for a new candidate.
