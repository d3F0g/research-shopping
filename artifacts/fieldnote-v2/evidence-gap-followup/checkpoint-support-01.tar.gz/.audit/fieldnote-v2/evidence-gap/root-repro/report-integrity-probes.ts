import { readFile, writeFile } from 'node:fs/promises';
import { validateReport } from '../../../../evals/v2/report';
import { summarize } from '../../../../evals/frozen-v4/report';
const path='artifacts/fieldnote-v2/conversation-polish/full60/report.json';
const original=JSON.parse(await readFile(path,'utf8'));
validateReport(original);
const results=[];
for(const mode of ['erase-checks','rewrite-failed-checks','invent-critical-check']){
 const report=structuredClone(original);
 for(const row of report.cases){
  if(mode==='erase-checks')row.checks=[];
  if(mode==='rewrite-failed-checks')for(const check of row.checks)if(check.status!=='pass')check.status='pass';
  if(mode==='invent-critical-check')row.checks.push({id:'fixture-invented-check',turn:null,status:'pass',critical:true,expected:true,observed:true,evidence:[]});
  row.verdict=!row.observation?'blocked':row.checks.some(c=>c.status==='fail')?'fail':row.checks.some(c=>c.status==='blocked')?'blocked':row.checks.some(c=>c.status==='unsupported')?'unsupported':'pass';
 }
 report.summary=summarize(report.cases);
 let accepted=true,error=null;try{validateReport(report)}catch(e){accepted=false;error=String(e)}
 results.push({mode,accepted,summary:report.summary,error});
}
const output={head:'579ec5311932248b19fb382d7a767caff809137d',source:path,originalSummary:original.summary,results};
await writeFile('artifacts/fieldnote-v2/evidence-gap-followup/root-579-report-integrity-red.json',JSON.stringify(output,null,2));
console.log(JSON.stringify(output,null,2));
