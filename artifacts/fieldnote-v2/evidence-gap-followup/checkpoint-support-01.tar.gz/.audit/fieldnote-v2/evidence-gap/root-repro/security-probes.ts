import { writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { initialConversation } from '../../../../src/domain/conversation';
import { reduceTurn } from '../../../../src/domain/turn-reducer';
import { projectExaAnswer } from '../../../../src/server/exa-research';
import { catalogMaterial } from '../../../../tests/helpers/v3-catalog-material';
import { nativeMaterial } from '../../../../tests/helpers/v2-material';
const intent = {...initialConversation().intent, productDescription:'Fixture sunglasses',budget:{minimum:800,maximum:1000,currency:'SGD'}};
const results=[];
for(const heading of ['Fixture Other Silver Sunglasses','Silver','Fixture Meridian Sunglasses - Silver','Fixture Meridian Sunglasses -  Silver','fixture meridian sunglasses - silver']){
 const raw=catalogMaterial(intent);raw.citations[0].text+='\n\n'+heading+'\n\nSGD 999';
 const result=projectExaAnswer(raw,intent);
 results.push({case:'peer row',heading,result:result.status==='ready'?{price:result.research.products[0].price&&{amount:result.research.products[0].price.amount,conditionsResolved:result.research.products[0].price.conditionsResolved},choice:result.research.choice,sourcesRetained:result.research.sources[0].text}:result});
}
const request=reduceTurn(initialConversation(),{phase:'prepare',operationId:randomUUID(),message:'Find a fixture USB-C powerbank between SGD30 and40'}).state.intent;
for(const quote of ['SGD 35','35 SGD','35','S$35']){
 let raw=nativeMaterial(request);
 const old=raw.citations[0].text;
 const token=quote==='35'?'SGD 35':quote;
 const source=old.replace('SGD 35',token);
 raw=JSON.parse(JSON.stringify(raw).replaceAll(JSON.stringify(old).slice(1,-1),JSON.stringify(source).slice(1,-1)));
 raw.answer.products[0].requestMatch=structuredClone(raw.answer.products[0].requestMatch);
 raw.answer.products[0].requestMatch.support=[{url:raw.citations[0].url,quote}];
 const result=projectExaAnswer(raw,request);
 results.push({case:'money-only fit',quote,result:result.status==='ready'?{requestMatch:result.research.products[0].requestMatch.status,price:result.research.products[0].price&&{amount:result.research.products[0].price.amount,conditionsResolved:result.research.products[0].price.conditionsResolved},eligible:result.research.products[0].eligible,choice:result.research.choice}:result});
}
const report={head:'579ec5311932248b19fb382d7a767caff809137d',fixtureOnly:true,results};
await writeFile('artifacts/fieldnote-v2/evidence-gap-followup/root-579-security-red-probes.json',JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
