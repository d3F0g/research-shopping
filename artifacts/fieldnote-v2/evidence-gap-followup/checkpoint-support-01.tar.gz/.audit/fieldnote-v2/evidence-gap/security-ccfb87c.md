# Independent security review: final round-two candidate

Verdict: **ISSUES**. Two previously reported blocker classes remain on `ccfb87cdcbbebb4ca4b376fd6747cbbf9372b9cf`, against original base `33fadc7e3cfde2207528adb32b650287e758d343`. This review covers the repair delta from `579ec5311932248b19fb382d7a767caff809137d` and retains the earlier report for that broader change. The historical report forgery blocker and the serialized-answer evaluator gap are repaired within the tested scope.

The reviewer did not author application changes. The owned checkout is `/Users/josiahwong/Documents/research-shopping-v2-evidence-security`. Writes were limited to assigned security audit/artifact directories and owned temporary fixture resources. No application, dependency, repository test, or workflow file was edited. No private environment, credential, ledger, grant, capture, existing database, user history, real provider, paid request, GitHub mutation, or deployment was accessed. Two explicitly assigned public archives were read. Reviewers share host permissions and are not independently sandboxed.

## Remaining blockers, reproduced through actual local HTTP and SDK

`round2-runtime.ts` starts a loopback Hono API and loopback Exa SDK substitute. Each of its 11 scenarios creates a fresh session, submits an explicit preparation, then executes the prepared research. It records one injected admission, one SDK request, and one settlement per scenario. All fixture results are explicitly marked `test-fixture`. No real ledger is composed.

### Money-only fit still depends on currency formatting

The source sentence says `Model A costs 35 Singapore dollars for one unit, tax included.`. With request-match support limited to `35 Singapore dollars`, the response marks request fit supported, observes SGD35 with resolved conditions, sets eligible=true, and chooses model-a. Prefix wording `Singapore dollars 35` has the same result. These forms are already accepted by the application's price grammar; they do not establish the shopping objective.

The new regex in `bindRequestMatch` rejects three-letter currencies, symbols, and bare numbers. It does not cover the monetary vocabulary accepted elsewhere in the same boundary. `(35 SGD)` also remains supported fit, although the bounded case has no qualifying price and therefore no choice.

Paired controls pass: a complete objective sentence remains supported and chosen; `35 SGD` and bare `35` become unknown fit and cannot authorize a choice.

### Qualified partial target headings still disappear as independent peers

Append either of these rows to the catalog fixture whose selected product is `Fixture Meridian Sunglasses - Silver` at SGD868:

```text
Silver colorway

SGD 999
```

```text
Meridian Sunglasses Silver Edition

SGD 999
```

The HTTP response retains the selected SGD868 observation with unresolved conditions. It retains the raw source, but removes the ambiguous SGD999 row from monetary attribution. The word novelty and word-count test in `namedCatalogObservation` treats the qualified target description as an independently named product. These headings do not establish an independent peer.

Paired controls pass: bare `Silver` now withholds price; independently named `Fixture Other Silver Sunglasses` retains the selected SGD868 observation. Every catalog case remains unchosen because fit and purchase conditions are unresolved; that does not make a falsely narrowed price observation acceptable.

The unchanged original red probes pass. These counterexamples show that the original blocker classes need a broader repair, rather than another isolated spelling exception. Root has acknowledged both classes and holds the candidate.

## Verified repairs and retained boundaries

- The unchanged original money/peer probe and original historical report mutation probe pass on this exact head.
- All 13 loose historical report entries match their actual Git blob at base `33fadc7`, their current bytes match that blob, and their code-owned digest matches the authenticated payload. All four additional report members match the two explicitly assigned public archives and their archive SHA-256 values. Validation accepts all 17 original payloads and rejects 85 in-memory mutations covering erased checks, all-pass checks, invented critical checks, unknown run identity, and changed embedded code. No embedded implementation is executed, and no historical result is regraded as current evidence.
- The independent binding probe accepts a valid JSON-string answer and the exact 128000-character bound. Malformed JSON, primitive/array JSON, and one-character-over-limit answers fail closed. Native wording, literal/context offsets, cut metadata, and provider-origin mutations remain rejected. Declared whitespace and UTF-16 offsets remain valid.
- The full application suite passes 329 tests, zero failures, with one checkout-root-writing diagnostic test skipped for ownership. The independent runtime harness includes its scoped replacement. The current evaluation suite passes 27 tests.
- Thirteen independent runtime groups pass again on this exact head: HTTP input/Host/Origin/body boundaries and loopback binding; session isolation; actual SDK capture; cache/single-dispatch; cancellation and known/unknown settlement; throwing/hanging observers; provider timeout/error/invalid-JSON behavior without fixture fallback; capture projection stages; repository/private-destination exclusion; omission, locks, size/count limits; safe links; and source instructions/cut qualifiers. Normal logs omit fixture content and credential sentinels.
- `unchanged-blobs-ccfb87c.json` compares all tracked `src` and package/lock files with the reviewed `579ec53`. Only `src/server/exa-research.ts` and `src/server/price-evidence.ts` changed. The prior actual PostgreSQL migration/restart evidence therefore remains evidence for the unchanged historical codecs, migration/store, session, and action-invalidation implementation. PostgreSQL was **not rerun** at this head; current provider projection was exercised by the new HTTP/SDK harness.
- The CI delta adds only two artifact upload paths. `contents: read` and existing checks remain unchanged. Browser fixture changes label substitutes explicitly. The screenshot path changes preserve old tracked captures rather than rewriting them. Independent QA owns actual browser layout acceptance; this review does not infer visual acceptance from test source.

## Reproduction and portable evidence

Run from the owned checkout. All harnesses below are under `.audit/fieldnote-v2/evidence-gap-security/v3/` and write only the matching `artifacts/fieldnote-v2/evidence-gap-security/v3/` directory.

```sh
env -i PATH="$PATH" REVIEW_HEAD=ccfb87cdcbbebb4ca4b376fd6747cbbf9372b9cf EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v3/preflight-probes.ts
env -i PATH="$PATH" REVIEW_HEAD=ccfb87cdcbbebb4ca4b376fd6747cbbf9372b9cf EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v3/report-integrity-probes.ts
env -i PATH="$PATH" REVIEW_HEAD=ccfb87cdcbbebb4ca4b376fd6747cbbf9372b9cf EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v3/binding-final-probes.ts
env -i PATH="$PATH" REVIEW_HEAD=ccfb87cdcbbebb4ca4b376fd6747cbbf9372b9cf EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v3/archive-probes.ts
env -i PATH="$PATH" REVIEW_HEAD=ccfb87cdcbbebb4ca4b376fd6747cbbf9372b9cf EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v3/runtime-final-probes.ts
env -i PATH="$PATH" REVIEW_HEAD=ccfb87cdcbbebb4ca4b376fd6747cbbf9372b9cf EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx .audit/fieldnote-v2/evidence-gap-security/v3/round2-runtime.ts
env -i PATH="$PATH" EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node node_modules/vitest/vitest.mjs run --no-cache --configLoader runner -t '^(?!.*rejects capture within the current source checkout)' --reporter=json --outputFile=artifacts/fieldnote-v2/evidence-gap-security/v3/ccfb87c-app-tests.json
env -i PATH="$PATH" EXA_RESEARCH_ENABLED=false TSX_DISABLE_CACHE=1 node --import tsx --test evals/v2/tests/*.test.ts
```

The `round2-runtime.ts` expected-safety assertion deliberately exits nonzero on this candidate. Its JSON preserves all outcomes before failing. Other listed commands pass. An initial reviewer-harness attempt referenced the wrong prepared-response field and failed before dispatch; that harness typo was corrected to `preparedId` before the recorded 11-scenario run.

The archive harness reads only the two authorized public paths: `artifacts/fieldnote-v2/evidence-gap-followup/owner-33fadc7-checks.tar.gz` and `artifacts/fieldnote-v2/evidence-gap-followup/owner-651-checkpoint.tar.gz` under the root worktree. Archive members are streamed to memory, never extracted into the checkout.

## Limits

Full60 acceptance remains inconclusive: 11 pass, 48 blocked, 1 unsupported, zero fail. This review does not prove live retrieval usefulness, actual billing, inventory, delivery, merchant authorization, or safety against every semantic source instruction. Provenance and quote containment do not establish semantic entailment. Hosted CI, browser QA, repository policies, and merge remain root's gates. No new human approval is requested or implied.
