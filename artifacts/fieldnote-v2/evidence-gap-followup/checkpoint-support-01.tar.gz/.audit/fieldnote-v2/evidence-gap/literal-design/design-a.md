# Literal source binding and observed catalog prices

The goal is to retain a real product identity and its observed price when Exa changes only source whitespace. The approved UI stays intact. A retained price must not turn unresolved conditions into a compliant recommendation.

This is a bounded design runner for root synthesis. Application source was inspected at `33fadc7e3cfde2207528adb32b650287e758d343`. No application or GitHub changes were made. No private capture, environment, credential, usage ledger, or saved conversation was opened. No external request was made.

## Work phases

- Ground is complete. The current projection, evidence schema, stored codec, renderer, and evaluation adapter were traced.
- Sketch is complete. Two structural candidates are compared below.
- Agree belongs to root's parallel design synthesis.
- Implement is skipped because this assignment authorizes a sketch only.
- Scrap is skipped because no implementation was attempted.

The throughput boundary is one shared quote-binding primitive and one observed-price decision. Storage and evaluation work follow from the evidence-version change. A generic document parser, broad inference rewrite, or UI redesign is outside this design.

## Reproduced mechanism

The sanitized probe is `/tmp/v2-literal-binding-probe-a.ts`. Run it with `pnpm exec tsx /tmp/v2-literal-binding-probe-a.ts` from the V2 checkout. It invokes the pure `projectExaAnswer` function with visibly labeled fixture data. It does not construct an SDK request.

The current projection returned `identity: unknown`, `price: null`, and `requestMatch: supported`. The reported identity quote was absent as an exact substring. Its unique whitespace-equivalent literal source span was `[53,100)`.

```text
Reported wording
Fixture Meridian Sunglasses - Silver SGD 868

Literal source span
Fixture Meridian Sunglasses - Silver \n\n SGD 868
```

The first wrong decision is `source.text.indexOf(span.quote)` in `src/server/exa-research.ts:166`. Normalization cannot be added after this failure because the current `SupportSchema` equates the reported quote with a literal source substring in `src/domain/research.ts:120`.

The second wrong decision combines observation and applicability. `bindPrice` expands a short source to its entire catalog at `src/server/exa-research.ts:251`. `priceClauses` requires the price on the immediately following line at `src/server/price-evidence.ts:71`. Blank lines defeat that rule. Unparsed or unrelated monetary text then returns `unbound` at `src/server/price-evidence.ts:178`. `bindPrice` turns that result into no displayed observation at line 264.

The premise that every valid provider quotation must be byte-identical to its citation text is false for the supplied evidence. The premise that failure to qualify a price proves there is no observed amount is also false. The offline probe establishes both mechanisms. It does not establish private-capture acceptance or a complete user journey.

## Candidate A. Extend the current support record

Keep the current flat support fields and add `reportedQuote` plus a literal/whitespace discriminator. Keep `originalQuote` as the actual literal source substring. Change `bindAssessment` to use one offset-aware matcher. Add an identity-anchored price-row branch to `bindPrice` before existing applicability checks. Introduce evidence version 3 and a frozen evidence-2 read union.

This is viable and has the smallest immediate patch. Its cost is misleading field names and continued coordination across `bindAssessment`, `paragraph`, `bindPrice`, and `assessPriceContext`. The caller must know that `originalQuote` no longer means the original provider wording. It also leaves `unbound` carrying several distinct meanings. Those are concrete information-leakage and split-ownership red flags.

Do not implement the tempting smaller variant that changes the meaning of `originalQuote` under evidence version 2. Existing stored snapshots and current evaluation checks use it as the exact reported quotation.

## Candidate B. One literal-binding record and separate price decisions

Use a small evidence-binding module that owns reported wording, source offsets, context containment, and whitespace matching. Price assessment consumes bound supports and returns an observation separately from applicability. It remains a bounded redesign of these two decisions. There is no source AST, new provider loop, or general entailment engine.

This is the recommended shape. It removes the incorrect shared premise and makes later callers unable to mistake reported wording for literal source text. Its migration is larger than Candidate A, but most of that migration is required by evidence versioning in either design.

### Caller usage first

```ts
const evidence = bindProductEvidence({
	product: nativeProduct,
	sources: retainedSources,
	completeSources,
	otherProducts,
});
const product = assessProduct({
	id: nativeProduct.id,
	name: nativeProduct.name,
	variant: nativeProduct.variant,
	...evidence,
	stock: "unverified",
	eligible: false,
	blockers: [],
}, intent);
```

`bindProductEvidence` owns the coordination now spread through `projectAnswer`. It does not own ranking, budget comparison, or choice. `assessProduct` remains the sole eligibility calculation.

```ts
type LiteralSpan = {
	start: number;
	end: number;
	text: string;
};

type EvidenceSupportV3 = {
	sourceId: string;
	origin:
		| { kind: "provider"; reportedQuote: string; match: "literal" | "whitespace" }
		| { kind: "source-context" };
	literal: LiteralSpan;
	context: LiteralSpan;
};

type QuoteBinding =
	| { kind: "bound"; support: EvidenceSupportV3 }
	| { kind: "unbound"; reason: "missing" | "ambiguous" | "oversized-context" | "cut-context" };

function bindReportedQuote(
	source: ResearchSource,
	reportedQuote: string,
): QuoteBinding {
	throw new Error("not implemented");
}

type PriceBinding =
	| { kind: "absent"; reason: "missing-support" | "ambiguous-amount" | "wrong-variant" | "unbound-quantity" | "unsafe-source" }
	| {
		kind: "observed";
		amount: number;
		currency: string;
		variant: string;
		support: EvidenceSupportV3[];
		applicability:
			| { kind: "qualified"; conditions: string[] }
			| { kind: "unresolved"; conditions: string[]; reasons: string[] };
	};

function bindPriceEvidence(input: {
	price: NativePrice;
	product: Pick<NativeProduct, "name" | "variant">;
	identity: AssessmentV3;
	priceAssessment: AssessmentV3;
	sources: ResearchSource[];
	completeSources: boolean;
	otherProducts: Pick<NativeProduct, "name" | "variant">[];
}): PriceBinding {
	throw new Error("not implemented");
}
```

These are conceptual types. Derive actual public types from the Zod schemas. Keep provider types private to the server boundary. The product's public `price` can retain its existing amount, currency, conditions, `conditionsResolved`, and assessment fields. The distinct `PriceBinding` states are an internal decision model, not a new UI contract.

### Quote matching rules

1. Bind only within the retained source with the returned safe URL. Never search another URL to rescue a quote.
2. Preserve the exact-literal case. For an unambiguous exact match, reported wording and literal text are equal and the original offsets remain unchanged.
3. For whitespace alignment, collapse only a declared set of source whitespace runs. Preserve every non-whitespace code unit, including punctuation, hyphens, case, digits, currency symbols, and zero-width characters. Do not perform Unicode normalization, punctuation folding, ellipsis removal, word skipping, or paraphrase matching.
4. Use an offset map or a scan that maps the normalized match back to one raw contiguous interval. Count all equivalent matches, including overlapping matches. Multiple intervals are ambiguous. Never select the first normalized match.
5. Verify the resulting raw slice against the stored literal text. Verify the declared whitespace equivalence against the unmodified `reportedQuote`. Both checks belong in the evidence-3 schema refinement, not only in the projector.
6. Context must contain the whole raw matched interval. A match can cross blank paragraphs because every intervening raw character is retained. Preserve the current size and cut checks. Never join separate excerpts.
7. Retain `ResearchSource.originalLength` and `textTruncated` unchanged. Keep the existing source-count, conflicting-URL, source-instruction, and incomplete-source safeguards. Whitespace equivalence is provenance, not semantic support.
8. Represent source-derived adverse excerpts with `origin.kind: source-context`. The current adverse scanner constructs `originalQuote` itself at `exa-research.ts:414`. Evidence 3 must not label that excerpt as provider-reported wording.

For repeated exact literals, the safest current policy is ambiguity rather than an arbitrary occurrence. If exact-first compatibility is required for an existing test, restrict compatibility to identical context and certainty. Do not allow a duplicate under adverse context to be chosen by insertion order.

### Price observations and applicability

The new positive path binds a named row through already-bound identity and price supports. Both supports must refer to the same source. In the supplied case the identity's literal span contains the complete exact product name, selected variant, and explicit money token. The price's literal `SGD 868` span sits inside that span. This is enough to retain an observed amount, subject to the contextual ambiguity checks below. The price report alone is insufficient.

Keep the existing sentence-price and immediate-heading-price successes. Refactor their internal clauses to retain raw offsets rather than generating synthetic `heading costs amount` strings as `priceClauses` currently does at line 83. Add blank-line whitespace between the exact heading and money token without deleting any raw text from the evidence.

A row's matching text is not its complete applicability context. Inspect the complete contiguous local row context and the retained source set separately. Range tails, wrong-variant tails, quantity modifiers, and contradictory amounts must still prevent a single exact observed price. The existing tests that expect `price === null` for those cases remain unchanged.

For the supplied catalog, unrelated named rows with their own explicit amounts cannot overwrite the amount bound inside the selected identity span. Their presence can leave global applicability unresolved. It must not erase the local observed amount. Do not use a generic row boundary as proof that later text is irrelevant. Preserve the full source and its unknown context. If a row boundary cannot be established safely, leave applicability unresolved and retain the old binding-ambiguity outcome whenever that uncertainty could change the selected amount, unit, or variant.

A practical implementation should replace the current undifferentiated `unbound` result with separate binding ambiguity and applicability uncertainty. New price-row acceptance must flow through the same exact money, range, variant, quantity, and conditional checks as existing sentence prices. Do not add a permissive fallback that runs only after those checks fail.

Global qualification remains conservative. Run all current whole-source checks. Keep all source cuts and omissions disqualifying for positive compliance. Any adverse or opaque monetary context prevents `qualified`. A native `conditionsResolved: false` is monotonic and cannot become true because a parser recognized a row. Preserve known source conditions prominently. Preserve the provider's unresolved condition text as provider-reported context rather than pretending it was a literal quotation or a resolved condition.

For the sanitized response, the intended result is the following.

- Identity can retain the provider's supported exact-variant interpretation with the new literal provenance.
- The price is `868 SGD`, observed and unverified.
- `conditionsResolved` remains false. The provider's unresolved condition remains visible with honest attribution.
- The choice remains null. No budget bounds change.
- A request-match quote containing only `SGD 868` does not gain evidence for the full sunglasses objective through identity repair. Keep provenance and semantic assessment separate. This is an independently observed weakness in the current projector. Do not report that this fix establishes complete request fit.

## Module and migration footprint

`src/server/evidence-binding.ts` is the proposed new owner of literal quote matching and context spans. It is a pure server helper. Its public surface can stay at `bindProductEvidence`; the lower-level sketches above describe its internal responsibilities. `src/server/price-evidence.ts` remains the price-domain owner and consumes spans rather than a fake generated assertion string. Avoid introducing a second quote matcher in that module.

`src/domain/research.ts` defines the current evidence-3 schema and its refinement. Keep the research envelope `version: 2` and intent `intentVersion: 2` if their semantics do not change. Increment `evidenceVersion` to 3. Export the current type separately from the renderable history union.

`src/domain/workspace.ts:25` already has an independent `StoredResearchV2Schema`. Freeze it in place or move it verbatim into an explicitly historical module. Do not rebuild it by importing the new current `SupportSchema`, `AssessmentSchema`, `ProductSchema`, money schema, or intent schema. Do not run `assessProduct` on decoded history. Historical `eligible`, choice, rationale, and support fields remain exactly as stored.

Add a current stored-research branch for evidence 3. Historical message decoding must be a union selected by `evidenceVersion`, with the evidence-2 branch using the frozen codec. `ChatMessage.research` at `src/domain/conversation.ts:64` becomes a renderable-history union. A newly returned `TurnResponse.kind: research` and `ResearchOperation` remain current-only.

The frozen `StoredConversationV2Schema` currently accepts only evidence-2 messages. Leave that schema intact. Add a current conversation codec with mixed evidence-2 and evidence-3 messages. Introduce a new workspace-envelope schema if its stored representation changes. A wrapper migration may preserve the exact old message values while updating only the envelope or active state. It must not normalize, rebind, or reassess old research. `src/server/workspace-store.ts:52` and line 56 are the read and write parse boundaries. The SQL JSONB column needs no semantic rewrite of historical research.

`src/client/ResearchAnswer.tsx` can consume a read-only history view. Its current citation already renders `span.quote` as a literal blockquote at lines 51 and 76. For evidence 3, render `context.text` or `literal.text`, and add a short whitespace-alignment provenance label inside the existing evidence disclosure. Provider-reported wording, if displayed, must be labeled as such and must not be substituted into the literal blockquote. Keep all existing cards, disclosure controls, and navigation. There is no `clientEvidence` helper in this checkout, so a version-dispatched read-only view may be introduced at this rendering boundary if needed.

`evals/v2/projection.ts:22` currently maps `originalQuote` into the historical native quote field. Preserve that exact behavior for evidence 2. Do not project the new aligned literal text as the provider's native quote. Keep the actual reported wording separately for current checks. For evidence-3 whitespace matches, historical grading must acknowledge its representational limit. Do not silently suppress a failed historical literal check or fabricate a literal provider quote to pass it. A current provenance check must independently verify reported-to-literal equivalence, uniqueness, offsets, context containment, and actual cut metadata.

Update the current adapter/assertion versions in `evals/v2/contracts.ts`, current assertions, and transport tests. Keep `evals/frozen-v2`, `evals/frozen-v3`, and `evals/frozen-v4` untouched. Exact-literal current observations should continue to satisfy the previous literal assertions unchanged. Evidence-3 whitespace cases receive explicit current assertions rather than a dishonest historical projection.

## Paired acceptance tests

| Positive behavior | Required adverse partner |
| --- | --- |
| Sanitized catalog retains identity and SGD 868 with false resolved flag | Wrong native variant still has no price and no choice |
| LF, CRLF, tabs, and declared nonbreaking spaces align to one raw interval | Reordered words, changed punctuation, ellipses, omitted qualifiers, and zero-width characters never align |
| A unique normalized quote binds with exact offsets | Two equivalent occurrences are ambiguous, including one occurrence under adverse context |
| Exact literal native support preserves its native wording and offsets | Forged reported wording, literal offsets, match kind, and context containment fail the evidence-3 schema |
| A selected named row survives other catalog products and amounts | A neighboring row's money cannot satisfy the selected product's price support |
| Known membership conditions remain visible on an observed amount | Native false stays false, regardless of recognized row syntax |
| A clean old sentence-price case remains qualified | Existing range, alternate variant, quantity, tax, shipping, contradictory amount, and mixed-source cases keep their current outcomes |
| Full uncut source preserves contiguous blank-line evidence | A cut after the positive prefix, omitted source, conflicting duplicate URL, or instruction-bearing source cannot qualify |
| A full objective has distinct request-match evidence | Money-only requestMatch does not become complete fit merely through identity binding |
| A current evidence-3 snapshot round-trips through account persistence | Frozen evidence-2 snapshots round-trip without any changed research value or new paid action |
| Current exact-literal eval projection stays compatible | Whitespace-aligned reported wording is never emitted as an exact native literal quote |
| Existing desktop and mobile disclosure layout shows the observed price | Literal and reported text remain distinguishable, conditions remain readable, and source links retain safe navigation |

Run the existing `v2-price-boundary`, `v2-evidence-gaps`, Exa projection, account persistence, and current evaluation transport tests. Add the new sanitized case through the real local HTTP adapter and browser flow after implementation. Preserve all old adverse assertions. Root alone can replay the private capture. Independent QA and security must review the exact candidate commit before any merge decision.

## Principle decisions

- Attack the Premise changed the starting point. The sanitized raw whitespace span was checked before proposing another paragraph parser adjustment.
- Fix Root Causes placed the change at quote binding and price observation, before UI rendering or eligibility. The offline probe ties the failure to those decisions.
- Model the Domain separated provider wording, literal source span, and complete context. It also separated observation from applicability so unknown conditions cannot delete known money or become resolved accidentally.
- Type System Discipline requires evidence-3 discriminators and frozen evidence-2 reads. It forbids using current mutable schemas to reinterpret actual saved history.
- Laziness Protocol keeps this bounded to evidence binding, price decisions, and required consumers. It rejects a generic source parser or a broad conversational rewrite.
- Exhaust the Design Space produced the flat-record extension and the owned binding-record alternative. Candidate B wins because the modest extra structure removes the ambiguity that caused both failures.

The only current runtime evidence in this sketch is the sanitized offline probe. Private replay, browser acceptance, persistence round-trip tests, and independent review remain implementation gates owned by root.
