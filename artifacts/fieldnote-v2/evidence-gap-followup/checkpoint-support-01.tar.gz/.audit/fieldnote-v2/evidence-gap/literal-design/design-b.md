# Source-observation alternative for literal evidence binding

Preserve the approved UI and repair the observed identity/price loss without presenting reported text as a literal quotation. This is a read-only sketch against `33fadc7`. No provider, credential, ledger, captured user response, or database was accessed. Only the sanitized fixture supplied by root was used.

## Grounding

The current boundary makes one representation serve two jobs.

- `src/server/exa-research.ts:155` binds an assessment only when its reported quote occurs literally in the retained source. It then expands that span with `paragraph` at line135.
- `src/domain/research.ts:10` requires `originalQuote` to be the exact native quotation and checks it against the source slice at lines122–145. The same shape is used for identity, request fit, requirements and money.
- `bindPrice` uses the bound price assessment, broadens small sources to their whole text, and calls the price grammar. A catalog containing several unrelated prices therefore cannot supply the one selected row through the current paragraph/prose representation.
- `src/domain/workspace.ts:22–45` already has an independently frozen stored V2 support/research/conversation codec. `WorkspaceDataSchema` currently accepts only that stored conversation.
- `src/client/ResearchAnswer.tsx:73–77` renders the complete literal context span. It does not currently display a distinction between a provider report and an independently extracted observation.
- `evals/v2/projection.ts:22` mechanically projects `originalQuote` as the historical native quotation. `evals/v2/assertions.ts:21` independently enforces exact original and complete-context source slices. Neither can silently start accepting normalized text under the old evidence version.

The root fixture has an exact product-heading string followed only by whitespace and `SGD 868`. The provider's combined one-line quote is not literal, but the source contains a contiguous named listing and amount. Those facts are distinct from whether any merchant offers that item now or whether the native request-fit assessment establishes the whole objective.

## Candidate B, source observations rather than aligned provider quotes

Keep the provider quotation binder literal-only. Do not rescue its unbound quote by replacing `originalQuote` with a reconstructed string.

Introduce a small current evidence model for independently observed listing facts. Native reports remain attached as reports, including the unbound one-line text. Literal source observations carry their own provenance and never claim to be native quotations.

Caller usage:

```ts
const observations = observeCandidateListings(sources, {
  name: nativeProduct.name,
  variant: nativeProduct.variant,
  citedUrls: nativeProduct.identity.support.map(span => span.url),
});

const identity = bindIdentity(nativeProduct.identity, observations);
const price = bindListedMoney(nativeProduct.price, observations, sources);

// Existing hard-fit, currency, bounds and condition eligibility still run.
const product = assessProduct({ ...otherFields, identity, price }, intent);
```

These names are sketches, not requested wrapper layers. One pure module can own the observation index and both binding decisions.

Minimal shapes:

```ts
type LiteralSpan = {
  sourceId: string;
  start: number;
  end: number;
  quote: string; // Must equal retained source.slice(start, end).
};

type ReportedSupport = {
  url: string;
  quote: string;
  binding: "literal" | "unbound";
};

type EvidenceV3 =
  | {
      kind: "provider-literal";
      reported: ReportedSupport & { binding: "literal" };
      literal: LiteralSpan;
      context: LiteralSpan;
    }
  | {
      kind: "source-listing";
      fact: "named-variant" | "listed-money";
      literal: LiteralSpan;
      context: LiteralSpan;
      anchor: { productName: string; variant: string };
    };

type CandidateListing = {
  productName: string;
  variant: string;
  heading: LiteralSpan;
  money: LiteralSpan;
  context: LiteralSpan;
  amount: number;
  currency: string;
};
```

An assessment can retain `reportedSupport` separately from validated `support: EvidenceV3[]`. That preserves the actual native text and exposes whether support came from a native literal quotation or from a deterministic source observation. Do not reuse `originalQuote` with a new meaning.

For the sanitized fixture, identity can say that the cited listing names the selected product and the literal Silver variant. Its rationale must describe that limited source fact. It must not claim manufacturer authenticity or current saleability.

The listed amount can be retained as SGD868 for that exact named listing. `native.price.conditionsResolved === false` remains false. Observing a catalog row must not resolve conditions, override request fit, produce a merchant offer, or authorize a choice.

## Literal row recognition and safety boundary

Do not build a general merchant-page parser for this fix. A narrow observation is admissible only when all the following hold.

1. The complete candidate name is an exact, unique standalone heading in a safe retained citation. No substring, fuzzy, case-folded or Unicode compatibility match is needed.
2. The selected variant is explicit in that heading or another exact row field. A family name or a provider-only variant is insufficient.
3. The immediately following source content is only retained whitespace followed by one explicit-currency money line. The original context span includes that whitespace. Nothing is joined or omitted.
4. The amount and currency exactly match the proposed observed money. No bare-dollar inference, range endpoint, multiple-price sale pair, quantity total or neighboring product amount is accepted.
5. Unrecognized text attached to that row keeps attribution unbound. Existing wrong-variant/range/quantity tests must continue to require `price === null`, not merely a null recommendation.
6. Complete source context remains available. Known adverse context outside the row must still reduce applicability. A footer, duplicate conflict, source cut or unscoped qualifier cannot be discarded to manufacture a resolved price.

Recognition does not require knowing arbitrary neighboring product names. Unknown neighboring records may prevent resolved applicability; they do not need to erase an otherwise literal named listing observation. This is why observation and applicability need separate states. If the implementation cannot preserve that distinction safely, retain the observation only behind evidence and leave the ordinary product-price field null. Do not render a wrong-variant or range amount prominently under the selected product.

A whole-source monetary failure is too coarse to answer both questions. Prefer a single price decision result that distinguishes `unbound attribution`, `bound observation with unresolved applicability`, and `qualified price`, with the reason and literal qualifiers. Do not add another boolean that can contradict `conditionsResolved`.

## Version and storage footprint

This alternative changes evidence semantics. Publish it only under a new evidence version. Freeze `SupportSchema`/V2 snapshot validation and the independently stored V2 codecs rather than editing them into a permissive union.

A practical migration is:

- Keep the conversation protocol and intent version unchanged if their fields and meaning do not change.
- Define current research/evidence V3 schemas and a `HistoricalResearch | CurrentResearch` union for message rendering.
- Add a new persisted workspace data codec, tagged independently from the unchanged active intent and message envelope. Read old workspace schema2 through its frozen codec. A new wrapper can keep old messages byte-for-byte and accept new V3 research messages.
- Do not rewrite old research snapshots or run them through the new observation binder. Invalidate stale operational prepared work during a wrapper migration rather than reviving paid actions.
- No destructive SQL migration is needed for the JSON payload. `workspace-store.ts:49–57` needs a version-aware read/current-write boundary instead of directly parsing every row through one mutable schema.

Minimum affected modules are `domain/research`, the source-observation/binding module, the Exa projector, conversation message types, workspace codecs/store read boundary, `ResearchAnswer` evidence labels, current eval projection/assertions, and targeted tests. Existing old stored messages require a rendering helper that returns their literal context without fabricating new provenance.

The current UI composition can remain unchanged. The disclosure can label V3 observations `Literal catalog row` and provider assessments `Source-based AI assessment`. The card can retain the existing observed/unverified wording and unresolved conditions. No generated shadcn file, token or layout change is required.

## Proof pairs

- Exact standalone named Silver row, multiple other products, whitespace-only separation and SGD868. Retain source-named identity and observed868, preserve native false conditions and no confident choice.
- Same source, but wrong variant, range, second sale price, `For AX2 only`, quantity, membership, voucher, tax or mandatory fee. Preserve each existing expected attribution/applicability result and literal qualifier.
- Repeated same heading/price, repeated heading with different prices, missing variant, same amount under another heading, or altered product-name character. Remain ambiguous or unbound.
- Native combined quote contains omitted words, changed punctuation, ellipses or inserted text. It stays unbound. The source observation may exist independently only if its own exact row criteria hold; it never turns that native text into a literal quotation.
- Source cut or adverse qualifier beyond a retained prefix. No gain in certainty from the new observation.
- V2 stored snapshot decoded after rollout. Exact original fields and eligibility remain unchanged. New V3 message survives save/restart beside that historical message.
- Current eval mutations change native reports, literal offsets, source content, observation type, amount, currency or variant. Reject them under the new assertion version. Frozen scenario inputs and old reports remain unchanged.

## Recommendation and tradeoff

B is a genuine source-first alternative. It solves the mistaken equation between a provider quote and the underlying source observation. It also creates a useful long-term boundary for catalog rows without asking the provider for another call or changing the external native schema.

It is larger than a bounded, versioned whitespace-alignment repair. For the present captured failure, I would choose the other candidate's unique contiguous whitespace alignment if its implementation explicitly preserves the report and literal span separately, and add only a narrow literal named-row observation for price. Avoid a full general evidence index now. B earns implementation when repeated source-layout failures require several kinds of independently extracted observations.

Model the Domain changed the design from a quote-matching exception into distinct reported support and source observations. Boundary Discipline kept extraction at the provider/source boundary and left eligibility with the domain. Laziness Protocol favors the smallest versioned binding repair over a generalized page parser. Fix Root Causes requires repairing the source representation, not changing missing evidence into support or changing the uncertainty copy.
