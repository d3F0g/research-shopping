# Focused cleanup review at 579ec53

The goal is to preserve the approved Fieldnote chat UI while retaining valid source-bound identity and observed SGD 868 without inventing applicability or new proof for historical responses.

Reviewed by gpt-6-astra. The reviewed base is `33fadc7e3cfde2207528adb32b650287e758d343`. The reviewed head is `579ec5311932248b19fb382d7a767caff809137d`. The checkout is `/Users/josiahwong/Documents/research-shopping-v2`.

The focused cleanup verdict is no additional blocking finding. The candidate remains blocked by the independent security findings recorded in decision-log row 44. This cleanup review does not approve correctness, visual acceptance, security, hosted CI, or merge.

## Findings

1. Nonblocking duplicate work remains in `src/server/price-evidence.ts:239-243`. `observePrice` computes `namedCatalogObservation` before `assessPriceContext`, then discards the catalog result whenever the context result is qualified or unresolved. Both functions are pure. The catalog scan can run only after the context result fails to establish an observation. This would remove an unnecessary scan without changing precedence or evidence policy. Consider it within the required price-boundary correction, rather than opening a separate cleanup change.

2. No added narrating comments, commented-out code, lint suppressions, TypeScript suppressions, or constraint comments were found in the source, script, test, and workflow delta. URL text was excluded from the comment-pattern results. No deletion is requested on comment grounds.

3. The prior dead `assessPriceContext.relevant` flag is removed. The diff removes its initialization and assignment and returns `absent` when no observation exists. I did not find another dead compatibility path that can be deleted safely within this scope.

## Keep the required distinctions

The frozen definitions in `src/domain/workspace-history-v2.ts` are required readers of actual stored data. A direct comparison of the MoneyV2-through-StoredConversationV2 definitions against `33fadc7:src/domain/workspace.ts` matches after stripping outer whitespace. Do not deduplicate them into current mutable schemas. `src/domain/rendered-evidence.ts` serves both the renderer and retained-response code. It is not a one-caller pass-through.

The independent evaluator in `evals/v2/provenance.ts` checks the source bindings without calling the application binder. That repetition has a verification purpose. The current response schema and workspace reader also validate external and persisted input at distinct boundaries. Those checks are not redundant internal guards.

The new money-only guard in `src/server/exa-research.ts:199-203` and peer-row exclusions in `src/server/price-evidence.ts:204-236` need the security-requested root-cause correction. The money regex only rejects one direction of monetary wording. The peer exclusion compares names differently from the whitespace-aware evidence binder. These are the already reported correctness blockers, not extra cleanup findings or an invitation to remove validation.

`evals/history-fieldnote-v2/report.ts:61-65` checks internal agreement between recorded checks, verdicts, and summary without establishing that those checks were the historical grader's checks. Root's retained `root-579-report-integrity-red.json` shows that erased checks and rewritten all-pass checks are accepted. The historical reader needs trustworthy historical grading or equivalent integrity, not more comments explaining the current result.

## Evidence and limits

I read the application, evaluator, verification-script, workflow, and test changes in `git diff 33fadc7 579ec53`, searched added lines for comments and suppressions, compared the frozen history definitions, and ran `git diff --check 33fadc7 579ec53`. The whitespace check produced no findings. I read the implementation summary, the root's sanitized positive replay receipt, and the root's retained synthetic security probes. I did not rerun broad package tests or a browser journey because independent runtime QA and security own those checks.

No application file was changed. The only written files are this report and `/tmp/fieldnote-v3-final-trail-review.md`. Comment deletions, restored comments, application fixes, encodings, and cleanup reruns are all zero. No constraint encoding was offered because no constraint comment was found. A nested Comment Sicko agent was not spawned. This is the parent's assigned independent focused review, not a claim that this agent ran the whole no-comments orchestration workflow.

I did not open private captures, environment files, credentials, billing ledgers, grants, or user databases. No paid call, GitHub mutation, or preview change occurred.

## Principles that changed decisions

- Minimize Reader Load identified the eager fallback scan and rejected deletion of the two-caller rendering adapter.
- Subtract Before You Add kept the scope to dead state, comments, and unnecessary work. It did not add speculative guards or an abstraction.
- Boundary Discipline preserved response, persistence, and independent-evaluator validation as distinct checks.
- Model the Domain preserved the separation among reported wording, literal spans, observed money, and applicability.
- Fix Root Causes treats the security findings as faults in evidence classification and historical report integrity. A null choice or a disclaimer cannot repair a falsely attributed price or fit assessment.
- Prove It Works limits this verdict to the diff and artifacts actually inspected. It does not turn author tests into runtime approval.

## Attention

reviewed by gpt-6-astra

- Candidate 579ec53 remains blocked by the three independently reproduced security findings in decision-log row 44.
- The cleanup pass found one optional lazy-fallback simplification and no additional blocking cleanup defect.
- A corrected candidate needs review of its exact delta and the required independent runtime, visual, security, and hosted CI gates.
