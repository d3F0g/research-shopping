# Evidence-gap architecture judgment

The goal is to preserve the approved FieldnoteV2 UI, repair demonstrated evidence defects, and retain honest uncertainty before PR53 can satisfy its merge gates.

Reviewed head `e81b890dbf421d2ad65c551c5e404ca5e656d5f5` in `/Users/josiahwong/Documents/research-shopping-v2`. This was a bounded read-only investigation. No provider call, private environment, key, ledger, grant, user history, database, or GitHub mutation was accessed. The only written artifact is this report. Root owns the implementation decision and merge gates.

Throughput checkpoint: n/a, read-only investigation.

## Overview

Choose candidate A below. Fix symmetric safe URL canonicalization and expose bounded private projection diagnostics. Construct the retrieval query from authoritative accepted state, but treat improved live relevance as unproven until legitimate runtime evidence exists. Preserve the native evidence contract and domain eligibility gates.

The screenshot does not reveal the raw response that failed validation. Its later family-level optical-frame result with unknown sunglasses fit and no qualifying SGD price is correctly ineligible. Turning those unknowns into support would create an evidence defect.

## How it works and ownership

1. `src/domain/turn-reducer.ts` accepts intent edits and distinguishes ordinary replies from research. Raw requirement groups can retain historical money while `intent.budget` contains current accepted bounds. Both must remain distinguishable.
2. `src/server/conversations.ts:141` prepares an intent snapshot and operation identity. Its research path checks epoch, digest, active request, and cancellation before publishing. Current `invalid-response` copy collapses multiple adapter rejection stages into one user message.
3. `src/server/research-executor.ts:23` admits through quota, invokes one operation, extracts reported cost, and settles. Diagnostics must not delay or alter settlement, refund reservations, or add retries.
4. `src/server/exa-research.ts:481` calls `exa.answer` with `intent.productDescription` as query and complete accepted intent in `systemPrompt`. `projectExaAnswer` owns envelope validation, native schema parsing, URL and quotation binding, context checks, price projection, and final snapshot validation.
5. `src/server/price-evidence.ts:44` owns deterministic price-context checks. `src/domain/research.ts:170` independently requires exact identity, exact request fit, supported hard requirements, and applicable money inside both accepted budget bounds.
6. Conversation messages retain the resulting snapshot. The UI renders that result. Diagnostics belong beside the provider adapter and development composition, never inside messages, history, or frontend components.

The installed `exa-js` implementation at `node_modules/exa-js/dist/index.js:4165` forwards query, text, systemPrompt, outputSchema, userLocation, and transport options to `/answer`. The canonical skill and `references/answer.md` were read from `/var/folders/w2/wt271srd07ndwbnvm1_ty8t40000gn/T/skills-use-kTq0Mq/build-with-exa`. They support the existing Answer shape. No undocumented API field is proposed.

## Confirmed behavior from local synthetic projections

The following cases ran through the actual exported projector with `EXA_RESEARCH_ENABLED=false node --import tsx --input-type=module`. They use visibly labeled fixture material and establish local behavior only.

| Case | Observed result | Judgment |
| --- | --- | --- |
| Existing fixture with exact Model A, SGD35, complete tax context, requested SGD30 to SGD40 | Choice model-a, no blockers | Positive control |
| Replace every citation and native support URL `https://manufacturer.com/model-a` with `https://manufacturer.com` | Identity and request fit become unknown, price disappears | Confirmed URL binding defect |
| Replace price passage with `Model A\nPrice: SGD 35\nTax included.` beside the same identity | Price disappears, choice null | Narrow grammar excludes ordinary page layout |
| Append `Model A does not require a subscription.` | Request fit becomes unknown and money becomes unresolved | Confirmed lexical overconservatism |
| Append `The price applies only to members.` | Money unresolved, choice null | Required adverse control |
| Add unrelated long garden-tool citation that exceeds 24000 characters | All positive identity and fit assessments become unknown, price disappears | Global completeness creates cross-source coupling |
| Add two different garden-tool texts at one unrelated URL | All positive identity and fit assessments become unknown | Same global coupling through duplicate conflicts |
| Set native identity scope to invalid `exact` | Unavailable invalid-response | Required native contract rejection |

The global-completeness examples prove coupling, not that an arbitrary truncated source is safe to ignore. Discarded text can contain a relevant qualifier. Any source-scoping change must establish irrelevance from complete input before discard, or preserve the unresolved blocker.

The benign negative illustrates two independent mechanisms. The adapter scans any relevant paragraph for `does not` and downgrades request fit at `exa-research.ts:375`. The price parser treats `subscription` as monetary context but cannot bind the negative sentence to a qualifying price assertion. Removing either check wholesale would admit existing adverse cases.

## Two structural candidates

| Candidate | Shape | Benefits | Tradeoffs |
| --- | --- | --- | --- |
| A. Keep native contract and adapter ownership | One internal projector returns a result plus bounded diagnostic metadata. The public projector continues returning the domain result. A pure query builder reads authoritative intent. A private opt-in sink receives a whitelisted capture. | Small scope, stable frontend and snapshots, no second inference call, clear local reproduction. | Price grammar and broad context conservatism remain until separate paired cases justify changing them. |
| B. Make attributed evidence the internal model | Adapter first builds a bounded evidence index with canonical source identity, original lengths, cut provenance, native spans, complete passages, product attribution, and adverse observations. Projection derives claims and money from that index. | Separates missing evidence from discarded or unrelated context. Centralizes attribution and diagnostics. | Much larger change. Product attribution and semantic relevance cannot become trusted merely because a model asserted them. Requires a broader positive and adverse test bank and live usefulness proof. |

Candidate A has the deeper useful interface for this immediate scope. The conversation layer still consumes one research operation. Native provider details stay private to the adapter. Candidate B may later address repeated attribution failures, but introducing its new representation now would exceed the diagnosed URL fault and conceal the unknown screenshot cause.

## Smallest concrete repair

`retainSources` canonicalizes `citation.url` using `new URL(...).href` at `exa-research.ts:106`. `bindAssessment` compares that normalized value against raw `span.url` at line164. `https://manufacturer.com` therefore becomes `https://manufacturer.com/` on only one side.

Validate every support URL with the same safe-source policy before canonicalizing it. Compare the complete normalized href. Keep query, path, and fragment differences. Do not follow redirects or fetch source pages. Conflicting texts under one canonical URL remain conflicts.

A minimal reproduction is:

```js
const raw = nativeMaterial(intent);
const changed = JSON.parse(JSON.stringify(raw).replaceAll(
  "https://manufacturer.com/model-a", "https://manufacturer.com"
));
projectExaAnswer(raw, intent);     // ready with choice model-a
projectExaAnswer(changed, intent); // ready with no choice before repair
```

Pair the repaired positive with HTTP, credential-bearing, localhost, IP-literal, distinct-query, altered-quote, and conflicting-canonical-duplicate cases. Existing URL safety and exact text containment must continue to reject them where appropriate.

The retrieval query can state the accepted open request, hard requirements, flexible preferences, currency, and numeric bounds. Keep generation policy in systemPrompt. Do not heuristically erase clauses inside raw groups or treat old literal prices as the current accepted budget. A transport test can prove the submitted fields. It cannot prove the provider will now find sunglasses or a usable price.

## Private diagnostic shape and sink judgment

Minimum metadata should include a version, locally generated opaque correlation ID, projection stage, bounded issue paths and controlled issue codes, input counts and lengths, source ordinal, native status and scope, projected status and scope, and controlled downgrade reasons. Relevant stages are envelope, answer-json, answer-schema, sources, snapshot, and ready. Useful reasons include unsafe-url, duplicate-source-conflict, quote-not-found, incomplete-context, source-instructions, missing-support, and price-unbound.

Do not infer schema defects from the final screenshot. Capturing the exact rejection stage is the smallest instrumentation that can distinguish them.

Root supplied a fuller opt-in replay design. It captures actual query, accepted intent, whitelisted answer, citations, requestId, costDollars, and projection metadata. A development-only callback writes exclusively created mode0600 files into an existing owned nonsymlink mode0700 directory. The proposed cap is ten files, 2MiB per file, and 20MiB total across processes and restarts. A nonblocking exclusive lock makes count and byte admission atomic. Busy, stale, or unsafe destinations drop the capture. Nothing removes another process's lock.

This design has no architectural blocker if these conditions hold:

- Bound traversal and serialization before constructing large strings. Metadata, query, and intent count against the complete file limit. An oversize hash must not bypass the resource bound. Omit raw material with an explicit truncation or omission marker rather than label a partial payload complete.
- Use controlled filenames and exclusive no-follow creation. Verify the directory and final file ownership and modes. Unknown files must not evade directory-wide accounting. No automatic rotation, deletion, or replacement.
- Hold the lock through byte admission, write, and close. Release only the lock this process still owns. A replacement lock must survive the original writer's cleanup.
- Do not allow a hanging callback to postpone settlement indefinitely. Diagnostic failures and resource exhaustion leave result, reported cost, cancellation, and retry behavior unchanged.
- Document that opt-in replay files include shopping text and provider content. Keep them outside the repository, artifacts, history, browser responses, and ordinary logs. Never capture headers, cookies, credentials, SDK exception objects, or raw exception stacks.

Metadata-only capture is smaller and safer but cannot reproduce exact quotation or schema inputs. Full private replay capture earns its extra exposure only through explicit opt-in, the bounds above, and tests that exercise failure paths.

## Verification needed before merge

First prove URL repair and transport query behavior locally. Exercise invalid envelope, malformed answer JSON, native schema rejection, source dropping, snapshot rejection, successful ready response, and diagnostic disabled behavior. Test sink concurrency, byte limits, unsafe destinations, callback failure, and unchanged cost settlement with local substitutes.

Keep existing price-adversarial controls. Any expansion to ordinary price layouts needs controls for variants, shared variants, alternate prices, membership, vouchers, tax, mandatory shipping, bare dollar signs, source cuts, and adverse clauses elsewhere in the same complete source. Any relevance adjustment needs positive negative-language cases beside actual contradictory cases. The optical-frame unknown must remain unknown without real sunglasses evidence.

These local tests do not establish live usefulness or resolve the prior screenshot's exact payload. Independent exact-head QA and security, real application journeys, required CI, and project merge gates remain necessary.

Fix Root Causes shaped the recommendation to repair the first wrong URL comparison and instrument the unobserved rejection. Boundary Discipline kept validation and diagnostics at the provider adapter while leaving eligibility in the domain layer.
