# ISSUES

Goal. Preserve the approved Fieldnote chat UI while fixing false evidence gaps without inventing product fit, price applicability or eligibility.

Independent review of exact head `579ec5311932248b19fb382d7a767caff809137d`, base `33fadc7e3cfde2207528adb32b650287e758d343`, in `/Users/josiahwong/Documents/research-shopping-v2-evidence-qa`. Reviewer did not author application, test, evaluation, skill or workflow changes. Tracked diff remains empty. Only assigned audit/artifact files and the existing dependency symlink are untracked. No GitHub mutation or merge was performed.

The design milestone is already approved. This report adds no human approval gate. The three reproducible defects below prevent a QA PASS on this candidate.

## Blocking findings

1. Money-only full-fit checks depend on currency order. `SGD 35` downgrades requestMatch to unknown, but `35 SGD` remains supported. With an otherwise source-bound powerbank fixture and no budget, the latter produces an eligible choice. Actual Hono, Exa SDK, owned upstream HTTP and Chromium reproduce it for the ordinary message `I want a USB-C powerbank.`. The requestMatch's native support is only `35 SGD`. The initial card visibly shows `Source-supported option`. The expected false eligibility assertion fails. See `579ec53/money-only-probe.json`, `money-suffix/proof.json` and `money-suffix/desktop-money-suffix-initial.png`. Reproduce with `node .audit/fieldnote-v2/evidence-gap-qa/checks.mjs money-suffix`.

2. Whitespace-equivalent or ambiguous selected-variant rows are ignored as independent peers. Starting with the catalog fixture's named Silver SGD868 row, append the exact name and SGD999 and the price correctly becomes null. Append the same name with two spaces before Silver, or append bare `Silver` with SGD999, and the price incorrectly remains 868. Choice stays null, but conflicting/ambiguous attribution has been erased. Exact source materials and projected results are in `579ec53/peer-target-probe.json`. This independently corroborates security's finding. Other-brand complete names sharing Silver legitimately remain peer context; that positive control passes and must remain distinct.

3. Frozen historical report validation accepts rewritten results. The committed schema-5 report validates unchanged. Deleting every case's checks and setting verdicts/summary to pass also validates. Rewriting every recorded check status to pass validates too. No native response, material, source, historical implementation or transport is changed. This can present all 60 cases as pass instead of preserving the actual 11 pass, 48 blocked and one unsupported. `historical-reader-probe.ts` under the owned audit directory is rerunnable against the current reader and records both invalid acceptances in `579ec53/historical-reader-probe.json`. It executes no embedded historical code. Fixing report integrity must preserve the frozen semantics rather than regrade older results with mutable current assertions.

## Actual runtime and positive/adverse proof

The new source representation correctly separates provider-reported wording, literal UTF-16 span and contiguous raw context in the tested positive cases. Whitespace-only catalog quotation binding preserves the literal newlines. Five catalog modes ran through actual Hono, Exa SDK, loopback HTTP and Chromium at desktop/mobile sizes, 10/10 journeys. The ordinary catalog row and opaque peer sale/shared-color rows retain observed SGD868 with unresolved conditions and unknown full fit. Selected ranges, duplicate equivalent identity spans and punctuation-changed identity remain unresolved and do not create a price or choice. Native generic conditions are visibly labeled `Provider-reported, unverified`.

The original 23 independent source/price projector regressions pass unchanged before new V3 cases were added. The source-cut, conditional money, wrong variant, range, quantity, negative and budget-bound maintained tests also pass. These positives do not override the three defects above.

## Mixed history and owned PostgreSQL

The maintained 28 PostgreSQL tests passed against a newly created local temporary PostgreSQL17 cluster. No existing database was used. The actual historical V2 fixture is checked against its committed source blob and JSON pointer by the current unit suite.

The real account/browser/history runner passed at 1440x1000 and 390x844 against a separate owned temporary cluster. It preserved all old messages byte-for-value beside new evidence-3 results, invalidated a stale prepared receipt without SDK dispatch, isolated another signed-in account, restarted PostgreSQL and the API, and preserved the mixed workspace after reload. Current envelope/intent remain version2 while evidence is3 and the workspace wrapper is3. Old messages were not rebound or reassessed.

The owned copy of this runner changes only import paths, artifact destination and Vite startup to `envFile:false`. It preserves the maintained assertions. The copied runtime receives an allowlisted environment and uses generated fixture credentials, fixture database and fixture ledger only. These are automated substitutes, not private credentials or a live paid ledger.

## Exact-head checks and commands

Use `node .audit/fieldnote-v2/evidence-gap-qa/checks.mjs <mode>` from the review checkout. The wrapper sets NODE_ENV=test and EXA_RESEARCH_ENABLED=false, inherits an explicit environment allowlist, and uses Vite envFile:false. Outputs are under `artifacts/fieldnote-v2/evidence-gap-qa/579ec53/` unless a specific owned wrapper path is noted.

| Mode or command | Result |
| --- | --- |
| unit | 300 tests passed, 12 files. |
| eval-test | 24 tests passed. This does not cover the historical-reader integrity defect above. |
| postgres | 28 tests passed on owned temporary PostgreSQL17; cleanup performed. |
| history-browser | Both actual desktop/mobile account journeys passed, cleanup true. |
| catalog-probes | 10/10 actual SDK/Hono/browser cases passed; cleanup true. |
| money-suffix | Failed expected no eligible choice, reproducing blocker1; cleanup true. |
| smoke | Maintained project skill passed all three viewports with cleanup true after preparation was frozen. |
| e2e | All8 maintained browser tests passed. Worker cwd redirects the tests' hardcoded captures beneath the assigned artifact directory. |
| typecheck and eval-typecheck | Both passed. |
| build | Passed with existing Vite chunk-size advisory. |
| verify-official-components | All18 official component files match recorded registry output. |
| actionlint .github/workflows/ci.yml | Passed. |
| preservation | Frozen committed assets remain unchanged. |
| eval | All60 cases/140 turns executed. 11 passed, 0 failed, 48 blocked, 1 unsupported, 0 critical failures, 0 infrastructure errors. Acceptance remains inconclusive. Strict all-gate exits1 because incomplete cases are not passes. |

The first skill run completed all runtime journeys but failed its source-state guard because this reviewer created additional owned audit helper files concurrently. That preparation failure is preserved in `skill-smoke-own-audit-files-added`. It is not an application defect. The unchanged candidate was rerun after helper preparation stopped and passed the skill. No assertion was relaxed.

## Visual inspection and seven principles

Inspected actual desktop/mobile initial observed-fact screenshots and expanded literal-evidence screenshots from the mixed-history runner, catalog peer source cases, and the failing money-suffix choice. Also inspected the project's current three-viewport chat proof. The existing minimal header, centered conversation, dark initial theme, bottom composer, official cards and disclosure placement are preserved. The mobile catalog summary leads with known observed money while prominently stating unresolved purchase conditions and full fit. Raw whitespace is visible in the quotation, with a separate provenance label. The composer remains accessible and evidence does not overflow the page horizontally.

1. Objective and material clarification retain the original request and both bounds in the maintained skill; ordinary messages remain local.
2. Hard constraints stay explicit through contextual edits and history. Current tests preserve budget bounds and unknown fit. Blocker1 nevertheless authorizes a money-only complete-fit assessment for an unrecognized money syntax.
3. Evidence and uncertainty are separated correctly in the intended V3 positive path. Blockers1 and2 remain attributable-evidence failures. Blocker3 undermines durable historical proof integrity.
4. The useful source observation appears first in the inspected catalog path before manual scrolling. The failing money-only path wrongly promotes a compliant choice.
5. Comparisons remain concise with keyboard-operable expanded evidence. Literal provider provenance stays distinct from complete context.
6. Theme persistence, budget changes, retained history, dissatisfaction, cancellation, account isolation and restart recovery are covered by the actual current skill, browser and database journeys.
7. Explicit synthetic research dispatches one SDK operation per request. Ordinary/held messages spend none; provider errors do not retry or select fixture fallback. Paid-action disclosure remains visible at the composer. No progress activity is simulated.

## CI judgment and limits

The existing CI verify job now includes `verify:evidence:history`, uses the same PostgreSQL17 fixture service/container and unchanged contents:read permissions, and uploads the new browser evidence. Lint passes, and this reviewer exercised the equivalent owned PostgreSQL/browser flow locally. Actual hosted CI status remains root's responsibility; this is not a claim that GitHub CI has run.

No private environment, key, live ledger, grant, private capture, user history, existing database or paid provider was accessed. No real Exa call was made. All claims and research materials in automated journeys are explicit fixtures. No production operation was performed.

Synthetic results do not establish live relevance, actual product usefulness, current price, stock, delivery, manufacturer status, merchant authorization or purchase eligibility. The original uncaptured invalid-schema response is not established as fixed. Root alone owns private replay and later merge/CI decisions. Current full60 usefulness remains inconclusive, and no final PASS is issued on 579ec53.

Prove It Works shaped the independent Hono/SDK/browser and PostgreSQL execution and direct screenshot inspection. Passing package checks alone did not override the reproduced blocking findings.
