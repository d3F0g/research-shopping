# PASS for the scoped offline evidence repair

Goal. Preserve the user-approved Fieldnote V2 chat while fixing demonstrated research and evidence defects before root considers PR 53's remaining gates.

Reviewed base `e81b890dbf421d2ad65c551c5e404ca5e656d5f5`. Exact candidate `33fadc7e3cfde2207528adb32b650287e758d343`. Reviewer did not author application, package, test, evaluation or verification-skill changes. Tracked working-tree diff is empty. Reviewer writes remain under the assigned audit and artifact directories. The pre-existing node_modules symlink remains untracked. Root owns GitHub changes and merging. No external comments, issues, pushes or merges were created.

This PASS covers the identified local defects and the approved UI's preservation. It does not establish genuine Exa retrieval, semantic product usefulness or complete product acceptance. The full frozen evaluation remains explicitly inconclusive.

## Resolved findings

The 5383 wrong-variant and range amount display finding is resolved. The original source forms `Model A / Price: SGD850 / For Model B only` and `Model A / Price: SGD850 to SGD1200 / Tax included` now retain no selected exact price. Actual desktop/mobile initial cards show `No qualifying observed price`, and choice remains null. Quantity-qualified headings likewise retain no misleading one-unit price.

The 651 benign identity-context regression is resolved. The unchanged source `Fixture data: Fixture Sunglasses Model A is a sunglasses product, exact variant Model A.\nModel A\nPrice: SGD 850\nTax included.` again retains exact SGD850, tax included and an eligible synthetic choice. The original sentence, standalone heading and root-URL positive controls pass together with the adverse controls. The repair removes only bare `variants` and `configurations` from global pricing triggers. Actual monetary, quantity, unit and restriction signals remain. Unparsed price tails fail closed.

Known explicit conditional observations remain useful without becoming eligible. Independent browser cases display `This price requires a membership` or `This price requires a subscription` inline beside the observed SGD850. The subscription case also visibly retains `The ordinary Model A price is SGD 1200`. Conditions remain unresolved and there is no compliant choice. These literal restrictions are not hidden behind a generic conditions label.

The root-URL citation binding positive passes. Unknown optical-frame family identity and sunglasses fit remain unknown, with no qualifying observed price and no choice. This is a valid unresolved comparison, not a defect to conceal.

## Exact-head commands and results

Run from `/Users/josiahwong/Documents/research-shopping-v2-evidence-qa`.

All checks below use `node .audit/fieldnote-v2/evidence-gap-qa/checks.mjs <mode>`. The wrapper allowlists child environment variables, sets NODE_ENV=test and EXA_RESEARCH_ENABLED=false, and disables Vite environment-file loading. Actual Hono and Exa SDK traffic goes only to an explicitly owned loopback fixture server. Fixture data is visibly labeled in every returned comparison.

| Mode | Exact-head result |
| --- | --- |
| projector | Original unchanged 20/20 cases passed first. Three additional explicit-condition and quantity controls then extended the bank to 23/23 passed. |
| early-probes | 12/12 desktop/mobile Hono + SDK + Chromium journeys passed. Original sentence, heading and root-URL positives were paired with wrong-variant tail, heading range and sentence range. Actual initial screenshots were inspected. |
| custom | 46/46 desktop/mobile Hono + SDK + Chromium journeys passed. Each request caused exactly one local SDK call. Stored budget remained SGD800 to SGD1000. Literal evidence was keyboard-expandable and body-level horizontal overflow was absent. |
| conditional-probes | 4/4 fresh desktop/mobile cases passed. Explicit membership, subscription and the ordinary SGD1200 alternative stayed visible inline. |
| unit | 245 tests passed across 9 maintained files. This includes SDK transport cancellation, URL/quotation/source-cut boundaries, price conditions, API state, quotas and diagnostic privacy/failure behavior. |
| eval-test | 21 active evaluation tests passed, including 12 negative query mutations, missing authoritative system prompt and the positive oracle control. |
| eval | All 60 frozen cases and 140 turns executed. 11 passed, 0 failed, 48 blocked, 1 unsupported, 0 critical failures and 0 infrastructure errors. Acceptance remains inconclusive. `--gate all` exits 1 because blocked and unsupported cases are not acceptance passes. |
| typecheck | Passed. |
| preservation | 389 frozen committed assets unchanged. |

Current artifacts are under `artifacts/fieldnote-v2/evidence-gap-qa/33fadc7/`. `source-binding.json` records exact source, test, evaluation, skill, package and configuration object IDs. Browser proofs record candidate 33fadc7 and cleanup true. No browser errors were recorded. All owned listeners were terminated.

## Oracle judgment

The active 1.1.0 oracle requires parsed retrieval-query JSON to equal accepted description, both optional budget bounds, explicit currency, every criterion text and strength, and region. It independently still requires the complete authoritative intent in the system prompt. Mutation tests reject stale, missing, altered and extra query data. Frozen inputs, expectations, thresholds and historic artifacts remain unchanged. No semantic claim is manufactured to turn a blocked case into a pass.

The 48 blocked cases lack independently matching fixed product evidence, so relevance or recommendation usefulness cannot be established by that corpus. The unsupported case remains disclosed. These results are not described as a 60-case product acceptance pass.

## All seven product principles

| Principle | Evidence and judgment |
| --- | --- |
| Understand objective and ask material questions | The actual accepted sunglasses request is preserved across all current browser cases. Current maintained tests cover clarification and dissatisfaction. The unchanged conversation UI's earlier exact-head skill proof covers ordinary messages and typed currency answers. No fixed category registry is introduced. |
| Separate hard constraints from preferences | Both SGD800 and SGD1000 bounds remain in actual Hono state. Below-minimum, above-maximum, wrong-variant, range, quantity and unknown family-fit cases remain ineligible. Current tests cover budget edits and hard-constraint retention. |
| Attributable evidence and explicit uncertainty | Literal safe source quotations are exposed. Correct canonical URL binding passes. Conditional amounts retain literal restrictions; unrelated variant/range amounts are withheld. Stock, delivery and merchant verification remain unknown. |
| Useful answer first | Inspected actual desktop and mobile positive and adverse initial screenshots show the leading response and first product before manual scrolling. The valid price is restored and adverse price limitations are prominent. |
| Concise comparisons and disclosure | Evidence is closed initially, keyboard-expandable, readable after expansion, and does not create document-level horizontal overflow in current journeys. |
| Adapt within session | Current maintained tests and the prior unchanged-UI skill proof cover theme persistence, held comparisons, budget changes, history preservation, cancellation and session isolation. No source change alters those paths. |
| Avoid redundant notifications and chatter | Each explicit current fixture request dispatches exactly one SDK call. Current tests cover ordinary and held messages with zero calls, provider-error recovery, no retry and no fixture fallback. The composer still discloses that shopping submission can trigger paid Exa research. |

## UI inspection and explicitly reused scope

Inspected current desktop/mobile initial positive-heading cards, wrong-variant and range cards, conditional prices and ordinary-price alternative, quantity blocker, optical-family unknown, and expanded literal evidence. The approved minimal header, centered chat, compact bottom composer, theme tokens and disclosure placement are preserved. The source tree contains no client changes from the approved baseline.

Reuse is limited to unchanged scope. The three-viewport project skill was rerun and visually inspected at 651ee11 with cleanup true. Its theme, ordinary-message, ambiguity, contextual-budget, history, cancellation, provider-error and session-isolation paths are reused here because client, conversation service, API application, dependencies, skill and evaluation/browser blobs did not change in the final repair. The eight maintained browser tests and frontend build passed at 5383 and are reused only for unchanged frontend behavior. Current typecheck and the actual SDK/Hono/browser price matrix verify the changed server path. These earlier runs are not claimed as rerun at 33fadc7.

A screenshot preview appeared inconsistent during inspection. A fresh isolated conditional run generated a byte-identical membership PNG, and the browser geometry plus raw PNG text pixels agree on the visible answer, title and condition positions. This did not reproduce an application clipping defect. The retained original screenshot, fresh proof and SHA256 permit independent inspection. No screenshot was scrolled or edited to manufacture an initial-result pass.

## Limits and remaining gates

No real Exa call, private environment, credential, paid ledger, grant, user history or database was accessed. The real user instance was not driven. Automated diagnostic tests use generated fixture files and loopback responses. No raw capture payload or key appears in normal UI/history test results.

Synthetic proof establishes local behavior only. It does not establish current products, exact real variant relevance, current prices, stock, delivery, merchant authorization or paid billing behavior. No raw response exists for the user's original invalid-evidence screenshot, so this review does not claim exact live-payload reproduction. The correct conservative unknown optical-frame result remains intact.

Independent security, final equal-code head binding, CI and repository merge-policy gates remain root's responsibility. This reviewer does not authorize production deployment or changes to sensitive operations.

Prove It Works shaped the decision to require actual Hono, SDK, browser and screenshot evidence, and to keep the passing build separate from runtime and semantic acceptance.
