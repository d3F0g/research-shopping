import { spawnSync } from 'node:child_process';
import path from 'node:path';
const env=Object.fromEntries(['PATH','HOME','TMPDIR','LANG','LC_ALL','TZ'].filter(k=>process.env[k]!==undefined).map(k=>[k,process.env[k]]));
Object.assign(env,{NODE_ENV:'test',EXA_RESEARCH_ENABLED:'false'});
const commands={
  'history-v3-868':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/history-v3-868.ts'],
  'history-browser':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/history-browser.ts'],
  postgres:['.audit/fieldnote-v2/evidence-gap-qa/postgres.mjs'],
  'eval-typecheck':['node_modules/typescript/bin/tsc','--noEmit','-p','evals/v2/tsconfig.json'],
  unit:['--input-type=module','-e',"import { startVitest } from 'vitest/node'; const ctx=await startVitest('test',[],{run:true},{envFile:false}); await ctx.close();"],
  typecheck:['node_modules/typescript/bin/tsc','--noEmit'],
  build:['--input-type=module','-e',"import { build } from 'vite'; await build({envFile:false,build:{outDir:'artifacts/fieldnote-v2/evidence-gap-qa/build',emptyOutDir:false}});"],
  'eval-test':['--import','tsx','--test','evals/v2/tests/integrity.test.ts','evals/v2/tests/semantic.test.ts','evals/v2/tests/transport.test.ts'],
  eval:['--import','tsx','evals/v2/run.ts','--out','artifacts/fieldnote-v2/evidence-gap-qa/fd1f505/corpus','--gate','all'],
  preservation:['evals/v2/verify-preservation.mjs'],
  e2e:['node_modules/@playwright/test/cli.js','test','--config','.audit/fieldnote-v2/evidence-gap-qa/playwright.config.ts'],
  smoke:['.agents/skills/verify-research-shopping/scripts/smoke.mjs'],
  'conditional-probes':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','conditional-probes','explicit-membership,subscription-ordinary-alternative'],
  'money-quantity-x':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','money-quantity-x','money-quantity-x'],
  'money-wrapper':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','money-wrapper','money-wrapper'],
  'partial-qualified':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','partial-qualified','catalog-partial-qualified'],
  'money-suffix':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','money-suffix','money-suffix'],
  'v4-held':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','v4-held','catalog-adverse'],
  'fd1-runtime':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','fd1-runtime','money-wrapper,money-quantity-x,money-currency-ws,money-wordop,money-per-piece,money-excl-tax,open-rtx,open-usb,open-abc,open-pictogram,open-unfamiliar,catalog-whitespace,catalog-peer-sales,catalog-partial-qualified,catalog-adverse'],
  'v4-visual':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','v4-visual','catalog-adverse,catalog-peer-sales,catalog-partial-qualified'],
  'v4-catalog':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','v4-catalog','catalog-whitespace,catalog-peer-sales,catalog-partial-qualified,catalog-collection,catalog-adverse,catalog-long,catalog-multiple,catalog-range,catalog-duplicate,catalog-punctuation'],
  'catalog-probes':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','catalog-probes','catalog-whitespace,catalog-peer-sales,catalog-range,catalog-duplicate,catalog-punctuation'],
  'early-probes':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','early-probes','positive-sentence,positive-heading,positive-canonical-root,heading-for-other-variant,heading-range,range'],
  'positive-probe':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','positive-probe','positive-heading'],
  'blocking-probes':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','blocking-probes','heading-for-other-variant,heading-range,range'],
  'variant-tail-browser':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','variant-tail-browser','heading-for-other-variant'],
  'custom-baseline':['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs','baseline-browser'],
  custom:['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/browser.mjs'],
  projector:['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/projector.ts','artifacts/fieldnote-v2/evidence-gap-qa/fd1f505/candidate-projector.json'],
};
const mode=process.argv[2];if(!(mode in commands))throw new Error('Select explicit owned check');
if(mode==='smoke')Object.assign(env,{VERIFY_API_PORT:'3187',VERIFY_WEB_PORT:'5297',VERIFY_ARTIFACT_DIR:path.join(process.cwd(),'artifacts/fieldnote-v2/evidence-gap-qa/fd1f505/skill-smoke')});
const result=spawnSync(process.execPath,commands[mode],{env,stdio:'inherit'});if(result.error)throw result.error;process.exitCode=result.status??1;
