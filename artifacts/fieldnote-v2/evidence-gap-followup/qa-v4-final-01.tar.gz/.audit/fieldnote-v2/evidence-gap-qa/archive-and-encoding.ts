import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFile,writeFile} from 'node:fs/promises';
import {historicalReportArchive,additionalArchivedReports} from '../../../evals/history-fieldnote-v2/archive';
import {historicalReportDigest,validateHistoricalFieldnoteReport} from '../../../evals/history-fieldnote-v2/report';
import {validCurrentProvenance} from '../../../evals/v2/provenance';
import {projectExaAnswer} from '../../../src/server/exa-research';
import {initialConversation} from '../../../src/domain/conversation';
import {catalogMaterial} from '../../../tests/helpers/v3-catalog-material';
const reports=[];
for(const entry of historicalReportArchive.reports){
 const bytes=execFileSync('git',['show',`${historicalReportArchive.sourceCommit}:${entry.path}`],{maxBuffer:128*1024*1024});
 assert.equal(createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex'),entry.blob);
 const report=JSON.parse(bytes.toString());assert.equal(historicalReportDigest(report),entry.sha256);validateHistoricalFieldnoteReport(report);reports.push({path:entry.path,result:'passed'});
}
for(const entry of additionalArchivedReports){
 const file=(process.argv[3] ?? '/Users/josiahwong/Documents/research-shopping-v2')+'/'+entry.archive;
 assert.equal(createHash('sha256').update(await readFile(file)).digest('hex'),entry.archiveSha256);
 const bytes=execFileSync('tar',['-xOf',file,entry.member],{maxBuffer:128*1024*1024});const report=JSON.parse(bytes.toString());assert.equal(historicalReportDigest(report),entry.sha256);validateHistoricalFieldnoteReport(report);reports.push({archive:entry.archive,member:entry.member,result:'passed'});
}
const intent={...initialConversation().intent,productDescription:'Fixture sunglasses',budget:{minimum:800,maximum:1000,currency:'SGD'}};
const native=catalogMaterial(intent);const encodings=[];
for(const encoding of ['object','json-string']){
 const material={...native,answer:encoding==='object'?native.answer:JSON.stringify(native.answer)};
 const result=projectExaAnswer(material,intent);assert.equal(result.status,'ready');if(result.status!=='ready')throw new Error('Expected ready');
 assert.equal(result.research.products[0]!.price,null);assert.equal(result.research.products[0]!.priceObservation?.amount,868);assert.equal(result.research.products[0]!.priceObservation?.row.context.text,result.research.sources[0]!.text);assert.equal(validCurrentProvenance(result.research,result.research.products[0]!,material as never),true);
 const changed=structuredClone(result.research);const support=changed.products[0]!.identity.support[0]!;support.origin={kind:'provider',reportedQuote:support.literal.text,match:'literal'};assert.equal(validCurrentProvenance(changed,changed.products[0]!,material as never),false);
 for(const answer of ['{','null','[]','{}',' '.repeat(128001)+JSON.stringify(native.answer)])assert.equal(validCurrentProvenance(result.research,result.research.products[0]!,{...native,answer} as never),false);
 encodings.push({encoding,result:'passed',price:result.research.products[0]!.price?.amount,choice:result.research.choice});
}
await writeFile(process.argv[2]!,JSON.stringify({reports,encodings},null,2));console.log(JSON.stringify({reports:reports.length,encodings}));
