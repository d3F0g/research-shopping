import assert from 'node:assert/strict';
import { spawn, execFileSync } from 'node:child_process';
import { createWriteStream } from 'node:fs';
import { mkdir, writeFile } from 'node:fs/promises';
import net from 'node:net';
import path from 'node:path';
import { chromium, expect } from '@playwright/test';
const repo=process.cwd();
const out=path.join(repo,'artifacts/fieldnote-v2/evidence-gap-qa/fd1f505',process.argv[2]??'custom-browser');
await mkdir(out,{recursive:true});
const apiPort=3186, webPort=5296, origin=`http://127.0.0.1:${webPort}`;
const proof={commit:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),composition:'Fixture data only. Owned loopback Hono + actual Exa SDK + browser. No private environment or paid calls.',result:'failed',cleanup:false,cases:[],errors:[]};
const children=[];let browser;const log=createWriteStream(path.join(out,'server.log'));
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function free(port){await new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(port,'127.0.0.1',()=>s.close(resolve));});}
function start(args){const env=Object.fromEntries(['PATH','HOME','TMPDIR','LANG','LC_ALL','TZ'].filter(k=>process.env[k]!==undefined).map(k=>[k,process.env[k]]));Object.assign(env,{NODE_ENV:'test',EXA_RESEARCH_ENABLED:'false',API_PORT:String(apiPort),VITE_API_PORT:String(apiPort),WEB_PORT:String(webPort)});const child=spawn(process.execPath,args,{cwd:repo,env,detached:true,stdio:['ignore','pipe','pipe']});child.stdout.pipe(log,{end:false});child.stderr.pipe(log,{end:false});children.push({child,closed:new Promise(resolve=>child.once('close',resolve))});}
try{
  await free(apiPort);await free(webPort);
  start(['--import','tsx','.audit/fieldnote-v2/evidence-gap-qa/server.ts']);
  start(['--input-type=module','-e',"import { createServer } from 'vite'; const server = await createServer({ envFile: false }); await server.listen();"]);
  let ready=false;for(let i=0;i<100;i++){try{const h=await fetch(`${origin}/api/health`).then(r=>r.json());assert.equal(h.automaticPaidChecks,false);assert.equal(h.provider,'exa');const s=await fetch(`${origin}/api/test-stats`).then(r=>r.json());assert(Array.isArray(s.calls));ready=true;break;}catch{}await delay(200);}assert(ready,'Owned fixture instance ready');
  const {scenarios}=await import('./material.ts');
  browser=await chromium.launch();
  for(const viewport of [{name:'desktop',width:1440,height:1000},{name:'mobile',width:390,height:844},{name:'short-mobile',width:390,height:600}]){
    const context=await browser.newContext({baseURL:origin,viewport,colorScheme:'light',reducedMotion:'reduce'});
    await context.route('**/*',route=>new URL(route.request().url()).origin===origin?route.continue():route.abort('blockedbyclient'));
    await context.tracing.start({screenshots:true,snapshots:true,sources:true});
    const page=await context.newPage();page.setDefaultTimeout(10000);page.on('pageerror',e=>proof.errors.push(e.message));await page.goto(origin);
    await expect(page.locator('html')).toHaveClass('dark');
    for(const scenario of scenarios.filter(s=>!process.argv[3]||process.argv[3].split(',').includes(s.id))){
      const row={viewport:viewport.name,scenario:scenario.id,expectedEligible:scenario.eligible,result:'failed'};proof.cases.push(row);
      const resetResponse=page.waitForResponse(r=>r.url().endsWith('/api/new-chat')&&r.request().method()==='POST');
      await page.getByRole('button',{name:'New chat',exact:true}).click();
      assert.equal((await resetResponse).status(),200);
      await expect(page.getByRole('heading',{name:'What are you looking for?',exact:true})).toBeVisible();
      const setMode=await page.request.post('/api/qa-mode',{data:{mode:scenario.id}});assert.equal(setMode.status(),200);assert.equal((await setMode.json()).mode,scenario.id);
      const before=await page.request.get('/api/test-stats').then(r=>r.json());
      const completed=page.waitForResponse(r=>r.url().endsWith('/api/turn')&&r.request().method()==='POST'&&r.request().postDataJSON()?.phase==='research');
      await page.getByRole('textbox',{name:'Message',exact:true}).fill('request' in scenario ? scenario.request : 'I want sunglasses between SGD 800 and 1000.');
      await page.getByRole('button',{name:'Send message',exact:true}).click();
      const completedResponse=await completed;assert.equal(completedResponse.status(),200);const final=await completedResponse.json();assert.equal(final.kind,'research');
      await expect(page.getByRole('status')).toHaveCount(0);
      const {state}=await page.request.get('/api/session').then(r=>r.json());const research=state.messages.findLast(m=>m.research).research;
      row.choice=research.choice;row.product=research.products[0];row.budget=state.intent.budget;
      const after=await page.request.get('/api/test-stats').then(r=>r.json());row.localProviderCalls=after.calls.length-before.calls.length;assert.equal(after.calls.at(-1).mode,scenario.id);
      assert.equal(row.localProviderCalls,1);assert.equal(research.dataKind,'test-fixture');
      const title=page.getByText(research.products[0].name,{exact:true}).last();await expect(title).toBeVisible();
      await page.evaluate(()=>new Promise(resolve=>{let n=0;const step=()=>++n>=30?resolve():requestAnimationFrame(step);requestAnimationFrame(step);}));
      await page.screenshot({path:path.join(out,`${viewport.name}-${scenario.id}-initial.png`)});
      row.geometry=await title.evaluate(el=>{const r=el.getBoundingClientRect();const s=el.closest('[data-slot="message-scroller-viewport"]').getBoundingClientRect();return {top:r.top,bottom:r.bottom,clipTop:s.top,clipBottom:s.bottom};});
      assert(row.geometry.top>=row.geometry.clipTop&&row.geometry.bottom<=row.geometry.clipBottom,'First product initially in conversation viewport');
      if(['heading-for-other-variant','heading-range','range','heading-quantity'].includes(scenario.id))assert.equal(research.products[0].price,null,'Wrong-variant and range amounts must not masquerade as an exact observed price');
      if('catalog' in scenario){assert.equal(research.evidenceVersion,4);assert.equal(research.choice,null);const p=research.products[0];assert.equal(p.price,null);if(['plain','peers','partial-qualified','collection','adverse'].includes(scenario.catalog)){const o=p.priceObservation;assert.equal(o?.amount,868);assert.equal(o.currency,'SGD');assert.equal(o.attribution.status,'unknown');assert.equal('variant' in o,false);assert.equal(o.reportedConditionsResolved,false);assert.equal(p.requestMatch.status,'unknown');assert.equal(o.row.origin.kind,'source-context');const source=research.sources.find(s=>s.id===o.row.sourceId);assert.equal(o.row.context.text,source.text);assert.equal(o.row.context.start,0);assert.equal(o.row.context.end,source.text.length);assert.equal(source.text.slice(o.row.literal.start,o.row.literal.end),o.row.literal.text);assert.equal(o.reportedAssessment.support[0].origin.reportedQuote,'SGD 868');if(['partial-qualified','collection','adverse'].includes(scenario.catalog))assert(o.row.context.text.includes('SGD 999'));if(scenario.catalog==='adverse'){assert.equal(o.reportedAssessment.status,'contradicted');assert.equal(o.reportedAssessment.rationale,'Fixture provider says this amount does not apply to the chosen variant.');assert.deepEqual(o.reportedConditions,['Fixture provider condition: voucher required.']);assert(o.row.context.text.includes('For Gold only.'));}}else assert.equal(p.priceObservation,null);}
      if('conditions' in scenario){assert.equal(research.products[0].price?.amount,850);assert.equal(research.products[0].price?.conditionsResolved,false);for(const condition of scenario.conditions){assert(research.products[0].price.conditions.includes(condition));await expect(page.getByText(new RegExp(condition))).toBeVisible();}}
      assert.equal(research.products[0].eligible,scenario.eligible);assert.equal(!!research.choice,scenario.eligible);
      assert.deepEqual(row.budget,'request' in scenario ? null : {minimum:800,maximum:1000,currency:'SGD'});
      await expect(page.getByText('Fixture data. Automated test substitute.',{exact:true})).toBeVisible();
      const evidence=page.getByRole('button',{name:`Evidence and tradeoffs for ${research.products[0].name}`,exact:true});
      await evidence.scrollIntoViewIfNeeded();await evidence.focus();await page.keyboard.press('Enter');
      if('catalog' in scenario && ['duplicate','punctuation'].includes(scenario.catalog)){assert.equal(research.products[0].identity.status,'unknown');}else await expect(page.locator('blockquote').first()).toContainText('catalog' in scenario ? 'Fixture Meridian Sunglasses - Silver' : 'Fixture data:');
      await page.evaluate(()=>new Promise(resolve=>{let n=0;const step=()=>++n>=30?resolve():requestAnimationFrame(step);requestAnimationFrame(step);}));
      if(await page.locator('blockquote').count())await page.locator('blockquote').first().scrollIntoViewIfNeeded();
      await page.screenshot({path:path.join(out,`${viewport.name}-${scenario.id}-evidence.png`)});
      if('catalog' in scenario && research.products[0].priceObservation){
        const sourceText=research.products[0].priceObservation.row.context.text;
        const complete=page.locator('blockquote').filter({hasText:'Other Sunglasses - Brown'}).first();
        assert.equal(await complete.textContent(),sourceText);
        await complete.scrollIntoViewIfNeeded();
        await page.screenshot({path:path.join(out,`${viewport.name}-${scenario.id}-complete-context.png`)});
        if(scenario.catalog==='adverse'){
          await complete.evaluate(el=>{const node=el.firstChild;const at=node.textContent.indexOf('For Gold only.');const range=document.createRange();range.setStart(node,at);range.setEnd(node,at+14);const view=el.closest('[data-slot=message-scroller-viewport]');view.scrollTop+=range.getBoundingClientRect().top-view.getBoundingClientRect().top-24;});
          await page.screenshot({path:path.join(out,`${viewport.name}-${scenario.id}-qualifier.png`)});
        }
        const composer=await page.getByRole('textbox',{name:'Message',exact:true}).boundingBox();assert(composer&&composer.y>=0&&composer.y+composer.height<=viewport.height);
      }
      assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
      const session=JSON.stringify(state);assert(!session.includes('fixture-only-key'));assert(!session.includes('diagnosticCapture'));
      if(process.argv[2]==='v4-held' && 'catalog' in scenario){
        row.held=[];
        for(const message of ['That first one looks good.','Show me more details.','Which source supports this?']){
          const completed=page.waitForResponse(r=>r.url().endsWith('/api/turn')&&r.request().postDataJSON()?.phase==='prepare');
          await page.getByRole('textbox',{name:'Message',exact:true}).fill(message);await page.getByRole('button',{name:'Send message',exact:true}).click();
          const response=await (await completed).json();assert.equal(response.kind,'message');const reply=response.state.messages.at(-1);const text=reply.text+' '+(reply.detail??'');
          assert(text.includes('Source row shows SGD 868'));assert(text.includes('SGD 999'));assert(text.includes('For Gold only.'));assert(text.includes('unresolved'));
          const stats=await page.request.get('/api/test-stats').then(r=>r.json());assert.equal(stats.calls.length,after.calls.length);
          for(const old of state.messages)assert(response.state.messages.some(m=>JSON.stringify(m)===JSON.stringify(old)));
          row.held.push({message,kind:response.kind,providerCalls:0,reply});
        }
        await page.screenshot({path:path.join(out,`${viewport.name}-${scenario.id}-held.png`)});
      }
      row.result='passed';
    }
    await context.tracing.stop({path:path.join(out,`${viewport.name}-trace.zip`)});await context.close();
  }
  assert.deepEqual(proof.errors,[]);proof.result='passed';
}catch(error){proof.error=error.stack;process.exitCode=1;}finally{
  if(browser)await browser.close();
  for(const {child,closed}of children.reverse()){try{process.kill(-child.pid,'SIGTERM');}catch(e){if(e.code!=='ESRCH')throw e;}await Promise.race([closed,delay(3000)]);try{process.kill(-child.pid,'SIGKILL');}catch(e){if(e.code!=='ESRCH')throw e;}await closed;}
  await free(apiPort);await free(webPort);proof.cleanup=true;await new Promise(resolve=>log.end(resolve));await writeFile(path.join(out,'proof.json'),JSON.stringify(proof,null,2));console.log(JSON.stringify({result:proof.result,cases:proof.cases.length,cleanup:proof.cleanup,artifact:out}));
}
