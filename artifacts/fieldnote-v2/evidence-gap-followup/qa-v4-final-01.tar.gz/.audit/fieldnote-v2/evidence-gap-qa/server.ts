import { createServer } from 'node:http';
import { serve } from '@hono/node-server';
import { createApp } from '../../../src/server/app';
import { configFromEnvironment } from '../../../src/server/config';
import { createConversationService } from '../../../src/server/conversations';
import { createExaProductResearch } from '../../../src/server/exa-research';
import { materialFor, scenarios } from './material';
import type { ShoppingIntent } from '../../../src/domain/conversation';
if(process.env.NODE_ENV!=='test'||process.env.EXA_RESEARCH_ENABLED!=='false') throw new Error('Explicit offline fixture composition only');
let mode='positive-sentence';
const calls: { mode: string; query: string }[]=[];
const upstream=createServer(async(req,res)=>{
  if(req.url!=='/answer'){res.writeHead(404).end();return;}
  let body='';for await(const chunk of req) body+=chunk;
  const input=JSON.parse(body);
  const intent=JSON.parse(input.systemPrompt.split('Current authoritative shopping intent: ')[1]) as ShoppingIntent;
  calls.push({mode,query:input.query});
  res.setHeader('content-type','application/json');res.end(JSON.stringify(materialFor(intent,mode)));
});
await new Promise<void>(resolve=>upstream.listen(0,'127.0.0.1',resolve));
const address=upstream.address();if(!address||typeof address==='string')throw new Error('No owned upstream');
const sdk=createExaProductResearch('fixture-only-key',{baseUrl:`http://127.0.0.1:${address.port}`,timeoutMs:1000});
const seen=new Set<string>();
const conversations=createConversationService({research:async(request,signal)=>{const result=await sdk(request,signal);if(result.status==='ready')result.research.dataKind='test-fixture';return result;},quota:{reserve:async id=>{if(seen.has(id))return 'duplicate';seen.add(id);return 'admitted';},settle:async()=>{}}});
const config=configFromEnvironment(process.env);const app=createApp({conversations},config);
app.get('/api/test-stats',c=>c.json({calls}));
app.post('/api/qa-mode',async c=>{const v=c.get("payload") as {mode:string};if(!scenarios.some(s=>s.id===v.mode))return c.json({error:'unknown fixture'},400);mode=v.mode;return c.json({mode,label:'Fixture data only'});});
serve({fetch:app.fetch,hostname:'127.0.0.1',port:config.apiPort});
