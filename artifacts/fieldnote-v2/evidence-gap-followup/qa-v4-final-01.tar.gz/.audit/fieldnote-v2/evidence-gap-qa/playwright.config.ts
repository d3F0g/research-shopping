import {defineConfig,devices} from '@playwright/test';
import {mkdirSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const repo=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const captureRoot=path.join(repo,'artifacts/fieldnote-v2/evidence-gap-qa/maintained-e2e-cwd');
mkdirSync(captureRoot,{recursive:true});
process.chdir(captureRoot);
export default defineConfig({
  testDir:path.join(repo,'tests/e2e'),fullyParallel:true,workers:1,reporter:'list',timeout:30000,expect:{timeout:6000},outputDir:path.join(repo,'artifacts/fieldnote-v2/evidence-gap-qa/e2e'),
  use:{baseURL:'http://127.0.0.1:5298',trace:'retain-on-failure',screenshot:'only-on-failure',video:'retain-on-failure'},
  projects:[{name:'chromium',use:{...devices['Desktop Chrome']}}],
  webServer:{cwd:repo,command:'node --import tsx .audit/fieldnote-v2/evidence-gap-qa/launch.mjs',url:'http://127.0.0.1:5298/api/health',reuseExistingServer:false,timeout:60000,env:{NODE_ENV:'test',EXA_RESEARCH_ENABLED:'false',API_PORT:'3188',VITE_API_PORT:'3188',WEB_PORT:'5298'}},
});
