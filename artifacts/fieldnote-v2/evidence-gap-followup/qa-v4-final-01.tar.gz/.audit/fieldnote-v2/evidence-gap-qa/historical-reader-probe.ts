import {readFile,writeFile} from 'node:fs/promises';
import {validateHistoricalFieldnoteReport} from '../../../evals/history-fieldnote-v2/report';
import {summarize} from '../../../evals/frozen-v4/report';
const original=JSON.parse(await readFile('artifacts/fieldnote-v2/conversation-polish/full60/report.json','utf8'));
const results=[];
for(const mode of ['original','delete-checks','rewrite-checks']){
 const report=structuredClone(original);
 if(mode!=='original'){
  for(const row of report.cases){if(mode==='delete-checks')row.checks=[];else for(const check of row.checks)check.status='pass';row.verdict='pass';}
  report.summary=summarize(report.cases);
 }
 let accepted=true;let error;
 try{validateHistoricalFieldnoteReport(report);}catch(e){accepted=false;error=String(e);}
 results.push({mode,accepted,error,summary:report.summary});
}
await writeFile(process.argv[2]!,JSON.stringify(results,null,2));
console.log(JSON.stringify(results.map(({mode,accepted})=>({mode,accepted}))));
if(results.some(r=>r.mode==='original'?!r.accepted:r.accepted))process.exitCode=1;
