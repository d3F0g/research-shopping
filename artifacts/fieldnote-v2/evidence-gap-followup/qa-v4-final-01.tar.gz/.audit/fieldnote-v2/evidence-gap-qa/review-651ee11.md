# ISSUES

Goal. Preserve the approved Fieldnote V2 chat while fixing actual research and evidence defects before PR 53 passes its gates.

Independent reviewer. Base `e81b890dbf421d2ad65c551c5e404ca5e656d5f5`. Exact reviewed head `651ee11ddafdc4103f02390513981acfd6a2dc32`. This reviewer authored no application, test, evaluation or skill changes. Tracked diff is empty. Only owned audit/artifact files and the pre-existing dependency symlink are untracked. No GitHub mutations, paid calls, private environment, key, ledger, grant, database or user instance were accessed.

## Blocking regression

The unchanged independent positive controls fail after the price-context tightening. A benign identity sentence containing `exact variant Model A` makes an ordinary exact SGD850 price unbound. The same sentence, standalone heading and root-URL positive cases passed at 5383a70.

The complete synthetic passage is:

```
Fixture data: Fixture Sunglasses Model A is a sunglasses product, exact variant Model A.
Model A
Price: SGD 850
Tax included.
```

The accepted shopper request is sunglasses between SGD800 and SGD1000. All native synthetic assessments bind literal source quotations, exact identity, complete fit and hard requirements. The source price is exact Model A, explicit SGD850, with tax included. Yet the current projector sets price null and choice null. The actual UI displays `No qualifying observed price`.

Root cause observed in current code. The expanded `monetaryContext` matches `variant` in the benign identity sentence. The sentence is not a price assertion, so the new early `unbound` return prevents the later exact amount from being assessed. The independent projector reports 17/20 pass, with all three positive controls failing. No expected assertion was weakened.

Reproduce:

```
node .audit/fieldnote-v2/evidence-gap-qa/checks.mjs projector
node .audit/fieldnote-v2/evidence-gap-qa/checks.mjs positive-probe
```

The second command drives actual Hono, Exa SDK, owned loopback HTTP and Chromium. Its fixture is labeled throughout. Evidence is under `artifacts/fieldnote-v2/evidence-gap-qa/651ee11/positive-probe/`. Inspect `desktop-positive-heading-initial.png` and `proof.json`. The browser assertion fails expected eligibility true after capturing the rendered failure. Cleanup succeeds. The complete independent matrix is `651ee11/candidate-projector.json`.

## Previous finding

The wrong-variant and range amount is now withheld rather than displayed as a single selected-variant amount. The actual six desktop/mobile probe journeys pass, and inspected initial screenshots show `No qualifying observed price`. Complete literal context remains in evidence. These probes are in `651ee11/blocking-probes/`. Because their source also contains the benign identity sentence, the new positive regression can mask their targeted adverse behavior. The active source tests independently cover adverse cards without that sentence. Acceptance still requires both positive and adverse cases together after repair.

## Current-head checks

All commands use `.audit/fieldnote-v2/evidence-gap-qa/checks.mjs` with an allowlisted child environment, NODE_ENV=test, EXA_RESEARCH_ENABLED=false and Vite envFile:false where applicable.

| Check | Result |
| --- | --- |
| unit | 240 tests passed across 9 files. |
| eval-test | 21 tests passed. Includes the active query oracle's 12 negative query mutations plus missing current system prompt, and a positive control. |
| eval | All 60 frozen scenarios executed across 140 turns. 11 passed, 0 failed, 48 blocked, 1 unsupported, 0 critical failures and 0 infrastructure errors. Acceptance is inconclusive. The strict all gate exits 1 because blocked and unsupported cases do not establish semantic acceptance. |
| projector | 17/20 pass. The three original exact positive price controls fail. |
| blocking-probes | 6/6 actual SDK/Hono/browser desktop/mobile cases pass withholding. |
| positive-probe | Failed at real browser eligibility as described above. |
| preservation | 389 committed frozen assets unchanged. |

Active oracle review. The only acceptance change binds parsed query JSON exactly to authoritative product description, both optional budget bounds and currency, every requirement text and strength, and region. It still requires complete authoritative intent in the system prompt. The new mutation loop rejects old description-only query, stale or missing fields, changed objective, missing minimum, missing currency, altered maximum or currency, missing/altered requirements, changed strength, missing/changed region, extra stale data and absent system prompt. Assertion version advances to 1.1.0. This does not fabricate semantic evidence or turn blocked cases into pass.

## Seven principles and reused scope

1. Objective and useful clarification retain the earlier exact-head 5383 browser proof. The 651 project skill rerun is recorded separately below.
2. Hard constraints and both bounds remain explicit in actual 651 request state. Wrong-variant and range probes preserve SGD800 to SGD1000 and stay ineligible.
3. Literal evidence and source uncertainty remain present. The benign price-context regression blocks acceptance of attributable valid evidence. Existing optical-family unknown remains a legitimate ineligible comparison.
4. The inspected 651 initial wrong-variant/range and positive-failure screenshots retain the visible first product and useful leading message. A valid useful price is nevertheless lost in the positive case.
5. Evidence stays behind keyboard-operable disclosure and quotations remain readable. No horizontal overflow measured in driven 651 cases.
6. Client/theme/composer/history implementation is unchanged from 5383. Its eight maintained browser tests and build are reused only for that unchanged scope; they are not described as rerun on 651.
7. Each 651 fixture submission invokes exactly one actual SDK call to the owned loopback provider. No paid transport, retry, fixture fallback, private capture payload or secret appears in normal history.

The review remains ISSUES until the positive price regression is fixed and independently reverified. No live product usefulness or exact original screenshot payload is established. No raw live payload exists. All synthetic claims remain visibly fixture data.

Current-head completion. `checks.mjs typecheck` passed. `checks.mjs smoke` passed all three viewports with cleanup true. Inspected actual current-head desktop and mobile initial-result screenshots and short-mobile evidence screenshot. Approved geometry, readable evidence and accessible composer remain intact. The smoke composition lacks the benign `exact variant` source wording and therefore does not cover the blocking regression. Its dirty-worktree marker reflects reviewer audit files and the existing dependency symlink; tracked diff remains empty.
