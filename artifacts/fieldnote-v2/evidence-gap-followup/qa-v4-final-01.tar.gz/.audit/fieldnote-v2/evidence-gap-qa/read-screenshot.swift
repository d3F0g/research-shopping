import Foundation
import Vision
let request = VNRecognizeTextRequest()
request.recognitionLevel = .accurate
let handler = VNImageRequestHandler(url: URL(fileURLWithPath: CommandLine.arguments[1]))
try handler.perform([request])
for observation in request.results ?? [] {
    if let text = observation.topCandidates(1).first?.string {
        print(String(format: "%.3f %.3f %@", observation.boundingBox.minY, observation.boundingBox.maxY, text))
    }
}
