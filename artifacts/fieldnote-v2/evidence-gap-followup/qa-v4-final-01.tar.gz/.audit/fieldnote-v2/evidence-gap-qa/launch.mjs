if(process.env.NODE_ENV!=='test'||process.env.EXA_RESEARCH_ENABLED!=='false')throw new Error('Explicit fixture composition only');
await import('../../../tests/helpers/browser-server.ts');
const {createServer}=await import('vite');
const server=await createServer({envFile:false});await server.listen();
