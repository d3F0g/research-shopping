import {fixtureDatabase} from '../../../scripts/test-postgres.mjs';
import {startVitest} from 'vitest/node';
if(process.env.NODE_ENV!=='test'||process.env.EXA_RESEARCH_ENABLED!=='false'||process.env.FIELDNOTE_TEST_DATABASE_URL)throw new Error('Fresh owned PostgreSQL fixture only');
const fixture=await fixtureDatabase();
try{process.env.FIELDNOTE_TEST_DATABASE_URL=fixture.url;const ctx=await startVitest('test',[],{run:true,config:'vitest.postgres.config.ts'},{envFile:false});await ctx.close();}finally{await fixture.stop();}
