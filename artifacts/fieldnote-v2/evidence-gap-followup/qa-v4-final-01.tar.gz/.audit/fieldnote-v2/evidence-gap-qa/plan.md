# Independent evidence-gap QA

Goal. Preserve the user-approved Fieldnote V2 chat while fixing demonstrated evidence defects for issue 55. Root owns PR 53 merging and GitHub tracking. This reviewer did not author the fix and will not edit application, package, test, evaluation or skill files.

Reviewed baseline. e81b890dbf421d2ad65c551c5e404ca5e656d5f5. Final candidate awaits root assignment. Dependency symlink `node_modules` is pre-existing. Only this audit directory and the corresponding artifacts directory are reviewer-owned writes.

Throughput checkpoint. Not applicable to product measurements. Preparation is a reusable explicit fixture harness, then exact-commit package checks, frozen 60-scenario evaluation and actual owned-loopback browser proof.

Runtime boundary. NODE_ENV=test and EXA_RESEARCH_ENABLED=false. No private environment, real Exa call, key, ledger, grant, database or user history. The local Exa SDK contacts only an owned HTTP substitute. Fixture claims remain visibly labeled. No live screenshot payload exists, so this cannot claim exact live-payload reproduction or live product usefulness.

Acceptance matrix.

| Principle | Required proof |
| --- | --- |
| Understand objective | Preserve complete sunglasses request and typed currency clarification; unfamiliar class remains valid. |
| Separate hard constraints | Both budget bounds survive editor changes; family identity or unknown fit cannot be sufficient. |
| Attributable evidence and uncertainty | Exact source quotes; canonical URLs; unsafe URLs rejected; price conditions remain explicit; optical frame family remains unresolved. |
| Useful answer first | Initial recommendation and first product intersect visible conversation viewport at desktop and mobile, before manual scrolling. |
| Concise comparisons | Evidence disclosures closed initially, keyboard operable, quotations readable after expansion. |
| Session adaptation | Held comparisons cost no call, edits preserve history, theme persists, no session leakage. |
| Avoid redundant chatter | Ordinary messages cost no research call, one bounded SDK call per submitted research, error no retry or fixture fallback. |

Price and source controls. Positive exact variant 850 SGD, tax included, ordinary exact heading/Price layout and URL root canonicalization. Adverse membership, voucher, mandatory fees, range, wrong variant, bare dollar, negative tax, unavailable fit, product-family identity and absent money. No assertion changes to accommodate candidate mistakes. Existing cut provenance and unknown evidence gates remain required.

Exact-head commands will use separate owned ports and output directories. Retain logs, proof, traces, screenshots, full corpus report and checksums. Inspect screenshots directly before a visual verdict. Passing build alone is not runtime acceptance.

Prove It Works shaped the decision to require actual Hono, SDK and browser evidence at the assigned commit. The skill leaf was read this session.
