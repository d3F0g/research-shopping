import { catalogMaterial } from '../../../tests/helpers/v3-catalog-material';
import { nativeMaterial } from '../../../tests/helpers/v2-material';
import type { ShoppingIntent } from '../../../src/domain/conversation';
export const scenarios = [
  { id: 'money-currency-ws', eligible: false, price: '', moneyOnly: true, moneyQuote: '35 Singapore\ndollars', request: 'I want a USB-C powerbank.' },
  { id: 'money-wordop', eligible: false, price: '', moneyOnly: true, moneyQuote: 'SGD 35 plus SGD 5', request: 'I want a USB-C powerbank.' },
  { id: 'money-per-piece', eligible: false, price: '', moneyOnly: true, moneyQuote: 'SGD 35 per piece', request: 'I want a USB-C powerbank.' },
  { id: 'money-excl-tax', eligible: false, price: '', moneyOnly: true, moneyQuote: 'SGD 35 excl. GST', request: 'I want a USB-C powerbank.' },
  { id: 'open-rtx', eligible: true, price: '', model: 'RTX4080', request: 'I want RTX4080.' },
  { id: 'open-usb', eligible: true, price: '', model: 'USB3', request: 'I want USB3.' },
  { id: 'open-abc', eligible: true, price: '', model: 'ABC35', request: 'I want ABC35.' },
  { id: 'open-pictogram', eligible: true, price: '', model: '🔬35', request: 'I want 🔬35.' },
  { id: 'open-unfamiliar', eligible: true, price: '', model: 'Fixture Orinth lunar spectrometer 7', request: 'I want Fixture Orinth lunar spectrometer 7.' },
  { id: 'money-quantity-x', eligible: false, price: '', moneyOnly: true, moneyQuote: 'SGD 35 x 3', request: 'I want a USB-C powerbank.' },
  { id: 'money-wrapper', eligible: false, price: '', moneyOnly: true, moneyQuote: '(35 SGD)', request: 'I want a USB-C powerbank.' },
  { id: 'catalog-partial-qualified', eligible: false, price: '', catalog: 'partial-qualified' },
  { id: 'money-suffix', eligible: false, price: '', moneyOnly: true, request: 'I want a USB-C powerbank.' },
  { id: 'catalog-collection', eligible: false, price: '', catalog: 'collection' },
  { id: 'catalog-adverse', eligible: false, price: '', catalog: 'adverse' },
  { id: 'catalog-long', eligible: false, price: '', catalog: 'long' },
  { id: 'catalog-multiple', eligible: false, price: '', catalog: 'multiple' },
  { id: 'catalog-whitespace', eligible: false, price: '', catalog: 'plain' },
  { id: 'catalog-peer-sales', eligible: false, price: '', catalog: 'peers' },
  { id: 'catalog-range', eligible: false, price: '', catalog: 'range' },
  { id: 'catalog-duplicate', eligible: false, price: '', catalog: 'duplicate' },
  { id: 'catalog-punctuation', eligible: false, price: '', catalog: 'punctuation' },
  { id: 'positive-sentence', eligible: true, price: 'Model A costs SGD 850 for one unit, tax included.' },
  { id: 'positive-heading', eligible: true, price: 'Model A\nPrice: SGD 850\nTax included.' },
  { id: 'heading-for-other-variant', eligible: false, price: 'Model A\nPrice: SGD 850\nFor Model B only.' },
  { id: 'heading-wrong-variant', eligible: false, price: 'Model B\nPrice: SGD 850\nTax included.' },
  { id: 'heading-membership', eligible: false, price: 'Model A\nPrice: SGD 850\nTax included.\nThe price applies only to members.' },
  { id: 'heading-fees', eligible: false, price: 'Model A\nPrice: SGD 850\nTax included.\nMandatory shipping is SGD 200 extra.' },
  { id: 'heading-range', eligible: false, price: 'Model A\nPrice: SGD 850 to SGD 1200\nTax included.' },
  { id: 'heading-bare-dollar', eligible: false, price: 'Model A\nPrice: $850\nTax included.' },
  { id: 'positive-canonical-root', eligible: true, price: 'Model A costs SGD 850 for one unit, tax included.', root: true },
  { id: 'explicit-membership', eligible: false, price: 'Model A costs SGD 850 for one unit, tax included. This price requires a membership.', conditions: ['This price requires a membership'] },
  { id: 'subscription-ordinary-alternative', eligible: false, price: 'Model A costs SGD 850 for one unit, tax included. This price requires a subscription. The ordinary Model A price is SGD 1200.', conditions: ['This price requires a subscription', 'The ordinary Model A price is SGD 1200'] },
  { id: 'heading-quantity', eligible: false, price: 'Model A\nPrice: SGD 850\nFor two units.' },
  { id: 'membership', eligible: false, price: 'Model A costs SGD 850 for one unit, tax included. The price applies only to members.' },
  { id: 'voucher', eligible: false, price: 'Model A costs SGD 850 with a membership voucher, tax included.' },
  { id: 'mandatory-fees', eligible: false, price: 'Model A costs SGD 850 for one unit, tax included. Model A requires SGD 200 shipping in addition.' },
  { id: 'range', eligible: false, price: 'Model A costs SGD 850 to SGD 1200 depending on configuration, tax included.' },
  { id: 'wrong-variant', eligible: false, price: 'Model A costs SGD 1200 while Model B costs SGD 850, tax included.' },
  { id: 'bare-dollar', eligible: false, price: 'Model A costs $850 for one unit, tax included.' },
  { id: 'negative-tax', eligible: false, price: 'Model A costs SGD 850, not tax included.' },
  { id: 'below-minimum', eligible: false, price: 'Model A costs SGD 750 for one unit, tax included.', amount: 750 },
  { id: 'above-maximum', eligible: false, price: 'Model A costs SGD 1100 for one unit, tax included.', amount: 1100 },
  { id: 'optical-family-unknown', eligible: false, price: '', family: true },
  { id: 'no-longer-available', eligible: false, price: 'Model A costs SGD 850 for one unit, tax included. Model A is no longer available.' },
] as const;
export function materialFor(intent: ShoppingIntent, id: string) {
  const scenario = scenarios.find(row => row.id === id);
  if (!scenario) throw new Error('Unknown explicit fixture scenario');
  if ('model' in scenario) {
    const material = JSON.parse(JSON.stringify(nativeMaterial(intent))) as ReturnType<typeof nativeMaterial>; const p = material.answer.products[0]!; p.name = 'Fixture Product Model A';
    const text = `Fixture data: Fixture Product Model A is the product ${scenario.model}.`; material.citations[0]!.text = text;
    for(const a of [p.identity,p.requestMatch,...p.criteria.map(c=>c.assessment)]) a.support = [{url:material.citations[0]!.url,quote:text}];
    p.requestMatch.support = [{url:material.citations[0]!.url,quote:scenario.model}]; p.attributes = []; (p as unknown as {price:null}).price = null; return material;
  }
  if ('moneyOnly' in scenario) {
    const material = JSON.parse(JSON.stringify(nativeMaterial(intent))) as ReturnType<typeof nativeMaterial>;
    const product = material.answer.products[0]!;
    const quote = 'moneyQuote' in scenario ? scenario.moneyQuote : '35 SGD';
    const text = `Fixture data: Fixture Powerbank Model A is a USB-C powerbank. Model A costs ${quote} for one unit, tax included.`;
    material.citations[0]!.text = text;
    for (const a of [product.identity, product.requestMatch, ...product.criteria.map(c=>c.assessment), ...product.attributes.map(a=>a.assessment), product.price.assessment]) a.support = [{url:material.citations[0]!.url,quote:text}];
    product.requestMatch.support = [{url:material.citations[0]!.url,quote}];
    return material;
  }
  if ('catalog' in scenario) {
    const material = catalogMaterial(intent);
    if (scenario.catalog === 'collection') material.citations[0]!.text += '\n\nSpring collection\n\nSGD 999';
    if (scenario.catalog === 'adverse') { material.citations[0]!.text += '\n\nNew Silver colorway\n\nSGD 999\n\nFor Gold only.'; material.answer.products[0]!.price.assessment.status = 'contradicted'; material.answer.products[0]!.price.assessment.rationale = 'Fixture provider says this amount does not apply to the chosen variant.'; material.answer.products[0]!.price.conditions = ['Fixture provider condition: voucher required.']; }
    if (scenario.catalog === 'long') material.citations[0]!.text += '\n\n' + 'Fixture filler '.repeat(300);
    if (scenario.catalog === 'multiple') material.citations[0]!.text = material.citations[0]!.text.replace('SGD 868', 'SGD 868 SGD 500');
    if (scenario.catalog === 'partial-qualified') material.citations[0]!.text += '\n\nMeridian Sunglasses - Silver (standard)\n\nSGD 999';
    if (scenario.catalog === 'peers') material.citations[0]!.text = 'Fixture Other Eyeglasses - Black\n\n SGD 547 SGD 268 (51% off)\n\nFixture Other Brand Silver Navigator Sunglasses\n\n SGD 490 SGD 243 (50% off)\n\n' + material.citations[0]!.text;
    if (scenario.catalog === 'range') material.citations[0]!.text = material.citations[0]!.text.replace('SGD 868', 'SGD 868–1200');
    if (scenario.catalog === 'duplicate') material.citations[0]!.text += '\n\nFixture Meridian Sunglasses - Silver SGD 868';
    if (scenario.catalog === 'punctuation') material.answer.products[0]!.identity.support[0]!.quote = 'Fixture Meridian Sunglasses — Silver SGD 868';
    return material;
  }
  const raw = JSON.parse(JSON.stringify(nativeMaterial(intent))) as ReturnType<typeof nativeMaterial>;
  const p = raw.answer.products[0]!;
  p.name = 'Fixture Sunglasses Model A';
  p.price.amount = 'amount' in scenario ? scenario.amount : 850;
  const url = 'root' in scenario ? 'https://manufacturer.com' : 'https://manufacturer.com/model-a';
  const text = 'family' in scenario
    ? 'Fixture data: Fixture Optical Frame Model A is an optical frame product family. Sunglasses fit, exact variant, qualifying observed price, stock and delivery are unknown.'
    : `Fixture data: Fixture Sunglasses Model A is a sunglasses product, exact variant Model A.\n${scenario.price}`;
  raw.citations = [{ url, title: 'Fixture data model page', text, image: 'https://manufacturer.com/model-a.png' }];
  for (const a of [p.identity, p.requestMatch, ...p.criteria.map(c=>c.assessment), ...p.attributes.map(c=>c.assessment), p.price.assessment]) {
    a.support = [{ url, quote: text }];
    a.rationale = 'Fixture data: synthetic source assessment, not live research.';
  }
  if ('family' in scenario) {
    p.name = 'Fixture Optical Frame Model A';
    p.identity.scope = 'product-family' as typeof p.identity.scope;
    p.requestMatch.status = 'unknown' as typeof p.requestMatch.status;
    p.requestMatch.rationale = 'Fixture data: complete sunglasses fit remains unknown.';
    for (const c of p.criteria) c.assessment.status = 'unknown' as typeof c.assessment.status;
    (p as unknown as {price:null}).price = null;
  }
  return raw;
}
