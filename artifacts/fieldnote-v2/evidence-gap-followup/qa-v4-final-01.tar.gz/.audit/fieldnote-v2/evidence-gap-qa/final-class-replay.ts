import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {projectExaAnswer} from '../../../src/server/exa-research';
import {isMonetaryOnlyEvidence} from '../../../src/server/price-evidence';
const base='artifacts/fieldnote-v2/evidence-gap-qa/';
const original=JSON.parse(await readFile(base+'ccfb87c/consolidated-counterexamples.json','utf8'));
const saved=JSON.parse(await readFile(base+'8ea7db2/class-probes.json','utf8'));
const monetary=[...original.money,...saved.extra.filter((x:{quote:string})=>!['RTX4080','USB3','ABC35','🔬35'].includes(x.quote))];
for(const item of monetary){const result=projectExaAnswer(item.material,item.result.research.intent);assert.equal(result.status,'ready');if(result.status!=='ready')throw new Error('Expected fixture comparison');assert.equal(result.research.products[0]!.requestMatch.status,'unknown',item.quote);assert.equal(result.research.choice,null,item.quote);}
const phrases=['SGD35 plus SGD5','SGD35 minus SGD5','SGD35 times 3','SGD35 each','SGD35 per piece','SGD35 excl. GST','SGD35 incl. tax','SGD35 multiplied by 3','35 United\nStates\tdollars'];
for(const text of phrases)assert.equal(isMonetaryOnlyEvidence(text,['SGD']),true,text);
const models=['RTX4080','USB3','ABC35','🔬35','Fixture Orinth lunar spectrometer 7'];
for(const text of models)assert.equal(isMonetaryOnlyEvidence(text,['SGD']),false,text);
for(const item of original.peers){const result=projectExaAnswer(item.material,item.result.research.intent);assert.equal(result.status,'ready');if(result.status!=='ready')throw new Error('Expected fixture observation');const p=result.research.products[0]!;assert.equal(p.price,null);assert.equal(p.priceObservation?.amount,868);assert.equal(p.priceObservation?.row.context.text,result.research.sources[0]!.text);assert(p.priceObservation?.row.context.text.includes('SGD 999'));assert.equal('variant' in p.priceObservation!,false);assert.equal(p.priceObservation?.attribution.status,'unknown');}
const result={monetaryCases:monetary.length,phrases:phrases.length,models:models.length,peerCases:original.peers.length,result:'passed'};
await writeFile(process.argv[2]!,JSON.stringify(result,null,2));console.log(JSON.stringify(result));
