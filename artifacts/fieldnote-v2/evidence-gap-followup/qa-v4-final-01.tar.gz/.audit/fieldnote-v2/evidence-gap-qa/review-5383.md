# ISSUES

Goal. Preserve the approved Fieldnote V2 chat appearance while fixing actual research and evidence bugs before PR 53 can satisfy its gates.

Independent reviewer. This reviewer did not author the application, tests, evaluation assertions or skill. Base `e81b890dbf421d2ad65c551c5e404ca5e656d5f5`. Reviewed head `5383a70e9ac54e322006e359c2a59d608851deab`. No tracked source edits. Only reviewer audit/artifact files and a pre-existing dependency symlink are untracked. Root owns merging and GitHub tracking. No external comments, issues, pushes or merges were created.

## Blocking product finding

A wrong-variant qualifier or price range can now retain an amount under the selected exact variant. The card shows a bold single amount with generic `Conditions unresolved`. The literal range or different variant is hidden until evidence expands. Recommendation eligibility correctly remains false, but the initial price presentation implies a selected-product observation that the retained source does not establish.

Reproduce `node .audit/fieldnote-v2/evidence-gap-qa/checks.mjs variant-tail-browser`. This starts an explicit owned fixture Hono service and actual Exa SDK against a loopback upstream, then drives desktop/mobile. The shopper requests sunglasses between SGD 800 and 1000. The returned source contains `Model A\nPrice: SGD 850\nFor Model B only.`. The resulting price remains amount 850, currency SGD, variant Model A, conditions empty, conditionsResolved false, assessment unknown with exact-variant scope. Choice remains null. The initial card displays `SGD 850.00 observed, unverified` and generic unresolved conditions. The incompatible variant is only in expanded quotation.

A second source `Model A\nPrice: SGD 850 to SGD 1200\nTax included.` produces the same single 850 display. See `artifacts/fieldnote-v2/evidence-gap-qa/custom-browser/desktop-heading-range-initial.png`, its evidence screenshot, and the corresponding mobile screenshots. `variant-tail-probe.json` retains the exact projection. `variant-tail-browser/` retains actual UI, payload and traces.

This violates attributable price context and useful-answer-first principles. A safe repair must retain the full qualifier or avoid presenting the amount as the selected exact price. Merely leaving the recommendation null does not resolve the display finding.

## Completed checks

Commands run from `/Users/josiahwong/Documents/research-shopping-v2-evidence-qa`. The owned checks wrapper allowlists environment variables, sets NODE_ENV=test and EXA_RESEARCH_ENABLED=false, disables Vite environment-file loading, and writes output beneath the assigned artifact directory.

| Command suffix after `node .audit/fieldnote-v2/evidence-gap-qa/checks.mjs` | Result |
| --- | --- |
| unit | 227 tests passed in 9 files. Includes real SDK socket cancellation, URL/source boundaries, private opt-in diagnostics and quota doubles. |
| typecheck | Passed. |
| build | Passed, with the existing bundle-size advisory. |
| e2e | All 8 maintained browser tests passed. |
| projector | 19/19 intended projection assertions passed before adding the explicit wrong-variant tail display probe. |
| custom | 38/38 desktop/mobile eligibility journeys passed. Each completed fixture request dispatches exactly one local provider call. These original assertions check eligibility, not complete price display. The screenshots reveal the display finding above. |
| smoke | Project verification helper passed desktop, mobile and short-mobile journeys, cleanup true. |
| eval | All 60 frozen cases executed. 59 failed solely at the old query oracle and one was unsupported. The candidate now sends structured authoritative intent while the old oracle requires query equal to productDescription. Root separately authorized a narrow current-oracle update. No acceptance pass claimed here. |

## All seven principles

1. Objective and material clarification passed in the skill journey. Ordinary hello stays local. Typed SGD preserves original powerbank request and both bounds, automatically dispatching research.
2. Hard constraints remain separate and accepted bounds survive maximum edits. Optical product-family identity and unknown sunglasses fit remain ineligible. No fixture is promoted to proof of real relevance.
3. Literal quotations and safe source links passed. The blocking price display finding remains. The root-URL binding positive now passes. Membership, vouchers, mandatory fees, wrong variants, bare dollars, ranges, unavailable products and budget bounds remain ineligible in synthetic controls.
4. Initial recommendation and first product intersect the actual visible conversation area at 1440x1000, 390x844 and 390x600. The price qualifier finding limits useful-answer acceptance.
5. Evidence stays behind keyboard-operable disclosure. Actual expanded screenshots show readable quotations. No page-level horizontal overflow was measured in the custom matrix.
6. Theme persistence, held comparisons without provider calls, contextual budget edits, unchanged historical snapshots, cancellation and session isolation passed the skill and maintained suites.
7. Ordinary messages and held comparisons spend no provider call. Explicit fixture submissions each invoke one SDK call. Provider errors retain requests and do not select fixture fallback or automatically retry.

## Visual inspection

Inspected actual desktop/mobile/short-mobile initial-result and evidence images, desktop light empty state and short-mobile contextual editor. Minimal header, centered chat and bottom composer preserve approved placement. First visits default dark in OS-light contexts. The composer remains readable and accessible while conversation content scrolls. Product-family optical-frame screenshot visibly states unknown fit and no qualifying observed price. Application client files are unchanged from the baseline.

## Evidence limitations

No genuine Exa retrieval, current product usefulness, live prices, stock, delivery, merchant authorization, live billing, database or account acceptance is established. No raw payload exists for the user's original screenshot, so this is not exact live-payload reproduction. No private environment, key, ledger, grant or user instance was accessed. All synthetic claims are labeled fixture data. The stopped billing record and manual grant were not accessed or changed.

The smoke proof reports cleanCandidate false because reviewer-owned audit files and the pre-existing node_modules symlink appear as untracked. Tracked application diff is empty and source state remained unchanged throughout. This limitation is explicit rather than relabeling the proof.

Preparation failures are retained as harness diagnostics, not application defects. The baseline browser prep raced New chat and read the app body twice in the test mode route; the corrected harness waits the actual reset response and consumes the existing typed payload. An intended heading initially followed an identity sentence on the same line; its separator was corrected before final assertions. No expected product assertion was weakened.

Prove It Works shaped the requirement to inspect actual screenshots and SDK/Hono/browser results rather than infer acceptance from the passing build.
