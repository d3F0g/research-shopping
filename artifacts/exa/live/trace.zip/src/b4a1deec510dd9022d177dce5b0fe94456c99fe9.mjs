import assert from 'node:assert/strict';
import { spawn, execFileSync } from 'node:child_process';
import { createWriteStream, mkdirSync, writeFileSync } from 'node:fs';
import net from 'node:net';
import { createRequire } from 'node:module';
const project='/Users/josiahwong/Documents/research-shopping-exa';
const artifacts='/tmp/research-shopping-exa/live';
mkdirSync(artifacts,{recursive:true});
const {chromium}=createRequire(`${project}/package.json`)('@playwright/test');
const ports={api:4073,web:6173};
const proof={commit:execFileSync('git',['rev-parse','HEAD'],{cwd:project,encoding:'utf8'}).trim(),worktreeStatus:execFileSync('git',['status','--short'],{cwd:project,encoding:'utf8'}),result:'running',health:null,searchCalls:0,externalBrowserRequests:[],pageErrors:[],cleanup:false};
const children=[];
const logs=[];
let browser;
let context;
let page;
const occupied=port=>new Promise(resolve=>{const s=net.connect({host:'127.0.0.1',port});s.once('connect',()=>{s.destroy();resolve(true)});s.once('error',()=>resolve(false));});
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function launch(args,env,name){
 const log=createWriteStream(`${artifacts}/${name}.log`,{mode:0o600});
 logs.push(log);
 const child=spawn(process.execPath,args,{cwd:project,env,detached:true,stdio:['ignore','pipe','pipe']});
 child.stdout.pipe(log);child.stderr.pipe(log);children.push(child);return child;
}
try{
 for(const port of Object.values(ports))assert.equal(await occupied(port),false,'Refusing an occupied port');
 const env={...process.env,NODE_ENV:'development',API_PORT:String(ports.api),WEB_PORT:String(ports.web),VITE_API_PORT:String(ports.api),EXA_RESEARCH_ENABLED:'true'};
 delete env.EXA_API_KEY;
 launch(['--env-file=/Users/josiahwong/Documents/research-shopping/.env','--import=tsx','src/server/index.ts'],env,'api');
 launch(['node_modules/vite/bin/vite.js','--host','127.0.0.1','--port',String(ports.web),'--strictPort'],{...env,EXA_RESEARCH_ENABLED:'false'},'web');
 const base=`http://127.0.0.1:${ports.web}`;
 let ready=false;
 for(let attempt=0;attempt<100;attempt++){
  try{const r=await fetch(`${base}/api/health`);if(r.ok){proof.health=await r.json();ready=true;break;}}catch{}
  await pause(150);
 }
 assert.equal(ready,true,'Owned API and web did not become ready');
 assert.equal(proof.health.mode,'fixture');assert.equal(proof.health.liveIntegrations,true);assert.equal(proof.health.webResearch,'enabled');
 browser=await chromium.launch();
 context=await browser.newContext({viewport:{width:1440,height:1000},reducedMotion:'reduce'});
 await context.tracing.start({screenshots:true,snapshots:true,sources:true});
 await context.route('**/*',route=>{
  const url=new URL(route.request().url());
  if(url.hostname!=='127.0.0.1'&&url.hostname!=='localhost'){proof.externalBrowserRequests.push(url.hostname);return route.abort();}
  return route.continue();
 });
 page=await context.newPage();
 page.on('pageerror',()=>proof.pageErrors.push('Browser page error'));
 page.on('request',request=>{if(new URL(request.url()).pathname==='/api/research'&&request.method()==='POST')proof.searchCalls++});
 proof.stage='fixture shortlist';
 await page.goto(base);
 await page.getByRole('button',{name:/Wireless headphones for long flights, under S\$500/}).click();
 await page.getByRole('heading',{name:'Your shortlist',exact:true}).waitFor();
 const cardsBefore=await page.locator('.product-card').allTextContents();
 assert.equal(proof.searchCalls,0);
 proof.stage='live web request';
 const responsePromise=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/research'&&r.request().method()==='POST',{timeout:20000});
 await page.getByRole('button',{name:'Search the web for context',exact:true}).click();
 const response=await responsePromise;
 assert.equal(response.status(),200);
 const payload=await response.json();
 writeFileSync(`${artifacts}/source-response.private.json`,JSON.stringify(payload,null,2)+'\n',{mode:0o600});
 proof.webStatus=payload.status;
 if(payload.status!=='ready'){proof.reason=payload.reason??'disabled';throw new Error('Project Exa search did not return source context');}
 assert.ok(payload.results.length>0,'Exa returned no usable sources');
 assert.ok(payload.results.some(source=>source.highlights.length>0),'Exa returned no highlights');
 proof.sources=payload.results.map(source=>({title:source.title,url:source.url,highlightCount:source.highlights.length}));
 proof.retrievedAt=payload.retrievedAt;
 proof.truncated=payload.truncated;
 proof.stage='source disclosure';
 await page.getByRole('button',{name:new RegExp(`^${payload.results.length} web sources?$`)}).click();
 await page.locator('.web-research-link').first().waitFor();
 assert.equal(proof.searchCalls,1);
 proof.visibleSourcePreviews=await page.locator('.web-research-link:visible').count();
 assert.equal(proof.visibleSourcePreviews,Math.min(3,payload.results.length));
 assert.deepEqual(await page.locator('.product-card').allTextContents(),cardsBefore);
 proof.fixtureCardsUnchanged=true;
 await page.screenshot({path:`${artifacts}/desktop-exa-sources.png`,fullPage:true,animations:'disabled'});
 proof.stage='mobile disclosure';
 await page.setViewportSize({width:390,height:844});
 await page.locator('.web-research-link').first().waitFor();
 const widths=await page.evaluate(()=>({viewport:innerWidth,document:document.documentElement.scrollWidth,body:document.body.scrollWidth}));
 assert.ok(widths.document<=widths.viewport&&widths.body<=widths.viewport);
 proof.mobileWidths=widths;
 await page.screenshot({path:`${artifacts}/mobile-exa-sources.png`,fullPage:true,animations:'disabled'});
 proof.stage='safe handoff';
 const selectionPromise=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/select');
 await page.locator('.product-card').first().getByRole('button',{name:'Select this product',exact:true}).click();
 const selection=await(await selectionPromise).json();
 assert.equal(selection.kind,'handoff');
 const handoff=page.getByRole('link',{name:'Open manufacturer product page'});
 await handoff.waitFor();assert.equal(await handoff.getAttribute('href'),selection.productUrl);
 proof.handoff={productId:selection.productId,destination:selection.productUrl};
 await page.screenshot({path:`${artifacts}/mobile-handoff.png`,fullPage:true,animations:'disabled'});
 assert.equal(proof.searchCalls,1);assert.deepEqual(proof.externalBrowserRequests,[]);assert.deepEqual(proof.pageErrors,[]);
 proof.stage='completed';
 proof.result='passed';
}catch{
 proof.result='failed';proof.failure='Live project verification did not satisfy its recorded checks.';
 process.exitCode=1;
}finally{
 if(proof.result==='failed'&&page)await page.screenshot({path:`${artifacts}/failure.png`,fullPage:true,animations:'disabled'}).catch(()=>{});
 if(context)await context.tracing.stop({path:`${artifacts}/trace.zip`}).catch(()=>{});
 await browser?.close();
 for(const child of children){try{process.kill(-child.pid,'SIGTERM')}catch{}}
 for(let attempt=0;attempt<40;attempt++){if(!(await occupied(ports.api))&&!(await occupied(ports.web)))break;await pause(100);}
 proof.cleanup=!(await occupied(ports.api))&&!(await occupied(ports.web));
 for(const log of logs)log.end();
 if(!proof.cleanup)process.exitCode=1;
 writeFileSync(`${artifacts}/proof.json`,JSON.stringify(proof,null,2)+'\n',{mode:0o600});
 process.stdout.write(JSON.stringify({result:proof.result,cleanup:proof.cleanup,searchCalls:proof.searchCalls,sources:proof.sources?.length??0,webStatus:proof.webStatus??null})+'\n');
}
